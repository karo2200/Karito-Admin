export const enumType = {
	Week: 'Week',
	Day: 'Day',
	Month: 'Month',
};
export default enumType;
