export const IconsAsset = {
	app: '/icons/app.svg',
};
