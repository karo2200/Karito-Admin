import * as React from 'react';

import TabControl from './tab';

const OrderPage = () => {
	return (
		<>
			<TabControl />
		</>
	);
};

export default OrderPage;
