import * as S from './styles';

const Index = () => {
	return (
		<>
			<S.Boxgroup>
				<S.userbox>
					<S.usergroup src={'/images/user.png'} />
					<S.usergroup src={'/images/user1.png'} />
					<S.usergroup src={'/images/user2.png'} />
					<S.usergroup src={'/images/user3.png'} />
					<S.usergroup src={'/images/user1.png'} />
					<S.usergroup src={'/images/user1.png'} />
				</S.userbox>
			</S.Boxgroup>
		</>
	);
};

export default Index;
