import { Box, styled } from '@mui/material';
export const row = styled(Box)({
	display: 'flex',
});
export const cell = styled(Box)({
	flex: 1,
});
