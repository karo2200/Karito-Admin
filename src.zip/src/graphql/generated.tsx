import { useMutation, useQuery, useInfiniteQuery, UseMutationOptions, UseQueryOptions, UseInfiniteQueryOptions } from '@tanstack/react-query';
import { fetcher } from 'src/graphql/fetcher';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: string;
  String: string;
  Boolean: boolean;
  Int: number;
  Float: number;
  Any: any;
  /** The `DateTime` scalar represents an ISO-8601 compliant date time type. */
  DateTime: any;
  /** The `Decimal` scalar type represents a decimal floating-point number. */
  Decimal: any;
  /** The `Long` scalar type represents non-fractional signed whole 64-bit numeric values. Long can represent values between -(2^63) and 2^63 - 1. */
  Long: any;
  UUID: any;
};

export type AcceptServiceRequestInput = {
  serviceRequestId: Scalars['UUID'];
};

export type ActivateCityInput = {
  cityId: Scalars['UUID'];
};

export type ActivateDiscountCodeInput = {
  id: Scalars['UUID'];
};

export type AddAddressInput = {
  customerId: Scalars['UUID'];
  latitude: Scalars['Float'];
  longitude: Scalars['Float'];
  neighborhoodId: Scalars['UUID'];
  text: Scalars['String'];
};

export type AddressDto = {
  __typename?: 'AddressDto';
  customer: CustomerDto;
  id: Scalars['UUID'];
  isPrimary: Scalars['Boolean'];
  latitude: Scalars['Float'];
  longitude: Scalars['Float'];
  neighborhood: NeighborhoodDto;
  text: Scalars['String'];
};

/** A segment of a collection. */
export type AddressDtoCollectionSegment = {
  __typename?: 'AddressDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<AddressDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type AddressDtoFilterInput = {
  and?: InputMaybe<Array<AddressDtoFilterInput>>;
  customer?: InputMaybe<CustomerDtoFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isPrimary?: InputMaybe<BooleanOperationFilterInput>;
  latitude?: InputMaybe<FloatOperationFilterInput>;
  longitude?: InputMaybe<FloatOperationFilterInput>;
  neighborhood?: InputMaybe<NeighborhoodDtoFilterInput>;
  or?: InputMaybe<Array<AddressDtoFilterInput>>;
  text?: InputMaybe<StringOperationFilterInput>;
};

export type AddressDtoSortInput = {
  customer?: InputMaybe<CustomerDtoSortInput>;
  id?: InputMaybe<SortEnumType>;
  isPrimary?: InputMaybe<SortEnumType>;
  latitude?: InputMaybe<SortEnumType>;
  longitude?: InputMaybe<SortEnumType>;
  neighborhood?: InputMaybe<NeighborhoodDtoSortInput>;
  text?: InputMaybe<SortEnumType>;
};

export type ApplyDiscountCodeToServiceRequestInput = {
  discountCode: Scalars['String'];
  serviceRequestId: Scalars['UUID'];
};

/** Defines when a policy shall be executed. */
export enum ApplyPolicy {
  /** After the resolver was executed. */
  AfterResolver = 'AFTER_RESOLVER',
  /** Before the resolver was executed. */
  BeforeResolver = 'BEFORE_RESOLVER',
  /** The policy is applied in the validation step before the execution. */
  Validation = 'VALIDATION'
}

export type AuthResult = {
  __typename?: 'AuthResult';
  accessToken: Scalars['String'];
  refreshToken: Scalars['String'];
};

export type BannerDto = {
  __typename?: 'BannerDto';
  id: Scalars['UUID'];
  imageUrl: Scalars['String'];
  title: Scalars['String'];
};

/** A segment of a collection. */
export type BannerDtoCollectionSegment = {
  __typename?: 'BannerDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<BannerDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type BannerDtoFilterInput = {
  and?: InputMaybe<Array<BannerDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  imageUrl?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<BannerDtoFilterInput>>;
  title?: InputMaybe<StringOperationFilterInput>;
};

export type BannerDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  imageUrl?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
};

export type BooleanOperationFilterInput = {
  eq?: InputMaybe<Scalars['Boolean']>;
  neq?: InputMaybe<Scalars['Boolean']>;
};

export type CancelServiceRequestInput = {
  cancellationReasonId: Scalars['UUID'];
  serviceRequestId: Scalars['UUID'];
};

export type CancellationReasonDto = {
  __typename?: 'CancellationReasonDto';
  id: Scalars['UUID'];
  name: Scalars['String'];
};

/** A segment of a collection. */
export type CancellationReasonDtoCollectionSegment = {
  __typename?: 'CancellationReasonDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CancellationReasonDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type CancellationReasonDtoFilterInput = {
  and?: InputMaybe<Array<CancellationReasonDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<CancellationReasonDtoFilterInput>>;
};

export type CancellationReasonDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type CarouselDto = {
  __typename?: 'CarouselDto';
  id: Scalars['UUID'];
  imageUrls: Array<Scalars['String']>;
  title: Scalars['String'];
};

/** A segment of a collection. */
export type CarouselDtoCollectionSegment = {
  __typename?: 'CarouselDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CarouselDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type CarouselDtoFilterInput = {
  and?: InputMaybe<Array<CarouselDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  imageUrls?: InputMaybe<ListStringOperationFilterInput>;
  or?: InputMaybe<Array<CarouselDtoFilterInput>>;
  title?: InputMaybe<StringOperationFilterInput>;
};

export type CarouselDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
};

export type CityDto = {
  __typename?: 'CityDto';
  activeBanner?: Maybe<BannerDto>;
  activeCarousel?: Maybe<CarouselDto>;
  id: Scalars['UUID'];
  isActive: Scalars['Boolean'];
  name: Scalars['String'];
  province: ProvinceDto;
};

/** A segment of a collection. */
export type CityDtoCollectionSegment = {
  __typename?: 'CityDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CityDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type CityDtoFilterInput = {
  activeBanner?: InputMaybe<BannerDtoFilterInput>;
  activeCarousel?: InputMaybe<CarouselDtoFilterInput>;
  and?: InputMaybe<Array<CityDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isActive?: InputMaybe<BooleanOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<CityDtoFilterInput>>;
  province?: InputMaybe<ProvinceDtoFilterInput>;
};

export type CityDtoSortInput = {
  activeBanner?: InputMaybe<BannerDtoSortInput>;
  activeCarousel?: InputMaybe<CarouselDtoSortInput>;
  id?: InputMaybe<SortEnumType>;
  isActive?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  province?: InputMaybe<ProvinceDtoSortInput>;
};

/** Information about the offset pagination. */
export type CollectionSegmentInfo = {
  __typename?: 'CollectionSegmentInfo';
  /** Indicates whether more items exist following the set defined by the clients arguments. */
  hasNextPage: Scalars['Boolean'];
  /** Indicates whether more items exist prior the set defined by the clients arguments. */
  hasPreviousPage: Scalars['Boolean'];
};

export type CompleteMultipartUploadInput = {
  objectKey: Scalars['String'];
  uploadId: Scalars['String'];
};

export type CompleteServiceInput = {
  serviceRequestId: Scalars['UUID'];
};

export type CreateBannerInput = {
  imageUrl: Scalars['String'];
  title: Scalars['String'];
};

export type CreateCancellationReasonInput = {
  name: Scalars['String'];
};

export type CreateCarouselInput = {
  imageUrls: Array<Scalars['String']>;
  title: Scalars['String'];
};

export type CreateCityInput = {
  name: Scalars['String'];
  provinceId: Scalars['UUID'];
};

export type CreateDisabledServiceTimeInput = {
  time: Scalars['DateTime'];
};

export type CreateDiscountCodeInput = {
  amount: Scalars['Decimal'];
  customerId: Scalars['UUID'];
  expiryDate?: InputMaybe<Scalars['DateTime']>;
  isPercentage: Scalars['Boolean'];
  title: Scalars['String'];
};

export type CreateNeighborhoodInput = {
  cityId: Scalars['UUID'];
  name: Scalars['String'];
};

export type CreatePaymentInput = {
  serviceRequestId: Scalars['UUID'];
};

export type CreateProvinceInput = {
  name: Scalars['String'];
};

export type CreateRateAndReviewInput = {
  comment?: InputMaybe<Scalars['String']>;
  rate: Scalars['Int'];
  serviceRequestId: Scalars['UUID'];
};

export type CreateServiceCategoryInput = {
  logo: Scalars['String'];
  name: Scalars['String'];
};

export type CreateServiceRequestInput = {
  addressId: Scalars['UUID'];
  description: Scalars['String'];
  gender?: InputMaybe<Gender>;
  locationType: LocationType;
  qnAs: Array<QnAInput>;
  requestDate: Scalars['DateTime'];
  serviceTypeId: Scalars['UUID'];
};

export type CreateServiceSubCategoryInput = {
  logo: Scalars['String'];
  name: Scalars['String'];
  serviceCategoryId: Scalars['UUID'];
};

export type CreateServiceTypeInput = {
  basePrice: Scalars['Decimal'];
  isSpecial: Scalars['Boolean'];
  logo: Scalars['String'];
  name: Scalars['String'];
  serviceSubCategoryId: Scalars['UUID'];
};

export type CreateServiceTypeQuestionInput = {
  isRequired: Scalars['Boolean'];
  options: Array<Scalars['String']>;
  questionType: QuestionType;
  serviceTypeId: Scalars['UUID'];
  title: Scalars['String'];
};

export type CustomerDto = {
  __typename?: 'CustomerDto';
  code: Scalars['String'];
  firstName?: Maybe<Scalars['String']>;
  gender: Gender;
  id: Scalars['UUID'];
  lastName?: Maybe<Scalars['String']>;
  phoneNumber: Scalars['String'];
  profileImageUrl?: Maybe<Scalars['String']>;
};

/** A segment of a collection. */
export type CustomerDtoCollectionSegment = {
  __typename?: 'CustomerDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CustomerDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type CustomerDtoFilterInput = {
  and?: InputMaybe<Array<CustomerDtoFilterInput>>;
  code?: InputMaybe<StringOperationFilterInput>;
  firstName?: InputMaybe<StringOperationFilterInput>;
  gender?: InputMaybe<GenderOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  lastName?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<CustomerDtoFilterInput>>;
  phoneNumber?: InputMaybe<StringOperationFilterInput>;
  profileImageUrl?: InputMaybe<StringOperationFilterInput>;
};

export type CustomerDtoSortInput = {
  code?: InputMaybe<SortEnumType>;
  firstName?: InputMaybe<SortEnumType>;
  gender?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  lastName?: InputMaybe<SortEnumType>;
  phoneNumber?: InputMaybe<SortEnumType>;
  profileImageUrl?: InputMaybe<SortEnumType>;
};

export type DateTimeOperationFilterInput = {
  eq?: InputMaybe<Scalars['DateTime']>;
  gt?: InputMaybe<Scalars['DateTime']>;
  gte?: InputMaybe<Scalars['DateTime']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['DateTime']>>>;
  lt?: InputMaybe<Scalars['DateTime']>;
  lte?: InputMaybe<Scalars['DateTime']>;
  neq?: InputMaybe<Scalars['DateTime']>;
  ngt?: InputMaybe<Scalars['DateTime']>;
  ngte?: InputMaybe<Scalars['DateTime']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['DateTime']>>>;
  nlt?: InputMaybe<Scalars['DateTime']>;
  nlte?: InputMaybe<Scalars['DateTime']>;
};

export type DeactivateCityInput = {
  cityId: Scalars['UUID'];
};

export type DeactivateDiscountCodeInput = {
  id: Scalars['UUID'];
};

export type DecimalOperationFilterInput = {
  eq?: InputMaybe<Scalars['Decimal']>;
  gt?: InputMaybe<Scalars['Decimal']>;
  gte?: InputMaybe<Scalars['Decimal']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Decimal']>>>;
  lt?: InputMaybe<Scalars['Decimal']>;
  lte?: InputMaybe<Scalars['Decimal']>;
  neq?: InputMaybe<Scalars['Decimal']>;
  ngt?: InputMaybe<Scalars['Decimal']>;
  ngte?: InputMaybe<Scalars['Decimal']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Decimal']>>>;
  nlt?: InputMaybe<Scalars['Decimal']>;
  nlte?: InputMaybe<Scalars['Decimal']>;
};

export type DeleteAddressInput = {
  addressId: Scalars['UUID'];
};

export type DeleteBannerInput = {
  bannerId: Scalars['UUID'];
};

export type DeleteCancellationReasonInput = {
  id: Scalars['UUID'];
};

export type DeleteCarouselInput = {
  id: Scalars['UUID'];
};

export type DeleteDiscountCodeInput = {
  id: Scalars['UUID'];
};

export type DeleteNeighborhoodInput = {
  neighborhoodId: Scalars['UUID'];
};

export type DeleteProvinceInput = {
  id: Scalars['UUID'];
};

export type DeleteServiceCategoryInput = {
  serviceCategoryId: Scalars['UUID'];
};

export type DeleteServiceSubCategoryInput = {
  serviceSubCategoryId: Scalars['UUID'];
};

export type DeleteServiceTypeInput = {
  id: Scalars['UUID'];
};

export type DeleteServiceTypeQuestionInput = {
  id: Scalars['UUID'];
};

export type DisabledServiceTimeDto = {
  __typename?: 'DisabledServiceTimeDto';
  id: Scalars['UUID'];
  time: Scalars['DateTime'];
};

/** A segment of a collection. */
export type DisabledServiceTimeDtoCollectionSegment = {
  __typename?: 'DisabledServiceTimeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<DisabledServiceTimeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type DisabledServiceTimeDtoFilterInput = {
  and?: InputMaybe<Array<DisabledServiceTimeDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<DisabledServiceTimeDtoFilterInput>>;
  time?: InputMaybe<DateTimeOperationFilterInput>;
};

export type DisabledServiceTimeDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  time?: InputMaybe<SortEnumType>;
};

export type DiscountCodeDto = {
  __typename?: 'DiscountCodeDto';
  amount: Scalars['Decimal'];
  code: Scalars['String'];
  customerDto: CustomerDto;
  expiryDate?: Maybe<Scalars['DateTime']>;
  id: Scalars['UUID'];
  isActive: Scalars['Boolean'];
  isPercentage: Scalars['Boolean'];
  title: Scalars['String'];
};

/** A segment of a collection. */
export type DiscountCodeDtoCollectionSegment = {
  __typename?: 'DiscountCodeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<DiscountCodeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type DiscountCodeDtoFilterInput = {
  amount?: InputMaybe<DecimalOperationFilterInput>;
  and?: InputMaybe<Array<DiscountCodeDtoFilterInput>>;
  code?: InputMaybe<StringOperationFilterInput>;
  customerDto?: InputMaybe<CustomerDtoFilterInput>;
  expiryDate?: InputMaybe<DateTimeOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isActive?: InputMaybe<BooleanOperationFilterInput>;
  isPercentage?: InputMaybe<BooleanOperationFilterInput>;
  or?: InputMaybe<Array<DiscountCodeDtoFilterInput>>;
  title?: InputMaybe<StringOperationFilterInput>;
};

export type DiscountCodeDtoSortInput = {
  amount?: InputMaybe<SortEnumType>;
  code?: InputMaybe<SortEnumType>;
  customerDto?: InputMaybe<CustomerDtoSortInput>;
  expiryDate?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isActive?: InputMaybe<SortEnumType>;
  isPercentage?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
};

export type FloatOperationFilterInput = {
  eq?: InputMaybe<Scalars['Float']>;
  gt?: InputMaybe<Scalars['Float']>;
  gte?: InputMaybe<Scalars['Float']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Float']>>>;
  lt?: InputMaybe<Scalars['Float']>;
  lte?: InputMaybe<Scalars['Float']>;
  neq?: InputMaybe<Scalars['Float']>;
  ngt?: InputMaybe<Scalars['Float']>;
  ngte?: InputMaybe<Scalars['Float']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Float']>>>;
  nlt?: InputMaybe<Scalars['Float']>;
  nlte?: InputMaybe<Scalars['Float']>;
};

export enum Gender {
  Female = 'FEMALE',
  Male = 'MALE',
  NotSet = 'NOT_SET'
}

export type GenderOperationFilterInput = {
  eq?: InputMaybe<Gender>;
  in?: InputMaybe<Array<Gender>>;
  neq?: InputMaybe<Gender>;
  nin?: InputMaybe<Array<Gender>>;
};

export type GenerateMultipartPresignedUrlsInput = {
  fileSize: Scalars['Long'];
  objectKey: Scalars['String'];
  partSize?: InputMaybe<Scalars['Int']>;
};

export type GeneratePresignedUrlInput = {
  objectKey: Scalars['String'];
};

export type GetAddressByIdInput = {
  addressId: Scalars['UUID'];
};

export type GetBannerByIdInput = {
  id: Scalars['UUID'];
};

export type GetCancellationReasonByIdInput = {
  id: Scalars['UUID'];
};

export type GetCarouselByIdInput = {
  id: Scalars['UUID'];
};

export type GetCityByIdInput = {
  id: Scalars['UUID'];
};

export type GetCustomerByIdInput = {
  customerId: Scalars['UUID'];
};

export type GetDiscountCodeByIdInput = {
  id: Scalars['UUID'];
};

export type GetMyRevenueInput = {
  endDate: Scalars['DateTime'];
  startDate: Scalars['DateTime'];
};

export type GetNearestAddressesInput = {
  latitude: Scalars['Float'];
  longitude: Scalars['Float'];
};

export type GetNeighborhoodByIdInput = {
  id: Scalars['UUID'];
};

export type GetPaymentByIdInput = {
  paymentId: Scalars['UUID'];
};

export type GetPaymentsForServiceRequestInput = {
  serviceRequestId: Scalars['UUID'];
};

export type GetProvinceByIdInput = {
  id: Scalars['UUID'];
};

export type GetServiceCategoryByIdInput = {
  id: Scalars['UUID'];
};

export type GetServiceRequestByIdInput = {
  serviceRequestId: Scalars['UUID'];
};

export type GetServiceSubCategoryByIdInput = {
  id: Scalars['UUID'];
};

export type GetServiceTypeByIdInput = {
  id: Scalars['UUID'];
};

export type GetServiceTypeQuestionByIdInput = {
  id: Scalars['UUID'];
};

export type GetServiceTypeQuestionsByServiceTypeInput = {
  serviceTypeId: Scalars['UUID'];
};

export type GetSpecialistByIdInput = {
  specialistId: Scalars['UUID'];
};

export type GetSpecialistRevenueByIdInput = {
  endDate: Scalars['DateTime'];
  specialistId: Scalars['UUID'];
  startDate: Scalars['DateTime'];
};

export type IntOperationFilterInput = {
  eq?: InputMaybe<Scalars['Int']>;
  gt?: InputMaybe<Scalars['Int']>;
  gte?: InputMaybe<Scalars['Int']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Int']>>>;
  lt?: InputMaybe<Scalars['Int']>;
  lte?: InputMaybe<Scalars['Int']>;
  neq?: InputMaybe<Scalars['Int']>;
  ngt?: InputMaybe<Scalars['Int']>;
  ngte?: InputMaybe<Scalars['Int']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Int']>>>;
  nlt?: InputMaybe<Scalars['Int']>;
  nlte?: InputMaybe<Scalars['Int']>;
};

export type ListFilterInputTypeOfServiceRequestQnADtoFilterInput = {
  all?: InputMaybe<ServiceRequestQnADtoFilterInput>;
  any?: InputMaybe<Scalars['Boolean']>;
  none?: InputMaybe<ServiceRequestQnADtoFilterInput>;
  some?: InputMaybe<ServiceRequestQnADtoFilterInput>;
};

export type ListFilterInputTypeOfServiceTypeDtoFilterInput = {
  all?: InputMaybe<ServiceTypeDtoFilterInput>;
  any?: InputMaybe<Scalars['Boolean']>;
  none?: InputMaybe<ServiceTypeDtoFilterInput>;
  some?: InputMaybe<ServiceTypeDtoFilterInput>;
};

export type ListResponseBaseOfAddressDto = {
  __typename?: 'ListResponseBaseOfAddressDto';
  result?: Maybe<AddressDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfAddressDtoResultArgs = {
  order?: InputMaybe<Array<AddressDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<AddressDtoFilterInput>;
};

export type ListResponseBaseOfBannerDto = {
  __typename?: 'ListResponseBaseOfBannerDto';
  result?: Maybe<BannerDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfBannerDtoResultArgs = {
  order?: InputMaybe<Array<BannerDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<BannerDtoFilterInput>;
};

export type ListResponseBaseOfCancellationReasonDto = {
  __typename?: 'ListResponseBaseOfCancellationReasonDto';
  result?: Maybe<CancellationReasonDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfCancellationReasonDtoResultArgs = {
  order?: InputMaybe<Array<CancellationReasonDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CancellationReasonDtoFilterInput>;
};

export type ListResponseBaseOfCarouselDto = {
  __typename?: 'ListResponseBaseOfCarouselDto';
  result?: Maybe<CarouselDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfCarouselDtoResultArgs = {
  order?: InputMaybe<Array<CarouselDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CarouselDtoFilterInput>;
};

export type ListResponseBaseOfCityDto = {
  __typename?: 'ListResponseBaseOfCityDto';
  result?: Maybe<CityDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfCityDtoResultArgs = {
  order?: InputMaybe<Array<CityDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CityDtoFilterInput>;
};

export type ListResponseBaseOfCustomerDto = {
  __typename?: 'ListResponseBaseOfCustomerDto';
  result?: Maybe<CustomerDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfCustomerDtoResultArgs = {
  order?: InputMaybe<Array<CustomerDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CustomerDtoFilterInput>;
};

export type ListResponseBaseOfDisabledServiceTimeDto = {
  __typename?: 'ListResponseBaseOfDisabledServiceTimeDto';
  result?: Maybe<DisabledServiceTimeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfDisabledServiceTimeDtoResultArgs = {
  order?: InputMaybe<Array<DisabledServiceTimeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<DisabledServiceTimeDtoFilterInput>;
};

export type ListResponseBaseOfDiscountCodeDto = {
  __typename?: 'ListResponseBaseOfDiscountCodeDto';
  result?: Maybe<DiscountCodeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfDiscountCodeDtoResultArgs = {
  order?: InputMaybe<Array<DiscountCodeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<DiscountCodeDtoFilterInput>;
};

export type ListResponseBaseOfNeighborhoodDto = {
  __typename?: 'ListResponseBaseOfNeighborhoodDto';
  result?: Maybe<NeighborhoodDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfNeighborhoodDtoResultArgs = {
  order?: InputMaybe<Array<NeighborhoodDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<NeighborhoodDtoFilterInput>;
};

export type ListResponseBaseOfPaymentDto = {
  __typename?: 'ListResponseBaseOfPaymentDto';
  result?: Maybe<PaymentDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfPaymentDtoResultArgs = {
  order?: InputMaybe<Array<PaymentDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<PaymentDtoFilterInput>;
};

export type ListResponseBaseOfPopularServiceTypeDto = {
  __typename?: 'ListResponseBaseOfPopularServiceTypeDto';
  result?: Maybe<PopularServiceTypeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfPopularServiceTypeDtoResultArgs = {
  order?: InputMaybe<Array<PopularServiceTypeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<PopularServiceTypeDtoFilterInput>;
};

export type ListResponseBaseOfProvinceDto = {
  __typename?: 'ListResponseBaseOfProvinceDto';
  result?: Maybe<ProvinceDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfProvinceDtoResultArgs = {
  order?: InputMaybe<Array<ProvinceDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ProvinceDtoFilterInput>;
};

export type ListResponseBaseOfRateAndReviewDto = {
  __typename?: 'ListResponseBaseOfRateAndReviewDto';
  result?: Maybe<RateAndReviewDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfRateAndReviewDtoResultArgs = {
  order?: InputMaybe<Array<RateAndReviewDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<RateAndReviewDtoFilterInput>;
};

export type ListResponseBaseOfServiceCategoryDto = {
  __typename?: 'ListResponseBaseOfServiceCategoryDto';
  result?: Maybe<ServiceCategoryDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfServiceCategoryDtoResultArgs = {
  order?: InputMaybe<Array<ServiceCategoryDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceCategoryDtoFilterInput>;
};

export type ListResponseBaseOfServiceRequestDto = {
  __typename?: 'ListResponseBaseOfServiceRequestDto';
  result?: Maybe<ServiceRequestDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfServiceRequestDtoResultArgs = {
  order?: InputMaybe<Array<ServiceRequestDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceRequestDtoFilterInput>;
};

export type ListResponseBaseOfServiceSubCategoryDto = {
  __typename?: 'ListResponseBaseOfServiceSubCategoryDto';
  result?: Maybe<ServiceSubCategoryDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfServiceSubCategoryDtoResultArgs = {
  order?: InputMaybe<Array<ServiceSubCategoryDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
};

export type ListResponseBaseOfServiceTypeDto = {
  __typename?: 'ListResponseBaseOfServiceTypeDto';
  result?: Maybe<ServiceTypeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfServiceTypeDtoResultArgs = {
  order?: InputMaybe<Array<ServiceTypeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceTypeDtoFilterInput>;
};

export type ListResponseBaseOfServiceTypeQuestionDto = {
  __typename?: 'ListResponseBaseOfServiceTypeQuestionDto';
  result?: Maybe<ServiceTypeQuestionDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfServiceTypeQuestionDtoResultArgs = {
  order?: InputMaybe<Array<ServiceTypeQuestionDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceTypeQuestionDtoFilterInput>;
};

export type ListResponseBaseOfSpecialistProfileDto = {
  __typename?: 'ListResponseBaseOfSpecialistProfileDto';
  result?: Maybe<SpecialistProfileDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']>;
};


export type ListResponseBaseOfSpecialistProfileDtoResultArgs = {
  order?: InputMaybe<Array<SpecialistProfileDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<SpecialistProfileDtoFilterInput>;
};

export type ListStringOperationFilterInput = {
  all?: InputMaybe<StringOperationFilterInput>;
  any?: InputMaybe<Scalars['Boolean']>;
  none?: InputMaybe<StringOperationFilterInput>;
  some?: InputMaybe<StringOperationFilterInput>;
};

export enum LocationType {
  Commercial = 'COMMERCIAL',
  Office = 'OFFICE',
  Residential = 'RESIDENTIAL',
  Vacant = 'VACANT'
}

export type MarkAsArrivedInput = {
  latitude: Scalars['Float'];
  longitude: Scalars['Float'];
  serviceRequestId: Scalars['UUID'];
};

export type Mutation = {
  __typename?: 'Mutation';
  address_create: ResponseBaseOfAddressDto;
  address_delete: ResponseBase;
  address_setPrimary: ResponseBaseOfAddressDto;
  address_update: ResponseBaseOfAddressDto;
  auth_refreshToken: ResponseBaseOfAuthResult;
  auth_requestOtp: ResponseBase;
  auth_verifyOtp: ResponseBaseOfAuthResult;
  banner_create: ResponseBaseOfBannerDto;
  banner_delete: ResponseBase;
  banner_update: ResponseBaseOfBannerDto;
  cancellationReason_create: ResponseBaseOfCancellationReasonDto;
  cancellationReason_delete: ResponseBase;
  cancellationReason_update: ResponseBaseOfCancellationReasonDto;
  carousel_create: ResponseBaseOfCarouselDto;
  carousel_delete: ResponseBase;
  carousel_update: ResponseBaseOfCarouselDto;
  city_activate: ResponseBaseOfCityDto;
  city_create: ResponseBaseOfCityDto;
  city_deactivate: ResponseBaseOfCityDto;
  city_setActiveBanner: ResponseBaseOfCityDto;
  city_setActiveCarousel: ResponseBaseOfCityDto;
  city_update: ResponseBaseOfCityDto;
  disabledServiceTime_create: ResponseBaseOfDisabledServiceTimeDto;
  disabledServiceTime_remove: ResponseBase;
  discountCode_activate: ResponseBaseOfDiscountCodeDto;
  discountCode_create: ResponseBaseOfDiscountCodeDto;
  discountCode_deactivate: ResponseBaseOfDiscountCodeDto;
  discountCode_delete: ResponseBase;
  neighborhood_create: ResponseBaseOfNeighborhoodDto;
  neighborhood_delete: ResponseBase;
  neighborhood_update: ResponseBaseOfNeighborhoodDto;
  payment_create: ResponseBaseOfPaymentDto;
  province_create: ResponseBaseOfProvinceDto;
  province_delete: ResponseBase;
  province_update: ResponseBaseOfProvinceDto;
  rateAndReview_create: ResponseBaseOfRateAndReviewDto;
  s3_completeMultipartUpload: ResponseBase;
  s3_generatePresignedUrl: ResponseBaseOfS3SinglepartUploadUrlsResultDto;
  s3_generatePresignedUrls: ResponseBaseOfS3MultipartUploadUrlsResultDto;
  serviceCategory_create: ResponseBaseOfServiceCategoryDto;
  serviceCategory_delete: ResponseBase;
  serviceCategory_update: ResponseBaseOfServiceCategoryDto;
  serviceRequest_accept: ResponseBaseOfServiceRequestDto;
  serviceRequest_applyDiscount: ResponseBaseOfServiceRequestDto;
  serviceRequest_cancel: ResponseBaseOfServiceRequestDto;
  serviceRequest_completeService: ResponseBaseOfServiceRequestDto;
  serviceRequest_create: ResponseBaseOfServiceRequestDto;
  serviceRequest_markAsArrived: ResponseBaseOfServiceRequestDto;
  serviceRequest_reject: ResponseBaseOfRejectedServiceRequestDto;
  serviceRequest_removeDiscount: ResponseBaseOfServiceRequestDto;
  serviceSubCategory_create: ResponseBaseOfServiceSubCategoryDto;
  serviceSubCategory_delete: ResponseBase;
  serviceSubCategory_update: ResponseBaseOfServiceSubCategoryDto;
  serviceTypeQuestion_create: ResponseBaseOfServiceTypeQuestionDto;
  serviceTypeQuestion_delete: ResponseBase;
  serviceTypeQuestion_update: ResponseBaseOfServiceTypeQuestionDto;
  serviceType_create: ResponseBaseOfServiceTypeDto;
  serviceType_delete: ResponseBase;
  serviceType_update: ResponseBaseOfServiceTypeDto;
  specialist_setLocationAndSpecialty: ResponseBaseOfSpecialistProfileDto;
  specialist_setPersonalInformation: ResponseBaseOfSpecialistProfileDto;
  specialist_updateIdentityVerificationVideo: ResponseBase;
  specialist_updateSpecializedDocuments: ResponseBase;
  specialist_verifyIDCard: ResponseBase;
  specialist_verifyIdentityVerificationVideo: ResponseBase;
  specialist_verifySpecializedDocuments: ResponseBase;
  /** Allows an owner to create a new admin user. */
  user_createAdmin: ResponseBase;
  user_updateProfile: ResponseBaseOfUserProfileDto;
};


export type MutationAddress_CreateArgs = {
  input: AddAddressInput;
};


export type MutationAddress_DeleteArgs = {
  input: DeleteAddressInput;
};


export type MutationAddress_SetPrimaryArgs = {
  input: SetPrimaryAddressInput;
};


export type MutationAddress_UpdateArgs = {
  input: UpdateAddressInput;
};


export type MutationAuth_RefreshTokenArgs = {
  input: RefreshTokenRequestInput;
};


export type MutationAuth_RequestOtpArgs = {
  input: RequestOtpInput;
};


export type MutationAuth_VerifyOtpArgs = {
  input: VerifyOtpInput;
};


export type MutationBanner_CreateArgs = {
  input: CreateBannerInput;
};


export type MutationBanner_DeleteArgs = {
  input: DeleteBannerInput;
};


export type MutationBanner_UpdateArgs = {
  input: UpdateBannerInput;
};


export type MutationCancellationReason_CreateArgs = {
  input: CreateCancellationReasonInput;
};


export type MutationCancellationReason_DeleteArgs = {
  input: DeleteCancellationReasonInput;
};


export type MutationCancellationReason_UpdateArgs = {
  input: UpdateCancellationReasonInput;
};


export type MutationCarousel_CreateArgs = {
  input: CreateCarouselInput;
};


export type MutationCarousel_DeleteArgs = {
  input: DeleteCarouselInput;
};


export type MutationCarousel_UpdateArgs = {
  input: UpdateCarouselInput;
};


export type MutationCity_ActivateArgs = {
  input: ActivateCityInput;
};


export type MutationCity_CreateArgs = {
  input: CreateCityInput;
};


export type MutationCity_DeactivateArgs = {
  input: DeactivateCityInput;
};


export type MutationCity_SetActiveBannerArgs = {
  input: SetActiveBannerInput;
};


export type MutationCity_SetActiveCarouselArgs = {
  input: SetActiveCarouselInput;
};


export type MutationCity_UpdateArgs = {
  input: UpdateCityInput;
};


export type MutationDisabledServiceTime_CreateArgs = {
  input: CreateDisabledServiceTimeInput;
};


export type MutationDisabledServiceTime_RemoveArgs = {
  input: RemoveDisabledServiceTimeInput;
};


export type MutationDiscountCode_ActivateArgs = {
  input: ActivateDiscountCodeInput;
};


export type MutationDiscountCode_CreateArgs = {
  input: CreateDiscountCodeInput;
};


export type MutationDiscountCode_DeactivateArgs = {
  input: DeactivateDiscountCodeInput;
};


export type MutationDiscountCode_DeleteArgs = {
  input: DeleteDiscountCodeInput;
};


export type MutationNeighborhood_CreateArgs = {
  input: CreateNeighborhoodInput;
};


export type MutationNeighborhood_DeleteArgs = {
  input: DeleteNeighborhoodInput;
};


export type MutationNeighborhood_UpdateArgs = {
  input: UpdateNeighborhoodInput;
};


export type MutationPayment_CreateArgs = {
  input: CreatePaymentInput;
};


export type MutationProvince_CreateArgs = {
  input: CreateProvinceInput;
};


export type MutationProvince_DeleteArgs = {
  input: DeleteProvinceInput;
};


export type MutationProvince_UpdateArgs = {
  input: UpdateProvinceInput;
};


export type MutationRateAndReview_CreateArgs = {
  input: CreateRateAndReviewInput;
};


export type MutationS3_CompleteMultipartUploadArgs = {
  input: CompleteMultipartUploadInput;
};


export type MutationS3_GeneratePresignedUrlArgs = {
  input: GeneratePresignedUrlInput;
};


export type MutationS3_GeneratePresignedUrlsArgs = {
  input: GenerateMultipartPresignedUrlsInput;
};


export type MutationServiceCategory_CreateArgs = {
  input: CreateServiceCategoryInput;
};


export type MutationServiceCategory_DeleteArgs = {
  input: DeleteServiceCategoryInput;
};


export type MutationServiceCategory_UpdateArgs = {
  input: UpdateServiceCategoryInput;
};


export type MutationServiceRequest_AcceptArgs = {
  input: AcceptServiceRequestInput;
};


export type MutationServiceRequest_ApplyDiscountArgs = {
  input: ApplyDiscountCodeToServiceRequestInput;
};


export type MutationServiceRequest_CancelArgs = {
  input: CancelServiceRequestInput;
};


export type MutationServiceRequest_CompleteServiceArgs = {
  input: CompleteServiceInput;
};


export type MutationServiceRequest_CreateArgs = {
  input: CreateServiceRequestInput;
};


export type MutationServiceRequest_MarkAsArrivedArgs = {
  input: MarkAsArrivedInput;
};


export type MutationServiceRequest_RejectArgs = {
  input: RejectServiceRequestInput;
};


export type MutationServiceRequest_RemoveDiscountArgs = {
  input: RemoveDiscountCodeFromServiceRequestInput;
};


export type MutationServiceSubCategory_CreateArgs = {
  input: CreateServiceSubCategoryInput;
};


export type MutationServiceSubCategory_DeleteArgs = {
  input: DeleteServiceSubCategoryInput;
};


export type MutationServiceSubCategory_UpdateArgs = {
  input: UpdateServiceSubCategoryInput;
};


export type MutationServiceTypeQuestion_CreateArgs = {
  input: CreateServiceTypeQuestionInput;
};


export type MutationServiceTypeQuestion_DeleteArgs = {
  input: DeleteServiceTypeQuestionInput;
};


export type MutationServiceTypeQuestion_UpdateArgs = {
  input: UpdateServiceTypeQuestionInput;
};


export type MutationServiceType_CreateArgs = {
  input: CreateServiceTypeInput;
};


export type MutationServiceType_DeleteArgs = {
  input: DeleteServiceTypeInput;
};


export type MutationServiceType_UpdateArgs = {
  input: UpdateServiceTypeInput;
};


export type MutationSpecialist_SetLocationAndSpecialtyArgs = {
  input: SetLocationAndSpecialtyInput;
};


export type MutationSpecialist_SetPersonalInformationArgs = {
  input: SetPersonalInformationInput;
};


export type MutationSpecialist_UpdateIdentityVerificationVideoArgs = {
  input: UpdateIdentityVerificationVideoInput;
};


export type MutationSpecialist_UpdateSpecializedDocumentsArgs = {
  input: UpdateSpecializedDocumentsInput;
};


export type MutationSpecialist_VerifyIdCardArgs = {
  input: VerifyIdCardInput;
};


export type MutationSpecialist_VerifyIdentityVerificationVideoArgs = {
  input: VerifyIdentityVerificationVideoInput;
};


export type MutationSpecialist_VerifySpecializedDocumentsArgs = {
  input: VerifySpecializedDocumentsInput;
};


export type MutationUser_CreateAdminArgs = {
  adminPhoneNumber: Scalars['String'];
};


export type MutationUser_UpdateProfileArgs = {
  input: UpdateUserProfileInput;
};

export type NeighborhoodDto = {
  __typename?: 'NeighborhoodDto';
  city: CityDto;
  id: Scalars['UUID'];
  name: Scalars['String'];
};

/** A segment of a collection. */
export type NeighborhoodDtoCollectionSegment = {
  __typename?: 'NeighborhoodDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<NeighborhoodDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type NeighborhoodDtoFilterInput = {
  and?: InputMaybe<Array<NeighborhoodDtoFilterInput>>;
  city?: InputMaybe<CityDtoFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<NeighborhoodDtoFilterInput>>;
};

export type NeighborhoodDtoSortInput = {
  city?: InputMaybe<CityDtoSortInput>;
  id?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type PaymentDto = {
  __typename?: 'PaymentDto';
  amount: Scalars['Decimal'];
  discountAmount: Scalars['Decimal'];
  discountCode?: Maybe<DiscountCodeDto>;
  finalAmount: Scalars['Decimal'];
  id: Scalars['UUID'];
  paymentUrl?: Maybe<Scalars['String']>;
  serviceRequest: ServiceRequestDto;
  status: PaymentStatus;
};

/** A segment of a collection. */
export type PaymentDtoCollectionSegment = {
  __typename?: 'PaymentDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<PaymentDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type PaymentDtoFilterInput = {
  amount?: InputMaybe<DecimalOperationFilterInput>;
  and?: InputMaybe<Array<PaymentDtoFilterInput>>;
  discountAmount?: InputMaybe<DecimalOperationFilterInput>;
  discountCode?: InputMaybe<DiscountCodeDtoFilterInput>;
  finalAmount?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<PaymentDtoFilterInput>>;
  paymentUrl?: InputMaybe<StringOperationFilterInput>;
  serviceRequest?: InputMaybe<ServiceRequestDtoFilterInput>;
  status?: InputMaybe<PaymentStatusOperationFilterInput>;
};

export type PaymentDtoSortInput = {
  amount?: InputMaybe<SortEnumType>;
  discountAmount?: InputMaybe<SortEnumType>;
  discountCode?: InputMaybe<DiscountCodeDtoSortInput>;
  finalAmount?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  paymentUrl?: InputMaybe<SortEnumType>;
  serviceRequest?: InputMaybe<ServiceRequestDtoSortInput>;
  status?: InputMaybe<SortEnumType>;
};

export enum PaymentStatus {
  Failed = 'FAILED',
  Pending = 'PENDING',
  Success = 'SUCCESS'
}

export type PaymentStatusOperationFilterInput = {
  eq?: InputMaybe<PaymentStatus>;
  in?: InputMaybe<Array<PaymentStatus>>;
  neq?: InputMaybe<PaymentStatus>;
  nin?: InputMaybe<Array<PaymentStatus>>;
};

export type PopularServiceTypeDto = {
  __typename?: 'PopularServiceTypeDto';
  basePrice: Scalars['Decimal'];
  id: Scalars['UUID'];
  isSpecial: Scalars['Boolean'];
  logo: Scalars['String'];
  name: Scalars['String'];
  requestCount: Scalars['Int'];
  serviceSubCategory: ServiceSubCategoryDto;
};

/** A segment of a collection. */
export type PopularServiceTypeDtoCollectionSegment = {
  __typename?: 'PopularServiceTypeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<PopularServiceTypeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type PopularServiceTypeDtoFilterInput = {
  and?: InputMaybe<Array<PopularServiceTypeDtoFilterInput>>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isSpecial?: InputMaybe<BooleanOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<PopularServiceTypeDtoFilterInput>>;
  requestCount?: InputMaybe<IntOperationFilterInput>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
};

export type PopularServiceTypeDtoSortInput = {
  basePrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isSpecial?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  requestCount?: InputMaybe<SortEnumType>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoSortInput>;
};

export type ProvinceDto = {
  __typename?: 'ProvinceDto';
  id: Scalars['UUID'];
  name: Scalars['String'];
};

/** A segment of a collection. */
export type ProvinceDtoCollectionSegment = {
  __typename?: 'ProvinceDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ProvinceDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type ProvinceDtoFilterInput = {
  and?: InputMaybe<Array<ProvinceDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ProvinceDtoFilterInput>>;
};

export type ProvinceDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type QnAInput = {
  answers: Array<Scalars['String']>;
  questionId: Scalars['UUID'];
};

export type Query = {
  __typename?: 'Query';
  address_getAddressById: ResponseBaseOfAddressDto;
  address_getMyAddresses: ListResponseBaseOfAddressDto;
  address_nearestAddresses: ListResponseBaseOfAddressDto;
  banner_getAll: ListResponseBaseOfBannerDto;
  banner_getById: ResponseBaseOfBannerDto;
  cancellationReason_getAll: ListResponseBaseOfCancellationReasonDto;
  cancellationReason_getById: ResponseBaseOfCancellationReasonDto;
  carousel_getAll: ListResponseBaseOfCarouselDto;
  carousel_getById: ResponseBaseOfCarouselDto;
  city_getAll: ListResponseBaseOfCityDto;
  city_getById: ResponseBaseOfCityDto;
  /** Returns all customers. */
  customer_getAll: ListResponseBaseOfCustomerDto;
  /** Returns a customer by their ID. */
  customer_getById: ResponseBaseOfCustomerDto;
  disabledServiceTime_getAll: ListResponseBaseOfDisabledServiceTimeDto;
  discountCode_getAll: ListResponseBaseOfDiscountCodeDto;
  discountCode_getById: ResponseBaseOfDiscountCodeDto;
  discountCode_getMyCodes: ListResponseBaseOfDiscountCodeDto;
  neighborhood_getAll: ListResponseBaseOfNeighborhoodDto;
  neighborhood_getById: ResponseBaseOfNeighborhoodDto;
  payment_getById: ResponseBaseOfPaymentDto;
  payment_listForServiceRequest: ListResponseBaseOfPaymentDto;
  province_getAll: ListResponseBaseOfProvinceDto;
  province_getById: ResponseBaseOfProvinceDto;
  rateAndReview_getByCustomerId: ListResponseBaseOfRateAndReviewDto;
  rateAndReview_getBySpecialistId: ListResponseBaseOfRateAndReviewDto;
  /** Get revenue for the currently authenticated specialist in a given date range. */
  revenue_getMyRevenue: ResponseBaseOfSpecialistRevenueDto;
  /** Admin: get revenue of a specialist in a given date range. */
  revenue_getRevenueBySpecialistId: ResponseBaseOfSpecialistRevenueDto;
  serviceCategory_getAll: ListResponseBaseOfServiceCategoryDto;
  serviceCategory_getById: ResponseBaseOfServiceCategoryDto;
  serviceRequest_getAll: ListResponseBaseOfServiceRequestDto;
  serviceRequest_getAvailableRequests: ListResponseBaseOfServiceRequestDto;
  serviceRequest_getById: ResponseBaseOfServiceRequestDto;
  serviceRequest_getMyAcceptances: ListResponseBaseOfServiceRequestDto;
  serviceRequest_getMyRequests: ListResponseBaseOfServiceRequestDto;
  serviceSubCategory_getAll: ListResponseBaseOfServiceSubCategoryDto;
  serviceSubCategory_getById: ResponseBaseOfServiceSubCategoryDto;
  serviceTypeQuestion_getById: ResponseBaseOfServiceTypeQuestionDto;
  serviceTypeQuestion_getByServiceType: ListResponseBaseOfServiceTypeQuestionDto;
  serviceType_getById: ResponseBaseOfServiceTypeDto;
  serviceTypes_getAll: ListResponseBaseOfServiceTypeDto;
  serviceTypes_getPopular: ListResponseBaseOfPopularServiceTypeDto;
  /** Returns all specialists. */
  specialist_getAll: ListResponseBaseOfSpecialistProfileDto;
  /** Returns a specialist by their ID. */
  specialist_getById: ResponseBaseOfSpecialistProfileDto;
  /** Returns the profile of the currently authenticated specialist. */
  specialist_getMyProfile: ResponseBaseOfSpecialistProfileDto;
  /** Gets the profile of the currently authenticated user. */
  user_getMyProfile: ResponseBaseOfUserProfileDto;
};


export type QueryAddress_GetAddressByIdArgs = {
  input: GetAddressByIdInput;
};


export type QueryAddress_NearestAddressesArgs = {
  input: GetNearestAddressesInput;
};


export type QueryBanner_GetByIdArgs = {
  input: GetBannerByIdInput;
};


export type QueryCancellationReason_GetByIdArgs = {
  input: GetCancellationReasonByIdInput;
};


export type QueryCarousel_GetByIdArgs = {
  input: GetCarouselByIdInput;
};


export type QueryCity_GetByIdArgs = {
  input: GetCityByIdInput;
};


export type QueryCustomer_GetByIdArgs = {
  input: GetCustomerByIdInput;
};


export type QueryDiscountCode_GetByIdArgs = {
  input: GetDiscountCodeByIdInput;
};


export type QueryNeighborhood_GetByIdArgs = {
  input: GetNeighborhoodByIdInput;
};


export type QueryPayment_GetByIdArgs = {
  input: GetPaymentByIdInput;
};


export type QueryPayment_ListForServiceRequestArgs = {
  input: GetPaymentsForServiceRequestInput;
};


export type QueryProvince_GetByIdArgs = {
  input: GetProvinceByIdInput;
};


export type QueryRateAndReview_GetByCustomerIdArgs = {
  customerId: Scalars['UUID'];
};


export type QueryRateAndReview_GetBySpecialistIdArgs = {
  specialistId: Scalars['UUID'];
};


export type QueryRevenue_GetMyRevenueArgs = {
  input: GetMyRevenueInput;
};


export type QueryRevenue_GetRevenueBySpecialistIdArgs = {
  input: GetSpecialistRevenueByIdInput;
};


export type QueryServiceCategory_GetByIdArgs = {
  input: GetServiceCategoryByIdInput;
};


export type QueryServiceRequest_GetByIdArgs = {
  input: GetServiceRequestByIdInput;
};


export type QueryServiceSubCategory_GetByIdArgs = {
  input: GetServiceSubCategoryByIdInput;
};


export type QueryServiceTypeQuestion_GetByIdArgs = {
  input: GetServiceTypeQuestionByIdInput;
};


export type QueryServiceTypeQuestion_GetByServiceTypeArgs = {
  input: GetServiceTypeQuestionsByServiceTypeInput;
};


export type QueryServiceType_GetByIdArgs = {
  input: GetServiceTypeByIdInput;
};


export type QuerySpecialist_GetByIdArgs = {
  input: GetSpecialistByIdInput;
};

export enum QuestionType {
  CheckBox = 'CHECK_BOX',
  RadioButton = 'RADIO_BUTTON'
}

export type QuestionTypeOperationFilterInput = {
  eq?: InputMaybe<QuestionType>;
  in?: InputMaybe<Array<QuestionType>>;
  neq?: InputMaybe<QuestionType>;
  nin?: InputMaybe<Array<QuestionType>>;
};

export type RateAndReviewDto = {
  __typename?: 'RateAndReviewDto';
  comment: Scalars['String'];
  rate: Scalars['Int'];
};

/** A segment of a collection. */
export type RateAndReviewDtoCollectionSegment = {
  __typename?: 'RateAndReviewDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<RateAndReviewDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type RateAndReviewDtoFilterInput = {
  and?: InputMaybe<Array<RateAndReviewDtoFilterInput>>;
  comment?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<RateAndReviewDtoFilterInput>>;
  rate?: InputMaybe<IntOperationFilterInput>;
};

export type RateAndReviewDtoSortInput = {
  comment?: InputMaybe<SortEnumType>;
  rate?: InputMaybe<SortEnumType>;
};

export type RefreshTokenRequestInput = {
  accessToken: Scalars['String'];
  refreshToken: Scalars['String'];
};

export type RejectServiceRequestInput = {
  serviceRequestId: Scalars['UUID'];
};

export type RejectedServiceRequestDto = {
  __typename?: 'RejectedServiceRequestDto';
  serviceRequest: ServiceRequestDto;
  specialist: SpecialistDto;
};

export type RemoveDisabledServiceTimeInput = {
  id: Scalars['UUID'];
};

export type RemoveDiscountCodeFromServiceRequestInput = {
  serviceRequestId: Scalars['UUID'];
};

export type RequestOtpInput = {
  phoneNumber: Scalars['String'];
  userType: UserType;
};

export type ResponseBase = {
  __typename?: 'ResponseBase';
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfAddressDto = {
  __typename?: 'ResponseBaseOfAddressDto';
  result?: Maybe<AddressDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfAuthResult = {
  __typename?: 'ResponseBaseOfAuthResult';
  result?: Maybe<AuthResult>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfBannerDto = {
  __typename?: 'ResponseBaseOfBannerDto';
  result?: Maybe<BannerDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfCancellationReasonDto = {
  __typename?: 'ResponseBaseOfCancellationReasonDto';
  result?: Maybe<CancellationReasonDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfCarouselDto = {
  __typename?: 'ResponseBaseOfCarouselDto';
  result?: Maybe<CarouselDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfCityDto = {
  __typename?: 'ResponseBaseOfCityDto';
  result?: Maybe<CityDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfCustomerDto = {
  __typename?: 'ResponseBaseOfCustomerDto';
  result?: Maybe<CustomerDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfDisabledServiceTimeDto = {
  __typename?: 'ResponseBaseOfDisabledServiceTimeDto';
  result?: Maybe<DisabledServiceTimeDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfDiscountCodeDto = {
  __typename?: 'ResponseBaseOfDiscountCodeDto';
  result?: Maybe<DiscountCodeDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfNeighborhoodDto = {
  __typename?: 'ResponseBaseOfNeighborhoodDto';
  result?: Maybe<NeighborhoodDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfPaymentDto = {
  __typename?: 'ResponseBaseOfPaymentDto';
  result?: Maybe<PaymentDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfProvinceDto = {
  __typename?: 'ResponseBaseOfProvinceDto';
  result?: Maybe<ProvinceDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfRateAndReviewDto = {
  __typename?: 'ResponseBaseOfRateAndReviewDto';
  result?: Maybe<RateAndReviewDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfRejectedServiceRequestDto = {
  __typename?: 'ResponseBaseOfRejectedServiceRequestDto';
  result?: Maybe<RejectedServiceRequestDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfS3MultipartUploadUrlsResultDto = {
  __typename?: 'ResponseBaseOfS3MultipartUploadUrlsResultDto';
  result?: Maybe<S3MultipartUploadUrlsResultDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfS3SinglepartUploadUrlsResultDto = {
  __typename?: 'ResponseBaseOfS3SinglepartUploadUrlsResultDto';
  result?: Maybe<S3SinglepartUploadUrlsResultDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfServiceCategoryDto = {
  __typename?: 'ResponseBaseOfServiceCategoryDto';
  result?: Maybe<ServiceCategoryDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfServiceRequestDto = {
  __typename?: 'ResponseBaseOfServiceRequestDto';
  result?: Maybe<ServiceRequestDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfServiceSubCategoryDto = {
  __typename?: 'ResponseBaseOfServiceSubCategoryDto';
  result?: Maybe<ServiceSubCategoryDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfServiceTypeDto = {
  __typename?: 'ResponseBaseOfServiceTypeDto';
  result?: Maybe<ServiceTypeDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfServiceTypeQuestionDto = {
  __typename?: 'ResponseBaseOfServiceTypeQuestionDto';
  result?: Maybe<ServiceTypeQuestionDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfSpecialistProfileDto = {
  __typename?: 'ResponseBaseOfSpecialistProfileDto';
  result?: Maybe<SpecialistProfileDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfSpecialistRevenueDto = {
  __typename?: 'ResponseBaseOfSpecialistRevenueDto';
  result?: Maybe<SpecialistRevenueDto>;
  status?: Maybe<Scalars['Any']>;
};

export type ResponseBaseOfUserProfileDto = {
  __typename?: 'ResponseBaseOfUserProfileDto';
  result?: Maybe<UserProfileDto>;
  status?: Maybe<Scalars['Any']>;
};

export type S3MultipartUploadUrlsResultDto = {
  __typename?: 'S3MultipartUploadUrlsResultDto';
  objectUrl: Scalars['String'];
  presignedUrls: Array<Scalars['String']>;
  uploadId: Scalars['String'];
};

export type S3SinglepartUploadUrlsResultDto = {
  __typename?: 'S3SinglepartUploadUrlsResultDto';
  objectUrl: Scalars['String'];
  presignedUrl: Scalars['String'];
};

export type ServiceCategoryDto = {
  __typename?: 'ServiceCategoryDto';
  id: Scalars['UUID'];
  logo: Scalars['String'];
  name: Scalars['String'];
};

/** A segment of a collection. */
export type ServiceCategoryDtoCollectionSegment = {
  __typename?: 'ServiceCategoryDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceCategoryDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type ServiceCategoryDtoFilterInput = {
  and?: InputMaybe<Array<ServiceCategoryDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceCategoryDtoFilterInput>>;
};

export type ServiceCategoryDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type ServiceRequestDto = {
  __typename?: 'ServiceRequestDto';
  address: AddressDto;
  basePrice: Scalars['Decimal'];
  cancellationReason?: Maybe<CancellationReasonDto>;
  customer: CustomerDto;
  description?: Maybe<Scalars['String']>;
  discountAmount: Scalars['Decimal'];
  finalPrice: Scalars['Decimal'];
  id: Scalars['UUID'];
  qnAs: Array<ServiceRequestQnADto>;
  rateAndReview?: Maybe<RateAndReviewDto>;
  requestDate: Scalars['DateTime'];
  serviceType: ServiceTypeDto;
  specialist?: Maybe<SpecialistDto>;
  status: ServiceRequestStatus;
};

/** A segment of a collection. */
export type ServiceRequestDtoCollectionSegment = {
  __typename?: 'ServiceRequestDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceRequestDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type ServiceRequestDtoFilterInput = {
  address?: InputMaybe<AddressDtoFilterInput>;
  and?: InputMaybe<Array<ServiceRequestDtoFilterInput>>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  cancellationReason?: InputMaybe<CancellationReasonDtoFilterInput>;
  customer?: InputMaybe<CustomerDtoFilterInput>;
  description?: InputMaybe<StringOperationFilterInput>;
  discountAmount?: InputMaybe<DecimalOperationFilterInput>;
  finalPrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<ServiceRequestDtoFilterInput>>;
  qnAs?: InputMaybe<ListFilterInputTypeOfServiceRequestQnADtoFilterInput>;
  rateAndReview?: InputMaybe<RateAndReviewDtoFilterInput>;
  requestDate?: InputMaybe<DateTimeOperationFilterInput>;
  serviceType?: InputMaybe<ServiceTypeDtoFilterInput>;
  specialist?: InputMaybe<SpecialistDtoFilterInput>;
  status?: InputMaybe<ServiceRequestStatusOperationFilterInput>;
};

export type ServiceRequestDtoSortInput = {
  address?: InputMaybe<AddressDtoSortInput>;
  basePrice?: InputMaybe<SortEnumType>;
  cancellationReason?: InputMaybe<CancellationReasonDtoSortInput>;
  customer?: InputMaybe<CustomerDtoSortInput>;
  description?: InputMaybe<SortEnumType>;
  discountAmount?: InputMaybe<SortEnumType>;
  finalPrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  rateAndReview?: InputMaybe<RateAndReviewDtoSortInput>;
  requestDate?: InputMaybe<SortEnumType>;
  serviceType?: InputMaybe<ServiceTypeDtoSortInput>;
  specialist?: InputMaybe<SpecialistDtoSortInput>;
  status?: InputMaybe<SortEnumType>;
};

export type ServiceRequestQnADto = {
  __typename?: 'ServiceRequestQnADto';
  answer: Scalars['String'];
  questionText: Scalars['String'];
};

export type ServiceRequestQnADtoFilterInput = {
  and?: InputMaybe<Array<ServiceRequestQnADtoFilterInput>>;
  answer?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceRequestQnADtoFilterInput>>;
  questionText?: InputMaybe<StringOperationFilterInput>;
};

export enum ServiceRequestStatus {
  AcceptedBySpecialist = 'ACCEPTED_BY_SPECIALIST',
  Cancelled = 'CANCELLED',
  Paid = 'PAID',
  Pending = 'PENDING',
  PendingPayment = 'PENDING_PAYMENT',
  SpecialistArrivedToLocation = 'SPECIALIST_ARRIVED_TO_LOCATION'
}

export type ServiceRequestStatusOperationFilterInput = {
  eq?: InputMaybe<ServiceRequestStatus>;
  in?: InputMaybe<Array<ServiceRequestStatus>>;
  neq?: InputMaybe<ServiceRequestStatus>;
  nin?: InputMaybe<Array<ServiceRequestStatus>>;
};

export type ServiceSubCategoryDto = {
  __typename?: 'ServiceSubCategoryDto';
  id: Scalars['UUID'];
  logo: Scalars['String'];
  name: Scalars['String'];
  serviceCategory: ServiceCategoryDto;
};

/** A segment of a collection. */
export type ServiceSubCategoryDtoCollectionSegment = {
  __typename?: 'ServiceSubCategoryDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceSubCategoryDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type ServiceSubCategoryDtoFilterInput = {
  and?: InputMaybe<Array<ServiceSubCategoryDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceSubCategoryDtoFilterInput>>;
  serviceCategory?: InputMaybe<ServiceCategoryDtoFilterInput>;
};

export type ServiceSubCategoryDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  serviceCategory?: InputMaybe<ServiceCategoryDtoSortInput>;
};

export type ServiceTypeDto = {
  __typename?: 'ServiceTypeDto';
  basePrice: Scalars['Decimal'];
  id: Scalars['UUID'];
  isSpecial: Scalars['Boolean'];
  logo: Scalars['String'];
  name: Scalars['String'];
  serviceSubCategory: ServiceSubCategoryDto;
};

/** A segment of a collection. */
export type ServiceTypeDtoCollectionSegment = {
  __typename?: 'ServiceTypeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceTypeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type ServiceTypeDtoFilterInput = {
  and?: InputMaybe<Array<ServiceTypeDtoFilterInput>>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isSpecial?: InputMaybe<BooleanOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceTypeDtoFilterInput>>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
};

export type ServiceTypeDtoSortInput = {
  basePrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isSpecial?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoSortInput>;
};

export type ServiceTypeQuestionDto = {
  __typename?: 'ServiceTypeQuestionDto';
  id: Scalars['UUID'];
  options: Array<Scalars['String']>;
  questionType: QuestionType;
  text: Scalars['String'];
};

/** A segment of a collection. */
export type ServiceTypeQuestionDtoCollectionSegment = {
  __typename?: 'ServiceTypeQuestionDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceTypeQuestionDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type ServiceTypeQuestionDtoFilterInput = {
  and?: InputMaybe<Array<ServiceTypeQuestionDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  options?: InputMaybe<ListStringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceTypeQuestionDtoFilterInput>>;
  questionType?: InputMaybe<QuestionTypeOperationFilterInput>;
  text?: InputMaybe<StringOperationFilterInput>;
};

export type ServiceTypeQuestionDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  questionType?: InputMaybe<SortEnumType>;
  text?: InputMaybe<SortEnumType>;
};

export type SetActiveBannerInput = {
  bannerId?: InputMaybe<Scalars['UUID']>;
  cityId: Scalars['UUID'];
};

export type SetActiveCarouselInput = {
  carouselId?: InputMaybe<Scalars['UUID']>;
  cityId: Scalars['UUID'];
};

export type SetLocationAndSpecialtyInput = {
  cityId: Scalars['UUID'];
  serviceSubCategoryId: Scalars['UUID'];
  serviceTypeIds: Array<Scalars['UUID']>;
};

export type SetPersonalInformationInput = {
  birthDate: Scalars['DateTime'];
  firstName: Scalars['String'];
  gender: Gender;
  idCardImageUrl?: InputMaybe<Scalars['String']>;
  lastName: Scalars['String'];
  nationalCode: Scalars['String'];
  profileImageUrl?: InputMaybe<Scalars['String']>;
};

export type SetPrimaryAddressInput = {
  addressId: Scalars['UUID'];
};

export enum SortEnumType {
  Asc = 'ASC',
  Desc = 'DESC'
}

export type SpecialistDto = {
  __typename?: 'SpecialistDto';
  averageRating: Scalars['Float'];
  code: Scalars['String'];
  firstName?: Maybe<Scalars['String']>;
  gender: Gender;
  id: Scalars['UUID'];
  lastName?: Maybe<Scalars['String']>;
  phoneNumber: Scalars['String'];
  profileImageUrl?: Maybe<Scalars['String']>;
  rateCount: Scalars['Int'];
};

export type SpecialistDtoFilterInput = {
  and?: InputMaybe<Array<SpecialistDtoFilterInput>>;
  averageRating?: InputMaybe<FloatOperationFilterInput>;
  code?: InputMaybe<StringOperationFilterInput>;
  firstName?: InputMaybe<StringOperationFilterInput>;
  gender?: InputMaybe<GenderOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  lastName?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<SpecialistDtoFilterInput>>;
  phoneNumber?: InputMaybe<StringOperationFilterInput>;
  profileImageUrl?: InputMaybe<StringOperationFilterInput>;
  rateCount?: InputMaybe<IntOperationFilterInput>;
};

export type SpecialistDtoSortInput = {
  averageRating?: InputMaybe<SortEnumType>;
  code?: InputMaybe<SortEnumType>;
  firstName?: InputMaybe<SortEnumType>;
  gender?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  lastName?: InputMaybe<SortEnumType>;
  phoneNumber?: InputMaybe<SortEnumType>;
  profileImageUrl?: InputMaybe<SortEnumType>;
  rateCount?: InputMaybe<SortEnumType>;
};

export type SpecialistProfileDto = {
  __typename?: 'SpecialistProfileDto';
  averageRating: Scalars['Float'];
  birthDate: Scalars['DateTime'];
  city?: Maybe<CityDto>;
  daysRegistered: Scalars['Int'];
  firstName?: Maybe<Scalars['String']>;
  gender: Gender;
  id: Scalars['UUID'];
  idCardImageUrl?: Maybe<Scalars['String']>;
  idCardVerificationStatus: VerificationStatus;
  identityVerificationVideoStatus: VerificationStatus;
  identityVerificationVideoUrl?: Maybe<Scalars['String']>;
  lastName?: Maybe<Scalars['String']>;
  nationalCode?: Maybe<Scalars['String']>;
  phoneNumber: Scalars['String'];
  profileImageUrl?: Maybe<Scalars['String']>;
  rateCount: Scalars['Int'];
  serviceSubCategory?: Maybe<ServiceSubCategoryDto>;
  serviceTypes: Array<ServiceTypeDto>;
  specializedDocumentUrls?: Maybe<Array<Scalars['String']>>;
  specializedDocumentsVerificationStatus: VerificationStatus;
  successfulMissions: Scalars['Int'];
};

/** A segment of a collection. */
export type SpecialistProfileDtoCollectionSegment = {
  __typename?: 'SpecialistProfileDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<SpecialistProfileDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int'];
};

export type SpecialistProfileDtoFilterInput = {
  and?: InputMaybe<Array<SpecialistProfileDtoFilterInput>>;
  averageRating?: InputMaybe<FloatOperationFilterInput>;
  birthDate?: InputMaybe<DateTimeOperationFilterInput>;
  city?: InputMaybe<CityDtoFilterInput>;
  daysRegistered?: InputMaybe<IntOperationFilterInput>;
  firstName?: InputMaybe<StringOperationFilterInput>;
  gender?: InputMaybe<GenderOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  idCardImageUrl?: InputMaybe<StringOperationFilterInput>;
  idCardVerificationStatus?: InputMaybe<VerificationStatusOperationFilterInput>;
  identityVerificationVideoStatus?: InputMaybe<VerificationStatusOperationFilterInput>;
  identityVerificationVideoUrl?: InputMaybe<StringOperationFilterInput>;
  lastName?: InputMaybe<StringOperationFilterInput>;
  nationalCode?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<SpecialistProfileDtoFilterInput>>;
  phoneNumber?: InputMaybe<StringOperationFilterInput>;
  profileImageUrl?: InputMaybe<StringOperationFilterInput>;
  rateCount?: InputMaybe<IntOperationFilterInput>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
  serviceTypes?: InputMaybe<ListFilterInputTypeOfServiceTypeDtoFilterInput>;
  specializedDocumentUrls?: InputMaybe<ListStringOperationFilterInput>;
  specializedDocumentsVerificationStatus?: InputMaybe<VerificationStatusOperationFilterInput>;
  successfulMissions?: InputMaybe<IntOperationFilterInput>;
};

export type SpecialistProfileDtoSortInput = {
  averageRating?: InputMaybe<SortEnumType>;
  birthDate?: InputMaybe<SortEnumType>;
  city?: InputMaybe<CityDtoSortInput>;
  daysRegistered?: InputMaybe<SortEnumType>;
  firstName?: InputMaybe<SortEnumType>;
  gender?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  idCardImageUrl?: InputMaybe<SortEnumType>;
  idCardVerificationStatus?: InputMaybe<SortEnumType>;
  identityVerificationVideoStatus?: InputMaybe<SortEnumType>;
  identityVerificationVideoUrl?: InputMaybe<SortEnumType>;
  lastName?: InputMaybe<SortEnumType>;
  nationalCode?: InputMaybe<SortEnumType>;
  phoneNumber?: InputMaybe<SortEnumType>;
  profileImageUrl?: InputMaybe<SortEnumType>;
  rateCount?: InputMaybe<SortEnumType>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoSortInput>;
  specializedDocumentsVerificationStatus?: InputMaybe<SortEnumType>;
  successfulMissions?: InputMaybe<SortEnumType>;
};

export type SpecialistRevenueDto = {
  __typename?: 'SpecialistRevenueDto';
  payments: Array<PaymentDto>;
  paymentsCount: Scalars['Int'];
  specialist: SpecialistDto;
  totalAmount: Scalars['Decimal'];
};

export type StringOperationFilterInput = {
  and?: InputMaybe<Array<StringOperationFilterInput>>;
  contains?: InputMaybe<Scalars['String']>;
  endsWith?: InputMaybe<Scalars['String']>;
  eq?: InputMaybe<Scalars['String']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['String']>>>;
  ncontains?: InputMaybe<Scalars['String']>;
  nendsWith?: InputMaybe<Scalars['String']>;
  neq?: InputMaybe<Scalars['String']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['String']>>>;
  nstartsWith?: InputMaybe<Scalars['String']>;
  or?: InputMaybe<Array<StringOperationFilterInput>>;
  startsWith?: InputMaybe<Scalars['String']>;
};

export type UpdateAddressInput = {
  addressId: Scalars['UUID'];
  newLatitude: Scalars['Float'];
  newLongitude: Scalars['Float'];
  newText: Scalars['String'];
};

export type UpdateBannerInput = {
  id: Scalars['UUID'];
  imageUrl: Scalars['String'];
  title: Scalars['String'];
};

export type UpdateCancellationReasonInput = {
  id: Scalars['UUID'];
  name: Scalars['String'];
};

export type UpdateCarouselInput = {
  id: Scalars['UUID'];
  imageUrls: Array<Scalars['String']>;
  title: Scalars['String'];
};

export type UpdateCityInput = {
  cityId: Scalars['UUID'];
  newName: Scalars['String'];
};

export type UpdateIdentityVerificationVideoInput = {
  newVideoUrl: Scalars['String'];
};

export type UpdateNeighborhoodInput = {
  neighborhoodId: Scalars['UUID'];
  newName: Scalars['String'];
};

export type UpdateProvinceInput = {
  id: Scalars['UUID'];
  name: Scalars['String'];
};

export type UpdateServiceCategoryInput = {
  newLogo: Scalars['String'];
  newName: Scalars['String'];
  serviceCategoryId: Scalars['UUID'];
};

export type UpdateServiceSubCategoryInput = {
  newLogo: Scalars['String'];
  newName: Scalars['String'];
  serviceSubCategoryId: Scalars['UUID'];
};

export type UpdateServiceTypeInput = {
  basePrice: Scalars['Decimal'];
  id: Scalars['UUID'];
  isSpecial: Scalars['Boolean'];
  newLogo: Scalars['String'];
  newName: Scalars['String'];
};

export type UpdateServiceTypeQuestionInput = {
  id: Scalars['UUID'];
  isRequired: Scalars['Boolean'];
  options: Array<Scalars['String']>;
  questionType: QuestionType;
  title: Scalars['String'];
};

export type UpdateSpecializedDocumentsInput = {
  newDocumentUrls: Array<Scalars['String']>;
};

export type UpdateUserProfileInput = {
  firstName: Scalars['String'];
  gender: Gender;
  lastName: Scalars['String'];
  profileImageUrl?: InputMaybe<Scalars['String']>;
};

export type UserProfileDto = {
  __typename?: 'UserProfileDto';
  code: Scalars['String'];
  firstName?: Maybe<Scalars['String']>;
  gender: Gender;
  id: Scalars['UUID'];
  lastName?: Maybe<Scalars['String']>;
  phoneNumber: Scalars['String'];
  profileImageUrl?: Maybe<Scalars['String']>;
};

export enum UserType {
  Admin = 'ADMIN',
  Customer = 'CUSTOMER',
  Owner = 'OWNER',
  Specialist = 'SPECIALIST'
}

export type UuidOperationFilterInput = {
  eq?: InputMaybe<Scalars['UUID']>;
  gt?: InputMaybe<Scalars['UUID']>;
  gte?: InputMaybe<Scalars['UUID']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['UUID']>>>;
  lt?: InputMaybe<Scalars['UUID']>;
  lte?: InputMaybe<Scalars['UUID']>;
  neq?: InputMaybe<Scalars['UUID']>;
  ngt?: InputMaybe<Scalars['UUID']>;
  ngte?: InputMaybe<Scalars['UUID']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['UUID']>>>;
  nlt?: InputMaybe<Scalars['UUID']>;
  nlte?: InputMaybe<Scalars['UUID']>;
};

export enum VerificationStatus {
  Approved = 'APPROVED',
  Pending = 'PENDING',
  Rejected = 'REJECTED'
}

export type VerificationStatusOperationFilterInput = {
  eq?: InputMaybe<VerificationStatus>;
  in?: InputMaybe<Array<VerificationStatus>>;
  neq?: InputMaybe<VerificationStatus>;
  nin?: InputMaybe<Array<VerificationStatus>>;
};

export type VerifyIdCardInput = {
  specialistId: Scalars['UUID'];
  status: VerificationStatus;
};

export type VerifyIdentityVerificationVideoInput = {
  specialistId: Scalars['UUID'];
  status: VerificationStatus;
};

export type VerifyOtpInput = {
  otp: Scalars['String'];
  phoneNumber: Scalars['String'];
  userType: UserType;
};

export type VerifySpecializedDocumentsInput = {
  specialistId: Scalars['UUID'];
  status: VerificationStatus;
};

export type Banner_CreateMutationVariables = Exact<{
  input: CreateBannerInput;
}>;


export type Banner_CreateMutation = { __typename?: 'Mutation', banner_create: { __typename?: 'ResponseBaseOfBannerDto', status?: any | null, result?: { __typename?: 'BannerDto', id: any, title: string, imageUrl: string } | null } };

export type Banner_UpdateMutationVariables = Exact<{
  input: UpdateBannerInput;
}>;


export type Banner_UpdateMutation = { __typename?: 'Mutation', banner_update: { __typename?: 'ResponseBaseOfBannerDto', status?: any | null, result?: { __typename?: 'BannerDto', id: any, title: string, imageUrl: string } | null } };

export type Banner_DeleteMutationVariables = Exact<{
  input: DeleteBannerInput;
}>;


export type Banner_DeleteMutation = { __typename?: 'Mutation', banner_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type Banner_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<BannerDtoFilterInput>;
  order?: InputMaybe<Array<BannerDtoSortInput> | BannerDtoSortInput>;
}>;


export type Banner_GetAllQuery = { __typename?: 'Query', banner_getAll: { __typename?: 'ListResponseBaseOfBannerDto', status?: any | null, result?: { __typename?: 'BannerDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'BannerDto', id: any, imageUrl: string, title: string }> | null } | null } };

export type City_SetActiveBannerMutationVariables = Exact<{
  input: SetActiveBannerInput;
}>;


export type City_SetActiveBannerMutation = { __typename?: 'Mutation', city_setActiveBanner: { __typename?: 'ResponseBaseOfCityDto', status?: any | null } };

export type City_SetActiveCarouselMutationVariables = Exact<{
  input: SetActiveCarouselInput;
}>;


export type City_SetActiveCarouselMutation = { __typename?: 'Mutation', city_setActiveCarousel: { __typename?: 'ResponseBaseOfCityDto', status?: any | null } };

export type Carousel_CreateMutationVariables = Exact<{
  input: CreateCarouselInput;
}>;


export type Carousel_CreateMutation = { __typename?: 'Mutation', carousel_create: { __typename?: 'ResponseBaseOfCarouselDto', status?: any | null, result?: { __typename?: 'CarouselDto', id: any, title: string, imageUrls: Array<string> } | null } };

export type Carousel_UpdateMutationVariables = Exact<{
  input: UpdateCarouselInput;
}>;


export type Carousel_UpdateMutation = { __typename?: 'Mutation', carousel_update: { __typename?: 'ResponseBaseOfCarouselDto', status?: any | null, result?: { __typename?: 'CarouselDto', id: any, title: string, imageUrls: Array<string> } | null } };

export type Carousel_DeleteMutationVariables = Exact<{
  input: DeleteCarouselInput;
}>;


export type Carousel_DeleteMutation = { __typename?: 'Mutation', carousel_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type Carousel_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CarouselDtoFilterInput>;
  order?: InputMaybe<Array<CarouselDtoSortInput> | CarouselDtoSortInput>;
}>;


export type Carousel_GetAllQuery = { __typename?: 'Query', carousel_getAll: { __typename?: 'ListResponseBaseOfCarouselDto', status?: any | null, result?: { __typename?: 'CarouselDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'CarouselDto', id: any, imageUrls: Array<string>, title: string }> | null } | null } };

export type City_CreateCityMutationVariables = Exact<{
  input: CreateCityInput;
}>;


export type City_CreateCityMutation = { __typename?: 'Mutation', city_create: { __typename?: 'ResponseBaseOfCityDto', status?: any | null } };

export type CreateProvinceMutationVariables = Exact<{
  input: CreateProvinceInput;
}>;


export type CreateProvinceMutation = { __typename?: 'Mutation', province_create: { __typename?: 'ResponseBaseOfProvinceDto', status?: any | null, result?: { __typename?: 'ProvinceDto', id: any, name: string } | null } };

export type City_ActivateMutationVariables = Exact<{
  input: ActivateCityInput;
}>;


export type City_ActivateMutation = { __typename?: 'Mutation', city_activate: { __typename?: 'ResponseBaseOfCityDto', status?: any | null } };

export type City_DeactivateMutationVariables = Exact<{
  input: DeactivateCityInput;
}>;


export type City_DeactivateMutation = { __typename?: 'Mutation', city_deactivate: { __typename?: 'ResponseBaseOfCityDto', status?: any | null } };

export type City_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CityDtoFilterInput>;
  order?: InputMaybe<Array<CityDtoSortInput> | CityDtoSortInput>;
}>;


export type City_GetAllQuery = { __typename?: 'Query', city_getAll: { __typename?: 'ListResponseBaseOfCityDto', result?: { __typename?: 'CityDtoCollectionSegment', items?: Array<{ __typename?: 'CityDto', id: any, name: string, isActive: boolean, province: { __typename?: 'ProvinceDto', id: any, name: string }, activeBanner?: { __typename?: 'BannerDto', id: any, title: string, imageUrl: string } | null, activeCarousel?: { __typename?: 'CarouselDto', id: any, imageUrls: Array<string>, title: string } | null }> | null } | null } };

export type City_UpdateCityMutationVariables = Exact<{
  input: UpdateCityInput;
}>;


export type City_UpdateCityMutation = { __typename?: 'Mutation', city_update: { __typename?: 'ResponseBaseOfCityDto', status?: any | null } };

export type ProvincesQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ProvinceDtoFilterInput>;
  order?: InputMaybe<Array<ProvinceDtoSortInput> | ProvinceDtoSortInput>;
}>;


export type ProvincesQuery = { __typename?: 'Query', province_getAll: { __typename?: 'ListResponseBaseOfProvinceDto', result?: { __typename?: 'ProvinceDtoCollectionSegment', items?: Array<{ __typename?: 'ProvinceDto', name: string, id: any }> | null } | null } };

export type Province_UpdateMutationVariables = Exact<{
  input: UpdateProvinceInput;
}>;


export type Province_UpdateMutation = { __typename?: 'Mutation', province_update: { __typename?: 'ResponseBaseOfProvinceDto', status?: any | null, result?: { __typename?: 'ProvinceDto', id: any, name: string } | null } };

export type Province_DeleteMutationVariables = Exact<{
  input: DeleteProvinceInput;
}>;


export type Province_DeleteMutation = { __typename?: 'Mutation', province_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type Customer_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<CustomerDtoFilterInput>;
  order?: InputMaybe<Array<CustomerDtoSortInput> | CustomerDtoSortInput>;
}>;


export type Customer_GetAllQuery = { __typename?: 'Query', customer_getAll: { __typename?: 'ListResponseBaseOfCustomerDto', status?: any | null, result?: { __typename?: 'CustomerDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'CustomerDto', code: string, firstName?: string | null, gender: Gender, id: any, lastName?: string | null, phoneNumber: string, profileImageUrl?: string | null }> | null } | null } };

export type Auth_RequestOtpMutationVariables = Exact<{
  input: RequestOtpInput;
}>;


export type Auth_RequestOtpMutation = { __typename?: 'Mutation', auth_requestOtp: { __typename?: 'ResponseBase', status?: any | null } };

export type Auth_VerifyOtpMutationVariables = Exact<{
  input: VerifyOtpInput;
}>;


export type Auth_VerifyOtpMutation = { __typename?: 'Mutation', auth_verifyOtp: { __typename?: 'ResponseBaseOfAuthResult', status?: any | null, result?: { __typename?: 'AuthResult', accessToken: string, refreshToken: string } | null } };

export type Auth_RefreshTokenMutationVariables = Exact<{
  input: RefreshTokenRequestInput;
}>;


export type Auth_RefreshTokenMutation = { __typename?: 'Mutation', auth_refreshToken: { __typename?: 'ResponseBaseOfAuthResult', status?: any | null, result?: { __typename?: 'AuthResult', accessToken: string, refreshToken: string } | null } };

export type Neighborhood_CreateMutationVariables = Exact<{
  input: CreateNeighborhoodInput;
}>;


export type Neighborhood_CreateMutation = { __typename?: 'Mutation', neighborhood_create: { __typename?: 'ResponseBaseOfNeighborhoodDto', status?: any | null, result?: { __typename?: 'NeighborhoodDto', id: any, name: string } | null } };

export type Neighborhood_UpdateMutationVariables = Exact<{
  input: UpdateNeighborhoodInput;
}>;


export type Neighborhood_UpdateMutation = { __typename?: 'Mutation', neighborhood_update: { __typename?: 'ResponseBaseOfNeighborhoodDto', status?: any | null, result?: { __typename?: 'NeighborhoodDto', id: any, name: string } | null } };

export type Neighborhood_DeleteMutationVariables = Exact<{
  input: DeleteNeighborhoodInput;
}>;


export type Neighborhood_DeleteMutation = { __typename?: 'Mutation', neighborhood_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type Neighborhood_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<NeighborhoodDtoFilterInput>;
  order?: InputMaybe<Array<NeighborhoodDtoSortInput> | NeighborhoodDtoSortInput>;
}>;


export type Neighborhood_GetAllQuery = { __typename?: 'Query', neighborhood_getAll: { __typename?: 'ListResponseBaseOfNeighborhoodDto', status?: any | null, result?: { __typename?: 'NeighborhoodDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'NeighborhoodDto', id: any, name: string, city: { __typename?: 'CityDto', id: any, name: string } }> | null } | null } };

export type ServiceRequest_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceRequestDtoFilterInput>;
  order?: InputMaybe<Array<ServiceRequestDtoSortInput> | ServiceRequestDtoSortInput>;
}>;


export type ServiceRequest_GetAllQuery = { __typename?: 'Query', serviceRequest_getAll: { __typename?: 'ListResponseBaseOfServiceRequestDto', status?: any | null, result?: { __typename?: 'ServiceRequestDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceRequestDto', basePrice: any, description?: string | null, discountAmount: any, finalPrice: any, id: any, requestDate: any, status: ServiceRequestStatus, address: { __typename?: 'AddressDto', text: string, neighborhood: { __typename?: 'NeighborhoodDto', name: string, id: any, city: { __typename?: 'CityDto', id: any, name: string, province: { __typename?: 'ProvinceDto', name: string, id: any } } } }, cancellationReason?: { __typename?: 'CancellationReasonDto', id: any, name: string } | null, customer: { __typename?: 'CustomerDto', firstName?: string | null, id: any, lastName?: string | null, phoneNumber: string, profileImageUrl?: string | null }, specialist?: { __typename?: 'SpecialistDto', firstName?: string | null, id: any, lastName?: string | null, averageRating: number, rateCount: number, phoneNumber: string, profileImageUrl?: string | null } | null, serviceType: { __typename?: 'ServiceTypeDto', id: any, name: string, logo: string, serviceSubCategory: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any, name: string } } } }> | null } | null } };

export type S3_GeneratePresignedUrlMutationVariables = Exact<{
  input: GeneratePresignedUrlInput;
}>;


export type S3_GeneratePresignedUrlMutation = { __typename?: 'Mutation', s3_generatePresignedUrl: { __typename?: 'ResponseBaseOfS3SinglepartUploadUrlsResultDto', status?: any | null, result?: { __typename?: 'S3SinglepartUploadUrlsResultDto', presignedUrl: string, objectUrl: string } | null } };

export type S3_GeneratePresignedUrlsMutationVariables = Exact<{
  input: GenerateMultipartPresignedUrlsInput;
}>;


export type S3_GeneratePresignedUrlsMutation = { __typename?: 'Mutation', s3_generatePresignedUrls: { __typename?: 'ResponseBaseOfS3MultipartUploadUrlsResultDto', status?: any | null, result?: { __typename?: 'S3MultipartUploadUrlsResultDto', uploadId: string, presignedUrls: Array<string>, objectUrl: string } | null } };

export type S3_CompleteMultipartUploadMutationVariables = Exact<{
  input: CompleteMultipartUploadInput;
}>;


export type S3_CompleteMultipartUploadMutation = { __typename?: 'Mutation', s3_completeMultipartUpload: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceCategory_CreateServiceCategoryMutationVariables = Exact<{
  input: CreateServiceCategoryInput;
}>;


export type ServiceCategory_CreateServiceCategoryMutation = { __typename?: 'Mutation', serviceCategory_create: { __typename?: 'ResponseBaseOfServiceCategoryDto', status?: any | null, result?: { __typename?: 'ServiceCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceCategory_UpdateServiceCategoryMutationVariables = Exact<{
  input: UpdateServiceCategoryInput;
}>;


export type ServiceCategory_UpdateServiceCategoryMutation = { __typename?: 'Mutation', serviceCategory_update: { __typename?: 'ResponseBaseOfServiceCategoryDto', status?: any | null, result?: { __typename?: 'ServiceCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceCategory_DeleteServiceCategoryMutationVariables = Exact<{
  input: DeleteServiceCategoryInput;
}>;


export type ServiceCategory_DeleteServiceCategoryMutation = { __typename?: 'Mutation', serviceCategory_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceCategory_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceCategoryDtoFilterInput>;
  order?: InputMaybe<Array<ServiceCategoryDtoSortInput> | ServiceCategoryDtoSortInput>;
}>;


export type ServiceCategory_GetAllQuery = { __typename?: 'Query', serviceCategory_getAll: { __typename?: 'ListResponseBaseOfServiceCategoryDto', status?: any | null, result?: { __typename?: 'ServiceCategoryDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceCategoryDto', id: any, name: string, logo: string }> | null } | null } };

export type Specialist_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<SpecialistProfileDtoFilterInput>;
  order?: InputMaybe<Array<SpecialistProfileDtoSortInput> | SpecialistProfileDtoSortInput>;
}>;


export type Specialist_GetAllQuery = { __typename?: 'Query', specialist_getAll: { __typename?: 'ListResponseBaseOfSpecialistProfileDto', status?: any | null, result?: { __typename?: 'SpecialistProfileDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'SpecialistProfileDto', phoneNumber: string, nationalCode?: string | null, profileImageUrl?: string | null, gender: Gender, birthDate: any, rateCount: number, averageRating: number, daysRegistered: number, successfulMissions: number, firstName?: string | null, id: any, idCardImageUrl?: string | null, identityVerificationVideoStatus: VerificationStatus, idCardVerificationStatus: VerificationStatus, identityVerificationVideoUrl?: string | null, lastName?: string | null, specializedDocumentsVerificationStatus: VerificationStatus, specializedDocumentUrls?: Array<string> | null, city?: { __typename?: 'CityDto', id: any, name: string } | null, serviceTypes: Array<{ __typename?: 'ServiceTypeDto', id: any, name: string }> }> | null } | null } };

export type Specialist_VerifyIdCardMutationVariables = Exact<{
  input: VerifyIdCardInput;
}>;


export type Specialist_VerifyIdCardMutation = { __typename?: 'Mutation', specialist_verifyIDCard: { __typename?: 'ResponseBase', status?: any | null } };

export type Specialist_VerifyIdentityVerificationVideoMutationVariables = Exact<{
  input: VerifyIdentityVerificationVideoInput;
}>;


export type Specialist_VerifyIdentityVerificationVideoMutation = { __typename?: 'Mutation', specialist_verifyIdentityVerificationVideo: { __typename?: 'ResponseBase', status?: any | null } };

export type Specialist_VerifySpecializedDocumentsMutationVariables = Exact<{
  input: VerifySpecializedDocumentsInput;
}>;


export type Specialist_VerifySpecializedDocumentsMutation = { __typename?: 'Mutation', specialist_verifySpecializedDocuments: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceSubCategory_CreateMutationVariables = Exact<{
  input: CreateServiceSubCategoryInput;
}>;


export type ServiceSubCategory_CreateMutation = { __typename?: 'Mutation', serviceSubCategory_create: { __typename?: 'ResponseBaseOfServiceSubCategoryDto', status?: any | null, result?: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceSubCategory_UpdateMutationVariables = Exact<{
  input: UpdateServiceSubCategoryInput;
}>;


export type ServiceSubCategory_UpdateMutation = { __typename?: 'Mutation', serviceSubCategory_update: { __typename?: 'ResponseBaseOfServiceSubCategoryDto', status?: any | null, result?: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceSubCategory_DeleteMutationVariables = Exact<{
  input: DeleteServiceSubCategoryInput;
}>;


export type ServiceSubCategory_DeleteMutation = { __typename?: 'Mutation', serviceSubCategory_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceSubCategory_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
  order?: InputMaybe<Array<ServiceSubCategoryDtoSortInput> | ServiceSubCategoryDtoSortInput>;
}>;


export type ServiceSubCategory_GetAllQuery = { __typename?: 'Query', serviceSubCategory_getAll: { __typename?: 'ListResponseBaseOfServiceSubCategoryDto', status?: any | null, result?: { __typename?: 'ServiceSubCategoryDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceSubCategoryDto', id: any, name: string, logo: string, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any, name: string } }> | null } | null } };

export type ServiceType_CreateMutationVariables = Exact<{
  input: CreateServiceTypeInput;
}>;


export type ServiceType_CreateMutation = { __typename?: 'Mutation', serviceType_create: { __typename?: 'ResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDto', id: any, name: string, logo: string } | null } };

export type ServiceType_UpdateMutationVariables = Exact<{
  input: UpdateServiceTypeInput;
}>;


export type ServiceType_UpdateMutation = { __typename?: 'Mutation', serviceType_update: { __typename?: 'ResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDto', id: any, name: string, logo: string } | null } };

export type ServiceType_DeleteMutationVariables = Exact<{
  input: DeleteServiceTypeInput;
}>;


export type ServiceType_DeleteMutation = { __typename?: 'Mutation', serviceType_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceTypes_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']>;
  take?: InputMaybe<Scalars['Int']>;
  where?: InputMaybe<ServiceTypeDtoFilterInput>;
  order?: InputMaybe<Array<ServiceTypeDtoSortInput> | ServiceTypeDtoSortInput>;
}>;


export type ServiceTypes_GetAllQuery = { __typename?: 'Query', serviceTypes_getAll: { __typename?: 'ListResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceTypeDto', id: any, name: string, basePrice: any, logo: string, isSpecial: boolean, serviceSubCategory: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any, name: string } } }> | null } | null } };

export type User_GetMyProfileQueryVariables = Exact<{ [key: string]: never; }>;


export type User_GetMyProfileQuery = { __typename?: 'Query', user_getMyProfile: { __typename?: 'ResponseBaseOfUserProfileDto', status?: any | null, result?: { __typename?: 'UserProfileDto', id: any, phoneNumber: string, firstName?: string | null, lastName?: string | null, profileImageUrl?: string | null, gender: Gender } | null } };


export const Banner_CreateDocument = `
    mutation banner_create($input: CreateBannerInput!) {
  banner_create(input: $input) {
    status
    result {
      id
      title
      imageUrl
    }
  }
}
    `;
export const useBanner_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Banner_CreateMutation, TError, Banner_CreateMutationVariables, TContext>) =>
    useMutation<Banner_CreateMutation, TError, Banner_CreateMutationVariables, TContext>(
      ['banner_create'],
      (variables?: Banner_CreateMutationVariables) => fetcher<Banner_CreateMutation, Banner_CreateMutationVariables>(Banner_CreateDocument, variables)(),
      options
    );
export const Banner_UpdateDocument = `
    mutation banner_update($input: UpdateBannerInput!) {
  banner_update(input: $input) {
    status
    result {
      id
      title
      imageUrl
    }
  }
}
    `;
export const useBanner_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Banner_UpdateMutation, TError, Banner_UpdateMutationVariables, TContext>) =>
    useMutation<Banner_UpdateMutation, TError, Banner_UpdateMutationVariables, TContext>(
      ['banner_update'],
      (variables?: Banner_UpdateMutationVariables) => fetcher<Banner_UpdateMutation, Banner_UpdateMutationVariables>(Banner_UpdateDocument, variables)(),
      options
    );
export const Banner_DeleteDocument = `
    mutation banner_delete($input: DeleteBannerInput!) {
  banner_delete(input: $input) {
    status
  }
}
    `;
export const useBanner_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Banner_DeleteMutation, TError, Banner_DeleteMutationVariables, TContext>) =>
    useMutation<Banner_DeleteMutation, TError, Banner_DeleteMutationVariables, TContext>(
      ['banner_delete'],
      (variables?: Banner_DeleteMutationVariables) => fetcher<Banner_DeleteMutation, Banner_DeleteMutationVariables>(Banner_DeleteDocument, variables)(),
      options
    );
export const Banner_GetAllDocument = `
    query banner_getAll($skip: Int, $take: Int, $where: BannerDtoFilterInput, $order: [BannerDtoSortInput!]) {
  banner_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        imageUrl
        title
      }
      totalCount
    }
    status
  }
}
    `;
export const useBanner_GetAllQuery = <
      TData = Banner_GetAllQuery,
      TError = unknown
    >(
      variables?: Banner_GetAllQueryVariables,
      options?: UseQueryOptions<Banner_GetAllQuery, TError, TData>
    ) =>
    useQuery<Banner_GetAllQuery, TError, TData>(
      variables === undefined ? ['banner_getAll'] : ['banner_getAll', variables],
      fetcher<Banner_GetAllQuery, Banner_GetAllQueryVariables>(Banner_GetAllDocument, variables),
      options
    );
export const useInfiniteBanner_GetAllQuery = <
      TData = Banner_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof Banner_GetAllQueryVariables,
      variables?: Banner_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Banner_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<Banner_GetAllQuery, TError, TData>(
      variables === undefined ? ['banner_getAll.infinite'] : ['banner_getAll.infinite', variables],
      (metaData) => fetcher<Banner_GetAllQuery, Banner_GetAllQueryVariables>(Banner_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const City_SetActiveBannerDocument = `
    mutation city_setActiveBanner($input: SetActiveBannerInput!) {
  city_setActiveBanner(input: $input) {
    status
  }
}
    `;
export const useCity_SetActiveBannerMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_SetActiveBannerMutation, TError, City_SetActiveBannerMutationVariables, TContext>) =>
    useMutation<City_SetActiveBannerMutation, TError, City_SetActiveBannerMutationVariables, TContext>(
      ['city_setActiveBanner'],
      (variables?: City_SetActiveBannerMutationVariables) => fetcher<City_SetActiveBannerMutation, City_SetActiveBannerMutationVariables>(City_SetActiveBannerDocument, variables)(),
      options
    );
export const City_SetActiveCarouselDocument = `
    mutation city_setActiveCarousel($input: SetActiveCarouselInput!) {
  city_setActiveCarousel(input: $input) {
    status
  }
}
    `;
export const useCity_SetActiveCarouselMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_SetActiveCarouselMutation, TError, City_SetActiveCarouselMutationVariables, TContext>) =>
    useMutation<City_SetActiveCarouselMutation, TError, City_SetActiveCarouselMutationVariables, TContext>(
      ['city_setActiveCarousel'],
      (variables?: City_SetActiveCarouselMutationVariables) => fetcher<City_SetActiveCarouselMutation, City_SetActiveCarouselMutationVariables>(City_SetActiveCarouselDocument, variables)(),
      options
    );
export const Carousel_CreateDocument = `
    mutation carousel_create($input: CreateCarouselInput!) {
  carousel_create(input: $input) {
    status
    result {
      id
      title
      imageUrls
    }
  }
}
    `;
export const useCarousel_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Carousel_CreateMutation, TError, Carousel_CreateMutationVariables, TContext>) =>
    useMutation<Carousel_CreateMutation, TError, Carousel_CreateMutationVariables, TContext>(
      ['carousel_create'],
      (variables?: Carousel_CreateMutationVariables) => fetcher<Carousel_CreateMutation, Carousel_CreateMutationVariables>(Carousel_CreateDocument, variables)(),
      options
    );
export const Carousel_UpdateDocument = `
    mutation carousel_update($input: UpdateCarouselInput!) {
  carousel_update(input: $input) {
    status
    result {
      id
      title
      imageUrls
    }
  }
}
    `;
export const useCarousel_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Carousel_UpdateMutation, TError, Carousel_UpdateMutationVariables, TContext>) =>
    useMutation<Carousel_UpdateMutation, TError, Carousel_UpdateMutationVariables, TContext>(
      ['carousel_update'],
      (variables?: Carousel_UpdateMutationVariables) => fetcher<Carousel_UpdateMutation, Carousel_UpdateMutationVariables>(Carousel_UpdateDocument, variables)(),
      options
    );
export const Carousel_DeleteDocument = `
    mutation carousel_delete($input: DeleteCarouselInput!) {
  carousel_delete(input: $input) {
    status
  }
}
    `;
export const useCarousel_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Carousel_DeleteMutation, TError, Carousel_DeleteMutationVariables, TContext>) =>
    useMutation<Carousel_DeleteMutation, TError, Carousel_DeleteMutationVariables, TContext>(
      ['carousel_delete'],
      (variables?: Carousel_DeleteMutationVariables) => fetcher<Carousel_DeleteMutation, Carousel_DeleteMutationVariables>(Carousel_DeleteDocument, variables)(),
      options
    );
export const Carousel_GetAllDocument = `
    query carousel_getAll($skip: Int, $take: Int, $where: CarouselDtoFilterInput, $order: [CarouselDtoSortInput!]) {
  carousel_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        imageUrls
        title
      }
      totalCount
    }
    status
  }
}
    `;
export const useCarousel_GetAllQuery = <
      TData = Carousel_GetAllQuery,
      TError = unknown
    >(
      variables?: Carousel_GetAllQueryVariables,
      options?: UseQueryOptions<Carousel_GetAllQuery, TError, TData>
    ) =>
    useQuery<Carousel_GetAllQuery, TError, TData>(
      variables === undefined ? ['carousel_getAll'] : ['carousel_getAll', variables],
      fetcher<Carousel_GetAllQuery, Carousel_GetAllQueryVariables>(Carousel_GetAllDocument, variables),
      options
    );
export const useInfiniteCarousel_GetAllQuery = <
      TData = Carousel_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof Carousel_GetAllQueryVariables,
      variables?: Carousel_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Carousel_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<Carousel_GetAllQuery, TError, TData>(
      variables === undefined ? ['carousel_getAll.infinite'] : ['carousel_getAll.infinite', variables],
      (metaData) => fetcher<Carousel_GetAllQuery, Carousel_GetAllQueryVariables>(Carousel_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const City_CreateCityDocument = `
    mutation city_createCity($input: CreateCityInput!) {
  city_create(input: $input) {
    status
  }
}
    `;
export const useCity_CreateCityMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_CreateCityMutation, TError, City_CreateCityMutationVariables, TContext>) =>
    useMutation<City_CreateCityMutation, TError, City_CreateCityMutationVariables, TContext>(
      ['city_createCity'],
      (variables?: City_CreateCityMutationVariables) => fetcher<City_CreateCityMutation, City_CreateCityMutationVariables>(City_CreateCityDocument, variables)(),
      options
    );
export const CreateProvinceDocument = `
    mutation createProvince($input: CreateProvinceInput!) {
  province_create(input: $input) {
    status
    result {
      id
      name
    }
  }
}
    `;
export const useCreateProvinceMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<CreateProvinceMutation, TError, CreateProvinceMutationVariables, TContext>) =>
    useMutation<CreateProvinceMutation, TError, CreateProvinceMutationVariables, TContext>(
      ['createProvince'],
      (variables?: CreateProvinceMutationVariables) => fetcher<CreateProvinceMutation, CreateProvinceMutationVariables>(CreateProvinceDocument, variables)(),
      options
    );
export const City_ActivateDocument = `
    mutation city_activate($input: ActivateCityInput!) {
  city_activate(input: $input) {
    status
  }
}
    `;
export const useCity_ActivateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_ActivateMutation, TError, City_ActivateMutationVariables, TContext>) =>
    useMutation<City_ActivateMutation, TError, City_ActivateMutationVariables, TContext>(
      ['city_activate'],
      (variables?: City_ActivateMutationVariables) => fetcher<City_ActivateMutation, City_ActivateMutationVariables>(City_ActivateDocument, variables)(),
      options
    );
export const City_DeactivateDocument = `
    mutation city_deactivate($input: DeactivateCityInput!) {
  city_deactivate(input: $input) {
    status
  }
}
    `;
export const useCity_DeactivateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_DeactivateMutation, TError, City_DeactivateMutationVariables, TContext>) =>
    useMutation<City_DeactivateMutation, TError, City_DeactivateMutationVariables, TContext>(
      ['city_deactivate'],
      (variables?: City_DeactivateMutationVariables) => fetcher<City_DeactivateMutation, City_DeactivateMutationVariables>(City_DeactivateDocument, variables)(),
      options
    );
export const City_GetAllDocument = `
    query city_getAll($skip: Int, $take: Int, $where: CityDtoFilterInput, $order: [CityDtoSortInput!]) {
  city_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        province {
          id
          name
        }
        name
        isActive
        activeBanner {
          id
          title
          imageUrl
        }
        activeCarousel {
          id
          imageUrls
          title
        }
      }
    }
  }
}
    `;
export const useCity_GetAllQuery = <
      TData = City_GetAllQuery,
      TError = unknown
    >(
      variables?: City_GetAllQueryVariables,
      options?: UseQueryOptions<City_GetAllQuery, TError, TData>
    ) =>
    useQuery<City_GetAllQuery, TError, TData>(
      variables === undefined ? ['city_getAll'] : ['city_getAll', variables],
      fetcher<City_GetAllQuery, City_GetAllQueryVariables>(City_GetAllDocument, variables),
      options
    );
export const useInfiniteCity_GetAllQuery = <
      TData = City_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof City_GetAllQueryVariables,
      variables?: City_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<City_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<City_GetAllQuery, TError, TData>(
      variables === undefined ? ['city_getAll.infinite'] : ['city_getAll.infinite', variables],
      (metaData) => fetcher<City_GetAllQuery, City_GetAllQueryVariables>(City_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const City_UpdateCityDocument = `
    mutation city_updateCity($input: UpdateCityInput!) {
  city_update(input: $input) {
    status
  }
}
    `;
export const useCity_UpdateCityMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_UpdateCityMutation, TError, City_UpdateCityMutationVariables, TContext>) =>
    useMutation<City_UpdateCityMutation, TError, City_UpdateCityMutationVariables, TContext>(
      ['city_updateCity'],
      (variables?: City_UpdateCityMutationVariables) => fetcher<City_UpdateCityMutation, City_UpdateCityMutationVariables>(City_UpdateCityDocument, variables)(),
      options
    );
export const ProvincesDocument = `
    query provinces($skip: Int, $take: Int, $where: ProvinceDtoFilterInput, $order: [ProvinceDtoSortInput!]) {
  province_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        name
        id
      }
    }
  }
}
    `;
export const useProvincesQuery = <
      TData = ProvincesQuery,
      TError = unknown
    >(
      variables?: ProvincesQueryVariables,
      options?: UseQueryOptions<ProvincesQuery, TError, TData>
    ) =>
    useQuery<ProvincesQuery, TError, TData>(
      variables === undefined ? ['provinces'] : ['provinces', variables],
      fetcher<ProvincesQuery, ProvincesQueryVariables>(ProvincesDocument, variables),
      options
    );
export const useInfiniteProvincesQuery = <
      TData = ProvincesQuery,
      TError = unknown
    >(
      pageParamKey: keyof ProvincesQueryVariables,
      variables?: ProvincesQueryVariables,
      options?: UseInfiniteQueryOptions<ProvincesQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<ProvincesQuery, TError, TData>(
      variables === undefined ? ['provinces.infinite'] : ['provinces.infinite', variables],
      (metaData) => fetcher<ProvincesQuery, ProvincesQueryVariables>(ProvincesDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Province_UpdateDocument = `
    mutation province_update($input: UpdateProvinceInput!) {
  province_update(input: $input) {
    status
    result {
      id
      name
    }
  }
}
    `;
export const useProvince_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Province_UpdateMutation, TError, Province_UpdateMutationVariables, TContext>) =>
    useMutation<Province_UpdateMutation, TError, Province_UpdateMutationVariables, TContext>(
      ['province_update'],
      (variables?: Province_UpdateMutationVariables) => fetcher<Province_UpdateMutation, Province_UpdateMutationVariables>(Province_UpdateDocument, variables)(),
      options
    );
export const Province_DeleteDocument = `
    mutation province_delete($input: DeleteProvinceInput!) {
  province_delete(input: $input) {
    status
  }
}
    `;
export const useProvince_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Province_DeleteMutation, TError, Province_DeleteMutationVariables, TContext>) =>
    useMutation<Province_DeleteMutation, TError, Province_DeleteMutationVariables, TContext>(
      ['province_delete'],
      (variables?: Province_DeleteMutationVariables) => fetcher<Province_DeleteMutation, Province_DeleteMutationVariables>(Province_DeleteDocument, variables)(),
      options
    );
export const Customer_GetAllDocument = `
    query customer_getAll($skip: Int, $take: Int, $where: CustomerDtoFilterInput, $order: [CustomerDtoSortInput!]) {
  customer_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        code
        firstName
        gender
        id
        lastName
        phoneNumber
        profileImageUrl
      }
      totalCount
    }
    status
  }
}
    `;
export const useCustomer_GetAllQuery = <
      TData = Customer_GetAllQuery,
      TError = unknown
    >(
      variables?: Customer_GetAllQueryVariables,
      options?: UseQueryOptions<Customer_GetAllQuery, TError, TData>
    ) =>
    useQuery<Customer_GetAllQuery, TError, TData>(
      variables === undefined ? ['customer_getAll'] : ['customer_getAll', variables],
      fetcher<Customer_GetAllQuery, Customer_GetAllQueryVariables>(Customer_GetAllDocument, variables),
      options
    );
export const useInfiniteCustomer_GetAllQuery = <
      TData = Customer_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof Customer_GetAllQueryVariables,
      variables?: Customer_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Customer_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<Customer_GetAllQuery, TError, TData>(
      variables === undefined ? ['customer_getAll.infinite'] : ['customer_getAll.infinite', variables],
      (metaData) => fetcher<Customer_GetAllQuery, Customer_GetAllQueryVariables>(Customer_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Auth_RequestOtpDocument = `
    mutation auth_requestOtp($input: RequestOtpInput!) {
  auth_requestOtp(input: $input) {
    status
  }
}
    `;
export const useAuth_RequestOtpMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Auth_RequestOtpMutation, TError, Auth_RequestOtpMutationVariables, TContext>) =>
    useMutation<Auth_RequestOtpMutation, TError, Auth_RequestOtpMutationVariables, TContext>(
      ['auth_requestOtp'],
      (variables?: Auth_RequestOtpMutationVariables) => fetcher<Auth_RequestOtpMutation, Auth_RequestOtpMutationVariables>(Auth_RequestOtpDocument, variables)(),
      options
    );
export const Auth_VerifyOtpDocument = `
    mutation auth_verifyOtp($input: VerifyOtpInput!) {
  auth_verifyOtp(input: $input) {
    status
    result {
      accessToken
      refreshToken
    }
  }
}
    `;
export const useAuth_VerifyOtpMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Auth_VerifyOtpMutation, TError, Auth_VerifyOtpMutationVariables, TContext>) =>
    useMutation<Auth_VerifyOtpMutation, TError, Auth_VerifyOtpMutationVariables, TContext>(
      ['auth_verifyOtp'],
      (variables?: Auth_VerifyOtpMutationVariables) => fetcher<Auth_VerifyOtpMutation, Auth_VerifyOtpMutationVariables>(Auth_VerifyOtpDocument, variables)(),
      options
    );
export const Auth_RefreshTokenDocument = `
    mutation auth_refreshToken($input: RefreshTokenRequestInput!) {
  auth_refreshToken(input: $input) {
    status
    result {
      accessToken
      refreshToken
    }
  }
}
    `;
export const useAuth_RefreshTokenMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Auth_RefreshTokenMutation, TError, Auth_RefreshTokenMutationVariables, TContext>) =>
    useMutation<Auth_RefreshTokenMutation, TError, Auth_RefreshTokenMutationVariables, TContext>(
      ['auth_refreshToken'],
      (variables?: Auth_RefreshTokenMutationVariables) => fetcher<Auth_RefreshTokenMutation, Auth_RefreshTokenMutationVariables>(Auth_RefreshTokenDocument, variables)(),
      options
    );
export const Neighborhood_CreateDocument = `
    mutation neighborhood_create($input: CreateNeighborhoodInput!) {
  neighborhood_create(input: $input) {
    status
    result {
      id
      name
    }
  }
}
    `;
export const useNeighborhood_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Neighborhood_CreateMutation, TError, Neighborhood_CreateMutationVariables, TContext>) =>
    useMutation<Neighborhood_CreateMutation, TError, Neighborhood_CreateMutationVariables, TContext>(
      ['neighborhood_create'],
      (variables?: Neighborhood_CreateMutationVariables) => fetcher<Neighborhood_CreateMutation, Neighborhood_CreateMutationVariables>(Neighborhood_CreateDocument, variables)(),
      options
    );
export const Neighborhood_UpdateDocument = `
    mutation neighborhood_update($input: UpdateNeighborhoodInput!) {
  neighborhood_update(input: $input) {
    status
    result {
      id
      name
    }
  }
}
    `;
export const useNeighborhood_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Neighborhood_UpdateMutation, TError, Neighborhood_UpdateMutationVariables, TContext>) =>
    useMutation<Neighborhood_UpdateMutation, TError, Neighborhood_UpdateMutationVariables, TContext>(
      ['neighborhood_update'],
      (variables?: Neighborhood_UpdateMutationVariables) => fetcher<Neighborhood_UpdateMutation, Neighborhood_UpdateMutationVariables>(Neighborhood_UpdateDocument, variables)(),
      options
    );
export const Neighborhood_DeleteDocument = `
    mutation neighborhood_delete($input: DeleteNeighborhoodInput!) {
  neighborhood_delete(input: $input) {
    status
  }
}
    `;
export const useNeighborhood_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Neighborhood_DeleteMutation, TError, Neighborhood_DeleteMutationVariables, TContext>) =>
    useMutation<Neighborhood_DeleteMutation, TError, Neighborhood_DeleteMutationVariables, TContext>(
      ['neighborhood_delete'],
      (variables?: Neighborhood_DeleteMutationVariables) => fetcher<Neighborhood_DeleteMutation, Neighborhood_DeleteMutationVariables>(Neighborhood_DeleteDocument, variables)(),
      options
    );
export const Neighborhood_GetAllDocument = `
    query neighborhood_getAll($skip: Int, $take: Int, $where: NeighborhoodDtoFilterInput, $order: [NeighborhoodDtoSortInput!]) {
  neighborhood_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        city {
          id
          name
        }
      }
      totalCount
    }
    status
  }
}
    `;
export const useNeighborhood_GetAllQuery = <
      TData = Neighborhood_GetAllQuery,
      TError = unknown
    >(
      variables?: Neighborhood_GetAllQueryVariables,
      options?: UseQueryOptions<Neighborhood_GetAllQuery, TError, TData>
    ) =>
    useQuery<Neighborhood_GetAllQuery, TError, TData>(
      variables === undefined ? ['neighborhood_getAll'] : ['neighborhood_getAll', variables],
      fetcher<Neighborhood_GetAllQuery, Neighborhood_GetAllQueryVariables>(Neighborhood_GetAllDocument, variables),
      options
    );
export const useInfiniteNeighborhood_GetAllQuery = <
      TData = Neighborhood_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof Neighborhood_GetAllQueryVariables,
      variables?: Neighborhood_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Neighborhood_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<Neighborhood_GetAllQuery, TError, TData>(
      variables === undefined ? ['neighborhood_getAll.infinite'] : ['neighborhood_getAll.infinite', variables],
      (metaData) => fetcher<Neighborhood_GetAllQuery, Neighborhood_GetAllQueryVariables>(Neighborhood_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const ServiceRequest_GetAllDocument = `
    query serviceRequest_getAll($skip: Int, $take: Int, $where: ServiceRequestDtoFilterInput, $order: [ServiceRequestDtoSortInput!]) {
  serviceRequest_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        address {
          neighborhood {
            name
            id
            city {
              province {
                name
                id
              }
              id
              name
            }
          }
          text
        }
        basePrice
        cancellationReason {
          id
          name
        }
        customer {
          firstName
          id
          lastName
          phoneNumber
          profileImageUrl
        }
        description
        discountAmount
        finalPrice
        id
        requestDate
        status
        specialist {
          firstName
          id
          lastName
          averageRating
          rateCount
          phoneNumber
          profileImageUrl
        }
        serviceType {
          id
          name
          logo
          serviceSubCategory {
            id
            name
            serviceCategory {
              id
              name
            }
          }
        }
      }
      totalCount
    }
    status
  }
}
    `;
export const useServiceRequest_GetAllQuery = <
      TData = ServiceRequest_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceRequest_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceRequest_GetAllQuery, TError, TData>
    ) =>
    useQuery<ServiceRequest_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceRequest_getAll'] : ['serviceRequest_getAll', variables],
      fetcher<ServiceRequest_GetAllQuery, ServiceRequest_GetAllQueryVariables>(ServiceRequest_GetAllDocument, variables),
      options
    );
export const useInfiniteServiceRequest_GetAllQuery = <
      TData = ServiceRequest_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof ServiceRequest_GetAllQueryVariables,
      variables?: ServiceRequest_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceRequest_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<ServiceRequest_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceRequest_getAll.infinite'] : ['serviceRequest_getAll.infinite', variables],
      (metaData) => fetcher<ServiceRequest_GetAllQuery, ServiceRequest_GetAllQueryVariables>(ServiceRequest_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const S3_GeneratePresignedUrlDocument = `
    mutation s3_generatePresignedUrl($input: GeneratePresignedUrlInput!) {
  s3_generatePresignedUrl(input: $input) {
    status
    result {
      presignedUrl
      objectUrl
    }
  }
}
    `;
export const useS3_GeneratePresignedUrlMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<S3_GeneratePresignedUrlMutation, TError, S3_GeneratePresignedUrlMutationVariables, TContext>) =>
    useMutation<S3_GeneratePresignedUrlMutation, TError, S3_GeneratePresignedUrlMutationVariables, TContext>(
      ['s3_generatePresignedUrl'],
      (variables?: S3_GeneratePresignedUrlMutationVariables) => fetcher<S3_GeneratePresignedUrlMutation, S3_GeneratePresignedUrlMutationVariables>(S3_GeneratePresignedUrlDocument, variables)(),
      options
    );
export const S3_GeneratePresignedUrlsDocument = `
    mutation s3_generatePresignedUrls($input: GenerateMultipartPresignedUrlsInput!) {
  s3_generatePresignedUrls(input: $input) {
    status
    result {
      uploadId
      presignedUrls
      objectUrl
    }
  }
}
    `;
export const useS3_GeneratePresignedUrlsMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<S3_GeneratePresignedUrlsMutation, TError, S3_GeneratePresignedUrlsMutationVariables, TContext>) =>
    useMutation<S3_GeneratePresignedUrlsMutation, TError, S3_GeneratePresignedUrlsMutationVariables, TContext>(
      ['s3_generatePresignedUrls'],
      (variables?: S3_GeneratePresignedUrlsMutationVariables) => fetcher<S3_GeneratePresignedUrlsMutation, S3_GeneratePresignedUrlsMutationVariables>(S3_GeneratePresignedUrlsDocument, variables)(),
      options
    );
export const S3_CompleteMultipartUploadDocument = `
    mutation s3_completeMultipartUpload($input: CompleteMultipartUploadInput!) {
  s3_completeMultipartUpload(input: $input) {
    status
  }
}
    `;
export const useS3_CompleteMultipartUploadMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<S3_CompleteMultipartUploadMutation, TError, S3_CompleteMultipartUploadMutationVariables, TContext>) =>
    useMutation<S3_CompleteMultipartUploadMutation, TError, S3_CompleteMultipartUploadMutationVariables, TContext>(
      ['s3_completeMultipartUpload'],
      (variables?: S3_CompleteMultipartUploadMutationVariables) => fetcher<S3_CompleteMultipartUploadMutation, S3_CompleteMultipartUploadMutationVariables>(S3_CompleteMultipartUploadDocument, variables)(),
      options
    );
export const ServiceCategory_CreateServiceCategoryDocument = `
    mutation serviceCategory_createServiceCategory($input: CreateServiceCategoryInput!) {
  serviceCategory_create(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;
export const useServiceCategory_CreateServiceCategoryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceCategory_CreateServiceCategoryMutation, TError, ServiceCategory_CreateServiceCategoryMutationVariables, TContext>) =>
    useMutation<ServiceCategory_CreateServiceCategoryMutation, TError, ServiceCategory_CreateServiceCategoryMutationVariables, TContext>(
      ['serviceCategory_createServiceCategory'],
      (variables?: ServiceCategory_CreateServiceCategoryMutationVariables) => fetcher<ServiceCategory_CreateServiceCategoryMutation, ServiceCategory_CreateServiceCategoryMutationVariables>(ServiceCategory_CreateServiceCategoryDocument, variables)(),
      options
    );
export const ServiceCategory_UpdateServiceCategoryDocument = `
    mutation serviceCategory_updateServiceCategory($input: UpdateServiceCategoryInput!) {
  serviceCategory_update(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;
export const useServiceCategory_UpdateServiceCategoryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceCategory_UpdateServiceCategoryMutation, TError, ServiceCategory_UpdateServiceCategoryMutationVariables, TContext>) =>
    useMutation<ServiceCategory_UpdateServiceCategoryMutation, TError, ServiceCategory_UpdateServiceCategoryMutationVariables, TContext>(
      ['serviceCategory_updateServiceCategory'],
      (variables?: ServiceCategory_UpdateServiceCategoryMutationVariables) => fetcher<ServiceCategory_UpdateServiceCategoryMutation, ServiceCategory_UpdateServiceCategoryMutationVariables>(ServiceCategory_UpdateServiceCategoryDocument, variables)(),
      options
    );
export const ServiceCategory_DeleteServiceCategoryDocument = `
    mutation serviceCategory_deleteServiceCategory($input: DeleteServiceCategoryInput!) {
  serviceCategory_delete(input: $input) {
    status
  }
}
    `;
export const useServiceCategory_DeleteServiceCategoryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceCategory_DeleteServiceCategoryMutation, TError, ServiceCategory_DeleteServiceCategoryMutationVariables, TContext>) =>
    useMutation<ServiceCategory_DeleteServiceCategoryMutation, TError, ServiceCategory_DeleteServiceCategoryMutationVariables, TContext>(
      ['serviceCategory_deleteServiceCategory'],
      (variables?: ServiceCategory_DeleteServiceCategoryMutationVariables) => fetcher<ServiceCategory_DeleteServiceCategoryMutation, ServiceCategory_DeleteServiceCategoryMutationVariables>(ServiceCategory_DeleteServiceCategoryDocument, variables)(),
      options
    );
export const ServiceCategory_GetAllDocument = `
    query serviceCategory_getAll($skip: Int, $take: Int, $where: ServiceCategoryDtoFilterInput, $order: [ServiceCategoryDtoSortInput!]) {
  serviceCategory_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        logo
      }
      totalCount
    }
    status
  }
}
    `;
export const useServiceCategory_GetAllQuery = <
      TData = ServiceCategory_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceCategory_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceCategory_GetAllQuery, TError, TData>
    ) =>
    useQuery<ServiceCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceCategory_getAll'] : ['serviceCategory_getAll', variables],
      fetcher<ServiceCategory_GetAllQuery, ServiceCategory_GetAllQueryVariables>(ServiceCategory_GetAllDocument, variables),
      options
    );
export const useInfiniteServiceCategory_GetAllQuery = <
      TData = ServiceCategory_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof ServiceCategory_GetAllQueryVariables,
      variables?: ServiceCategory_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceCategory_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<ServiceCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceCategory_getAll.infinite'] : ['serviceCategory_getAll.infinite', variables],
      (metaData) => fetcher<ServiceCategory_GetAllQuery, ServiceCategory_GetAllQueryVariables>(ServiceCategory_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Specialist_GetAllDocument = `
    query specialist_getAll($skip: Int, $take: Int, $where: SpecialistProfileDtoFilterInput, $order: [SpecialistProfileDtoSortInput!]) {
  specialist_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        city {
          id
          name
        }
        phoneNumber
        nationalCode
        profileImageUrl
        gender
        birthDate
        rateCount
        averageRating
        daysRegistered
        successfulMissions
        firstName
        id
        idCardImageUrl
        identityVerificationVideoStatus
        idCardVerificationStatus
        identityVerificationVideoUrl
        lastName
        serviceTypes {
          id
          name
        }
        specializedDocumentsVerificationStatus
        specializedDocumentUrls
      }
      totalCount
    }
    status
  }
}
    `;
export const useSpecialist_GetAllQuery = <
      TData = Specialist_GetAllQuery,
      TError = unknown
    >(
      variables?: Specialist_GetAllQueryVariables,
      options?: UseQueryOptions<Specialist_GetAllQuery, TError, TData>
    ) =>
    useQuery<Specialist_GetAllQuery, TError, TData>(
      variables === undefined ? ['specialist_getAll'] : ['specialist_getAll', variables],
      fetcher<Specialist_GetAllQuery, Specialist_GetAllQueryVariables>(Specialist_GetAllDocument, variables),
      options
    );
export const useInfiniteSpecialist_GetAllQuery = <
      TData = Specialist_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof Specialist_GetAllQueryVariables,
      variables?: Specialist_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Specialist_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<Specialist_GetAllQuery, TError, TData>(
      variables === undefined ? ['specialist_getAll.infinite'] : ['specialist_getAll.infinite', variables],
      (metaData) => fetcher<Specialist_GetAllQuery, Specialist_GetAllQueryVariables>(Specialist_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Specialist_VerifyIdCardDocument = `
    mutation specialist_verifyIDCard($input: VerifyIDCardInput!) {
  specialist_verifyIDCard(input: $input) {
    status
  }
}
    `;
export const useSpecialist_VerifyIdCardMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Specialist_VerifyIdCardMutation, TError, Specialist_VerifyIdCardMutationVariables, TContext>) =>
    useMutation<Specialist_VerifyIdCardMutation, TError, Specialist_VerifyIdCardMutationVariables, TContext>(
      ['specialist_verifyIDCard'],
      (variables?: Specialist_VerifyIdCardMutationVariables) => fetcher<Specialist_VerifyIdCardMutation, Specialist_VerifyIdCardMutationVariables>(Specialist_VerifyIdCardDocument, variables)(),
      options
    );
export const Specialist_VerifyIdentityVerificationVideoDocument = `
    mutation specialist_verifyIdentityVerificationVideo($input: VerifyIdentityVerificationVideoInput!) {
  specialist_verifyIdentityVerificationVideo(input: $input) {
    status
  }
}
    `;
export const useSpecialist_VerifyIdentityVerificationVideoMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Specialist_VerifyIdentityVerificationVideoMutation, TError, Specialist_VerifyIdentityVerificationVideoMutationVariables, TContext>) =>
    useMutation<Specialist_VerifyIdentityVerificationVideoMutation, TError, Specialist_VerifyIdentityVerificationVideoMutationVariables, TContext>(
      ['specialist_verifyIdentityVerificationVideo'],
      (variables?: Specialist_VerifyIdentityVerificationVideoMutationVariables) => fetcher<Specialist_VerifyIdentityVerificationVideoMutation, Specialist_VerifyIdentityVerificationVideoMutationVariables>(Specialist_VerifyIdentityVerificationVideoDocument, variables)(),
      options
    );
export const Specialist_VerifySpecializedDocumentsDocument = `
    mutation specialist_verifySpecializedDocuments($input: VerifySpecializedDocumentsInput!) {
  specialist_verifySpecializedDocuments(input: $input) {
    status
  }
}
    `;
export const useSpecialist_VerifySpecializedDocumentsMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Specialist_VerifySpecializedDocumentsMutation, TError, Specialist_VerifySpecializedDocumentsMutationVariables, TContext>) =>
    useMutation<Specialist_VerifySpecializedDocumentsMutation, TError, Specialist_VerifySpecializedDocumentsMutationVariables, TContext>(
      ['specialist_verifySpecializedDocuments'],
      (variables?: Specialist_VerifySpecializedDocumentsMutationVariables) => fetcher<Specialist_VerifySpecializedDocumentsMutation, Specialist_VerifySpecializedDocumentsMutationVariables>(Specialist_VerifySpecializedDocumentsDocument, variables)(),
      options
    );
export const ServiceSubCategory_CreateDocument = `
    mutation serviceSubCategory_create($input: CreateServiceSubCategoryInput!) {
  serviceSubCategory_create(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;
export const useServiceSubCategory_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceSubCategory_CreateMutation, TError, ServiceSubCategory_CreateMutationVariables, TContext>) =>
    useMutation<ServiceSubCategory_CreateMutation, TError, ServiceSubCategory_CreateMutationVariables, TContext>(
      ['serviceSubCategory_create'],
      (variables?: ServiceSubCategory_CreateMutationVariables) => fetcher<ServiceSubCategory_CreateMutation, ServiceSubCategory_CreateMutationVariables>(ServiceSubCategory_CreateDocument, variables)(),
      options
    );
export const ServiceSubCategory_UpdateDocument = `
    mutation serviceSubCategory_update($input: UpdateServiceSubCategoryInput!) {
  serviceSubCategory_update(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;
export const useServiceSubCategory_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceSubCategory_UpdateMutation, TError, ServiceSubCategory_UpdateMutationVariables, TContext>) =>
    useMutation<ServiceSubCategory_UpdateMutation, TError, ServiceSubCategory_UpdateMutationVariables, TContext>(
      ['serviceSubCategory_update'],
      (variables?: ServiceSubCategory_UpdateMutationVariables) => fetcher<ServiceSubCategory_UpdateMutation, ServiceSubCategory_UpdateMutationVariables>(ServiceSubCategory_UpdateDocument, variables)(),
      options
    );
export const ServiceSubCategory_DeleteDocument = `
    mutation serviceSubCategory_delete($input: DeleteServiceSubCategoryInput!) {
  serviceSubCategory_delete(input: $input) {
    status
  }
}
    `;
export const useServiceSubCategory_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceSubCategory_DeleteMutation, TError, ServiceSubCategory_DeleteMutationVariables, TContext>) =>
    useMutation<ServiceSubCategory_DeleteMutation, TError, ServiceSubCategory_DeleteMutationVariables, TContext>(
      ['serviceSubCategory_delete'],
      (variables?: ServiceSubCategory_DeleteMutationVariables) => fetcher<ServiceSubCategory_DeleteMutation, ServiceSubCategory_DeleteMutationVariables>(ServiceSubCategory_DeleteDocument, variables)(),
      options
    );
export const ServiceSubCategory_GetAllDocument = `
    query serviceSubCategory_getAll($skip: Int, $take: Int, $where: ServiceSubCategoryDtoFilterInput, $order: [ServiceSubCategoryDtoSortInput!]) {
  serviceSubCategory_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        logo
        serviceCategory {
          id
          name
        }
      }
      totalCount
    }
    status
  }
}
    `;
export const useServiceSubCategory_GetAllQuery = <
      TData = ServiceSubCategory_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceSubCategory_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceSubCategory_GetAllQuery, TError, TData>
    ) =>
    useQuery<ServiceSubCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceSubCategory_getAll'] : ['serviceSubCategory_getAll', variables],
      fetcher<ServiceSubCategory_GetAllQuery, ServiceSubCategory_GetAllQueryVariables>(ServiceSubCategory_GetAllDocument, variables),
      options
    );
export const useInfiniteServiceSubCategory_GetAllQuery = <
      TData = ServiceSubCategory_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof ServiceSubCategory_GetAllQueryVariables,
      variables?: ServiceSubCategory_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceSubCategory_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<ServiceSubCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceSubCategory_getAll.infinite'] : ['serviceSubCategory_getAll.infinite', variables],
      (metaData) => fetcher<ServiceSubCategory_GetAllQuery, ServiceSubCategory_GetAllQueryVariables>(ServiceSubCategory_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const ServiceType_CreateDocument = `
    mutation serviceType_create($input: CreateServiceTypeInput!) {
  serviceType_create(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;
export const useServiceType_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceType_CreateMutation, TError, ServiceType_CreateMutationVariables, TContext>) =>
    useMutation<ServiceType_CreateMutation, TError, ServiceType_CreateMutationVariables, TContext>(
      ['serviceType_create'],
      (variables?: ServiceType_CreateMutationVariables) => fetcher<ServiceType_CreateMutation, ServiceType_CreateMutationVariables>(ServiceType_CreateDocument, variables)(),
      options
    );
export const ServiceType_UpdateDocument = `
    mutation serviceType_update($input: UpdateServiceTypeInput!) {
  serviceType_update(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;
export const useServiceType_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceType_UpdateMutation, TError, ServiceType_UpdateMutationVariables, TContext>) =>
    useMutation<ServiceType_UpdateMutation, TError, ServiceType_UpdateMutationVariables, TContext>(
      ['serviceType_update'],
      (variables?: ServiceType_UpdateMutationVariables) => fetcher<ServiceType_UpdateMutation, ServiceType_UpdateMutationVariables>(ServiceType_UpdateDocument, variables)(),
      options
    );
export const ServiceType_DeleteDocument = `
    mutation serviceType_delete($input: DeleteServiceTypeInput!) {
  serviceType_delete(input: $input) {
    status
  }
}
    `;
export const useServiceType_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceType_DeleteMutation, TError, ServiceType_DeleteMutationVariables, TContext>) =>
    useMutation<ServiceType_DeleteMutation, TError, ServiceType_DeleteMutationVariables, TContext>(
      ['serviceType_delete'],
      (variables?: ServiceType_DeleteMutationVariables) => fetcher<ServiceType_DeleteMutation, ServiceType_DeleteMutationVariables>(ServiceType_DeleteDocument, variables)(),
      options
    );
export const ServiceTypes_GetAllDocument = `
    query serviceTypes_getAll($skip: Int, $take: Int, $where: ServiceTypeDtoFilterInput, $order: [ServiceTypeDtoSortInput!]) {
  serviceTypes_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        basePrice
        logo
        isSpecial
        serviceSubCategory {
          id
          name
          serviceCategory {
            id
            name
          }
        }
      }
      totalCount
    }
    status
  }
}
    `;
export const useServiceTypes_GetAllQuery = <
      TData = ServiceTypes_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceTypes_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceTypes_GetAllQuery, TError, TData>
    ) =>
    useQuery<ServiceTypes_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceTypes_getAll'] : ['serviceTypes_getAll', variables],
      fetcher<ServiceTypes_GetAllQuery, ServiceTypes_GetAllQueryVariables>(ServiceTypes_GetAllDocument, variables),
      options
    );
export const useInfiniteServiceTypes_GetAllQuery = <
      TData = ServiceTypes_GetAllQuery,
      TError = unknown
    >(
      pageParamKey: keyof ServiceTypes_GetAllQueryVariables,
      variables?: ServiceTypes_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceTypes_GetAllQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<ServiceTypes_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceTypes_getAll.infinite'] : ['serviceTypes_getAll.infinite', variables],
      (metaData) => fetcher<ServiceTypes_GetAllQuery, ServiceTypes_GetAllQueryVariables>(ServiceTypes_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const User_GetMyProfileDocument = `
    query user_getMyProfile {
  user_getMyProfile {
    status
    result {
      id
      phoneNumber
      firstName
      lastName
      profileImageUrl
      gender
    }
  }
}
    `;
export const useUser_GetMyProfileQuery = <
      TData = User_GetMyProfileQuery,
      TError = unknown
    >(
      variables?: User_GetMyProfileQueryVariables,
      options?: UseQueryOptions<User_GetMyProfileQuery, TError, TData>
    ) =>
    useQuery<User_GetMyProfileQuery, TError, TData>(
      variables === undefined ? ['user_getMyProfile'] : ['user_getMyProfile', variables],
      fetcher<User_GetMyProfileQuery, User_GetMyProfileQueryVariables>(User_GetMyProfileDocument, variables),
      options
    );
export const useInfiniteUser_GetMyProfileQuery = <
      TData = User_GetMyProfileQuery,
      TError = unknown
    >(
      pageParamKey: keyof User_GetMyProfileQueryVariables,
      variables?: User_GetMyProfileQueryVariables,
      options?: UseInfiniteQueryOptions<User_GetMyProfileQuery, TError, TData>
    ) =>{
    
    return useInfiniteQuery<User_GetMyProfileQuery, TError, TData>(
      variables === undefined ? ['user_getMyProfile.infinite'] : ['user_getMyProfile.infinite', variables],
      (metaData) => fetcher<User_GetMyProfileQuery, User_GetMyProfileQueryVariables>(User_GetMyProfileDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};
