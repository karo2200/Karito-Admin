import { useMutation, useQuery, useInfiniteQuery, UseMutationOptions, UseQueryOptions, UseInfiniteQueryOptions } from '@tanstack/react-query';
import { fetcher } from 'src/graphql/fetcher';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
  Any: { input: any; output: any; }
  DateTime: { input: any; output: any; }
  Decimal: { input: any; output: any; }
  Long: { input: any; output: any; }
  UUID: { input: any; output: any; }
};

export type AcceptServiceRequestInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type ActivateCityInput = {
  cityId: Scalars['UUID']['input'];
};

export type ActivateDiscountCodeInput = {
  id: Scalars['UUID']['input'];
};

export type AddAddressInput = {
  buildingNumber: Scalars['Int']['input'];
  customerId: Scalars['UUID']['input'];
  floorNumber: Scalars['Int']['input'];
  latitude: Scalars['Float']['input'];
  longitude: Scalars['Float']['input'];
  text: Scalars['String']['input'];
  title: Scalars['String']['input'];
  unitNumber: Scalars['Int']['input'];
};

export type AddressDto = {
  __typename?: 'AddressDto';
  buildingNumber: Scalars['Int']['output'];
  city: CityDto;
  customer: CustomerDto;
  floorNumber: Scalars['Int']['output'];
  id: Scalars['UUID']['output'];
  isPrimary: Scalars['Boolean']['output'];
  latitude: Scalars['Float']['output'];
  location: Scalars['String']['output'];
  longitude: Scalars['Float']['output'];
  text: Scalars['String']['output'];
  title: Scalars['String']['output'];
  unitNumber: Scalars['Int']['output'];
};

/** A segment of a collection. */
export type AddressDtoCollectionSegment = {
  __typename?: 'AddressDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<AddressDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type AddressDtoFilterInput = {
  and?: InputMaybe<Array<AddressDtoFilterInput>>;
  buildingNumber?: InputMaybe<IntOperationFilterInput>;
  city?: InputMaybe<CityDtoFilterInput>;
  customer?: InputMaybe<CustomerDtoFilterInput>;
  floorNumber?: InputMaybe<IntOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isPrimary?: InputMaybe<BooleanOperationFilterInput>;
  latitude?: InputMaybe<FloatOperationFilterInput>;
  location?: InputMaybe<StringOperationFilterInput>;
  longitude?: InputMaybe<FloatOperationFilterInput>;
  or?: InputMaybe<Array<AddressDtoFilterInput>>;
  text?: InputMaybe<StringOperationFilterInput>;
  title?: InputMaybe<StringOperationFilterInput>;
  unitNumber?: InputMaybe<IntOperationFilterInput>;
};

export type AddressDtoSortInput = {
  buildingNumber?: InputMaybe<SortEnumType>;
  city?: InputMaybe<CityDtoSortInput>;
  customer?: InputMaybe<CustomerDtoSortInput>;
  floorNumber?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isPrimary?: InputMaybe<SortEnumType>;
  latitude?: InputMaybe<SortEnumType>;
  location?: InputMaybe<SortEnumType>;
  longitude?: InputMaybe<SortEnumType>;
  text?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
  unitNumber?: InputMaybe<SortEnumType>;
};

export type AdminDto = {
  __typename?: 'AdminDto';
  code: Scalars['String']['output'];
  firstName?: Maybe<Scalars['String']['output']>;
  gender: Gender;
  id: Scalars['UUID']['output'];
  isBlocked: Scalars['Boolean']['output'];
  isOwner: Scalars['Boolean']['output'];
  lastName?: Maybe<Scalars['String']['output']>;
  phoneNumber: Scalars['String']['output'];
  profileImageUrl?: Maybe<Scalars['String']['output']>;
  registeredAt: Scalars['DateTime']['output'];
};

/** A segment of a collection. */
export type AdminDtoCollectionSegment = {
  __typename?: 'AdminDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<AdminDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type AdminDtoFilterInput = {
  and?: InputMaybe<Array<AdminDtoFilterInput>>;
  code?: InputMaybe<StringOperationFilterInput>;
  firstName?: InputMaybe<StringOperationFilterInput>;
  gender?: InputMaybe<GenderOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isBlocked?: InputMaybe<BooleanOperationFilterInput>;
  isOwner?: InputMaybe<BooleanOperationFilterInput>;
  lastName?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<AdminDtoFilterInput>>;
  phoneNumber?: InputMaybe<StringOperationFilterInput>;
  profileImageUrl?: InputMaybe<StringOperationFilterInput>;
  registeredAt?: InputMaybe<DateTimeOperationFilterInput>;
};

export type AdminDtoSortInput = {
  code?: InputMaybe<SortEnumType>;
  firstName?: InputMaybe<SortEnumType>;
  gender?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isBlocked?: InputMaybe<SortEnumType>;
  isOwner?: InputMaybe<SortEnumType>;
  lastName?: InputMaybe<SortEnumType>;
  phoneNumber?: InputMaybe<SortEnumType>;
  profileImageUrl?: InputMaybe<SortEnumType>;
  registeredAt?: InputMaybe<SortEnumType>;
};

export type ApplyDiscountCodeToServiceRequestInput = {
  discountCode: Scalars['String']['input'];
  serviceRequestId: Scalars['UUID']['input'];
};

/** Defines when a policy shall be executed. */
export enum ApplyPolicy {
  /** After the resolver was executed. */
  AfterResolver = 'AFTER_RESOLVER',
  /** Before the resolver was executed. */
  BeforeResolver = 'BEFORE_RESOLVER',
  /** The policy is applied in the validation step before the execution. */
  Validation = 'VALIDATION'
}

export type AuthResult = {
  __typename?: 'AuthResult';
  accessToken: Scalars['String']['output'];
  refreshToken: Scalars['String']['output'];
};

export type AvailableServiceRequestDto = {
  __typename?: 'AvailableServiceRequestDto';
  address: AddressDto;
  basePrice: Scalars['Decimal']['output'];
  cancellationReason?: Maybe<CancellationReasonDto>;
  customer: CustomerDto;
  customerShare: Scalars['Decimal']['output'];
  description?: Maybe<Scalars['String']['output']>;
  discountAmount: Scalars['Decimal']['output'];
  distance: Scalars['Float']['output'];
  finalPrice: Scalars['Decimal']['output'];
  id: Scalars['UUID']['output'];
  paidAt?: Maybe<Scalars['DateTime']['output']>;
  qnAs: Array<ServiceRequestQnADto>;
  rateAndReview?: Maybe<RateAndReviewDto>;
  requestDate: Scalars['DateTime']['output'];
  serviceType: ServiceTypeDto;
  settledAt?: Maybe<Scalars['DateTime']['output']>;
  specialist?: Maybe<SpecialistDto>;
  specialistGenderRequirement: Gender;
  status: ServiceRequestStatus;
  trackingCode: Scalars['String']['output'];
};

/** A segment of a collection. */
export type AvailableServiceRequestDtoCollectionSegment = {
  __typename?: 'AvailableServiceRequestDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<AvailableServiceRequestDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type AvailableServiceRequestDtoFilterInput = {
  address?: InputMaybe<AddressDtoFilterInput>;
  and?: InputMaybe<Array<AvailableServiceRequestDtoFilterInput>>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  cancellationReason?: InputMaybe<CancellationReasonDtoFilterInput>;
  customer?: InputMaybe<CustomerDtoFilterInput>;
  customerShare?: InputMaybe<DecimalOperationFilterInput>;
  description?: InputMaybe<StringOperationFilterInput>;
  discountAmount?: InputMaybe<DecimalOperationFilterInput>;
  distance?: InputMaybe<FloatOperationFilterInput>;
  finalPrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<AvailableServiceRequestDtoFilterInput>>;
  paidAt?: InputMaybe<DateTimeOperationFilterInput>;
  qnAs?: InputMaybe<ListFilterInputTypeOfServiceRequestQnADtoFilterInput>;
  rateAndReview?: InputMaybe<RateAndReviewDtoFilterInput>;
  requestDate?: InputMaybe<DateTimeOperationFilterInput>;
  serviceType?: InputMaybe<ServiceTypeDtoFilterInput>;
  settledAt?: InputMaybe<DateTimeOperationFilterInput>;
  specialist?: InputMaybe<SpecialistDtoFilterInput>;
  specialistGenderRequirement?: InputMaybe<GenderOperationFilterInput>;
  status?: InputMaybe<ServiceRequestStatusOperationFilterInput>;
  trackingCode?: InputMaybe<StringOperationFilterInput>;
};

export type AvailableServiceRequestDtoSortInput = {
  address?: InputMaybe<AddressDtoSortInput>;
  basePrice?: InputMaybe<SortEnumType>;
  cancellationReason?: InputMaybe<CancellationReasonDtoSortInput>;
  customer?: InputMaybe<CustomerDtoSortInput>;
  customerShare?: InputMaybe<SortEnumType>;
  description?: InputMaybe<SortEnumType>;
  discountAmount?: InputMaybe<SortEnumType>;
  distance?: InputMaybe<SortEnumType>;
  finalPrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  paidAt?: InputMaybe<SortEnumType>;
  rateAndReview?: InputMaybe<RateAndReviewDtoSortInput>;
  requestDate?: InputMaybe<SortEnumType>;
  serviceType?: InputMaybe<ServiceTypeDtoSortInput>;
  settledAt?: InputMaybe<SortEnumType>;
  specialist?: InputMaybe<SpecialistDtoSortInput>;
  specialistGenderRequirement?: InputMaybe<SortEnumType>;
  status?: InputMaybe<SortEnumType>;
  trackingCode?: InputMaybe<SortEnumType>;
};

export type BannerDto = {
  __typename?: 'BannerDto';
  id: Scalars['UUID']['output'];
  imageUrl: Scalars['String']['output'];
  title: Scalars['String']['output'];
};

/** A segment of a collection. */
export type BannerDtoCollectionSegment = {
  __typename?: 'BannerDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<BannerDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type BannerDtoFilterInput = {
  and?: InputMaybe<Array<BannerDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  imageUrl?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<BannerDtoFilterInput>>;
  title?: InputMaybe<StringOperationFilterInput>;
};

export type BannerDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  imageUrl?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
};

export type BooleanOperationFilterInput = {
  eq?: InputMaybe<Scalars['Boolean']['input']>;
  neq?: InputMaybe<Scalars['Boolean']['input']>;
};

export type CancelServiceRequestInput = {
  cancellationReasonId: Scalars['UUID']['input'];
  serviceRequestId: Scalars['UUID']['input'];
};

export type CancellationReasonDto = {
  __typename?: 'CancellationReasonDto';
  id: Scalars['UUID']['output'];
  name: Scalars['String']['output'];
  targets: Array<UserType>;
};

/** A segment of a collection. */
export type CancellationReasonDtoCollectionSegment = {
  __typename?: 'CancellationReasonDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CancellationReasonDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type CancellationReasonDtoFilterInput = {
  and?: InputMaybe<Array<CancellationReasonDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<CancellationReasonDtoFilterInput>>;
  targets?: InputMaybe<ListUserTypeOperationFilterInput>;
};

export type CancellationReasonDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type CarouselDto = {
  __typename?: 'CarouselDto';
  id: Scalars['UUID']['output'];
  serviceTypes: Array<ServiceTypeDto>;
  title: Scalars['String']['output'];
};

/** A segment of a collection. */
export type CarouselDtoCollectionSegment = {
  __typename?: 'CarouselDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CarouselDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type CarouselDtoFilterInput = {
  and?: InputMaybe<Array<CarouselDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<CarouselDtoFilterInput>>;
  serviceTypes?: InputMaybe<ListFilterInputTypeOfServiceTypeDtoFilterInput>;
  title?: InputMaybe<StringOperationFilterInput>;
};

export type CarouselDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
};

export type CityDto = {
  __typename?: 'CityDto';
  abbreviation: Scalars['String']['output'];
  activeBanner?: Maybe<BannerDto>;
  activeCarousel?: Maybe<CarouselDto>;
  availableServiceTypes: Array<ServiceTypeDto>;
  boundary: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  isActive: Scalars['Boolean']['output'];
  name: Scalars['String']['output'];
  province: ProvinceDto;
};

/** A segment of a collection. */
export type CityDtoCollectionSegment = {
  __typename?: 'CityDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CityDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type CityDtoFilterInput = {
  abbreviation?: InputMaybe<StringOperationFilterInput>;
  activeBanner?: InputMaybe<BannerDtoFilterInput>;
  activeCarousel?: InputMaybe<CarouselDtoFilterInput>;
  and?: InputMaybe<Array<CityDtoFilterInput>>;
  availableServiceTypes?: InputMaybe<ListFilterInputTypeOfServiceTypeDtoFilterInput>;
  boundary?: InputMaybe<StringOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isActive?: InputMaybe<BooleanOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<CityDtoFilterInput>>;
  province?: InputMaybe<ProvinceDtoFilterInput>;
};

export type CityDtoSortInput = {
  abbreviation?: InputMaybe<SortEnumType>;
  activeBanner?: InputMaybe<BannerDtoSortInput>;
  activeCarousel?: InputMaybe<CarouselDtoSortInput>;
  boundary?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isActive?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  province?: InputMaybe<ProvinceDtoSortInput>;
};

/** Information about the offset pagination. */
export type CollectionSegmentInfo = {
  __typename?: 'CollectionSegmentInfo';
  /** Indicates whether more items exist following the set defined by the clients arguments. */
  hasNextPage: Scalars['Boolean']['output'];
  /** Indicates whether more items exist prior the set defined by the clients arguments. */
  hasPreviousPage: Scalars['Boolean']['output'];
};

export type CompleteMultipartUploadInput = {
  objectKey: Scalars['String']['input'];
  uploadId: Scalars['String']['input'];
};

export type CompleteServiceInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type CreateAdminInput = {
  firstName: Scalars['String']['input'];
  lastName: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
};

export type CreateBannerInput = {
  imageUrl: Scalars['String']['input'];
  title: Scalars['String']['input'];
};

export type CreateCancellationReasonInput = {
  name: Scalars['String']['input'];
  targets: Array<UserType>;
};

export type CreateCarouselInput = {
  serviceTypeIds: Array<Scalars['UUID']['input']>;
  title: Scalars['String']['input'];
};

export type CreateCityInput = {
  abbreviation: Scalars['String']['input'];
  name: Scalars['String']['input'];
  provinceId: Scalars['UUID']['input'];
  wktBoundary: Scalars['String']['input'];
};

export type CreateDisabledServiceTimeInput = {
  time: Scalars['DateTime']['input'];
};

export type CreateDiscountCodeInput = {
  amount: Scalars['Decimal']['input'];
  customerId: Scalars['UUID']['input'];
  expiryDate?: InputMaybe<Scalars['DateTime']['input']>;
  isPercentage: Scalars['Boolean']['input'];
  title: Scalars['String']['input'];
};

export type CreatePaymentInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type CreateProvinceInput = {
  abbreviation: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type CreateRateAndReviewInput = {
  comment?: InputMaybe<Scalars['String']['input']>;
  rate: Scalars['Int']['input'];
  serviceRequestId: Scalars['UUID']['input'];
};

export type CreateServiceCategoryInput = {
  abbreviation: Scalars['String']['input'];
  logo: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type CreateServiceRequestInput = {
  addressId: Scalars['UUID']['input'];
  description: Scalars['String']['input'];
  gender?: InputMaybe<Gender>;
  locationType: LocationType;
  qnAs: Array<QnAInput>;
  requestDate: Scalars['DateTime']['input'];
  serviceTypeId: Scalars['UUID']['input'];
};

export type CreateServiceSubCategoryInput = {
  abbreviation: Scalars['String']['input'];
  logo: Scalars['String']['input'];
  name: Scalars['String']['input'];
  serviceCategoryId: Scalars['UUID']['input'];
};

export type CreateServiceTypeInput = {
  abbreviation: Scalars['String']['input'];
  banner: Scalars['String']['input'];
  basePrice: Scalars['Decimal']['input'];
  isSpecial: Scalars['Boolean']['input'];
  logo: Scalars['String']['input'];
  name: Scalars['String']['input'];
  serviceSubCategoryId: Scalars['UUID']['input'];
};

export type CreateServiceTypeQuestionInput = {
  isRequired: Scalars['Boolean']['input'];
  options: Array<Scalars['String']['input']>;
  questionType: QuestionType;
  serviceTypeId: Scalars['UUID']['input'];
  title: Scalars['String']['input'];
};

export type CustomerDto = {
  __typename?: 'CustomerDto';
  code: Scalars['String']['output'];
  firstName?: Maybe<Scalars['String']['output']>;
  gender: Gender;
  id: Scalars['UUID']['output'];
  isBlocked: Scalars['Boolean']['output'];
  lastName?: Maybe<Scalars['String']['output']>;
  phoneNumber: Scalars['String']['output'];
  profileImageUrl?: Maybe<Scalars['String']['output']>;
  registeredAt: Scalars['DateTime']['output'];
};

/** A segment of a collection. */
export type CustomerDtoCollectionSegment = {
  __typename?: 'CustomerDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<CustomerDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type CustomerDtoFilterInput = {
  and?: InputMaybe<Array<CustomerDtoFilterInput>>;
  code?: InputMaybe<StringOperationFilterInput>;
  firstName?: InputMaybe<StringOperationFilterInput>;
  gender?: InputMaybe<GenderOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isBlocked?: InputMaybe<BooleanOperationFilterInput>;
  lastName?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<CustomerDtoFilterInput>>;
  phoneNumber?: InputMaybe<StringOperationFilterInput>;
  profileImageUrl?: InputMaybe<StringOperationFilterInput>;
  registeredAt?: InputMaybe<DateTimeOperationFilterInput>;
};

export type CustomerDtoSortInput = {
  code?: InputMaybe<SortEnumType>;
  firstName?: InputMaybe<SortEnumType>;
  gender?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isBlocked?: InputMaybe<SortEnumType>;
  lastName?: InputMaybe<SortEnumType>;
  phoneNumber?: InputMaybe<SortEnumType>;
  profileImageUrl?: InputMaybe<SortEnumType>;
  registeredAt?: InputMaybe<SortEnumType>;
};

export type DateTimeOperationFilterInput = {
  eq?: InputMaybe<Scalars['DateTime']['input']>;
  gt?: InputMaybe<Scalars['DateTime']['input']>;
  gte?: InputMaybe<Scalars['DateTime']['input']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['DateTime']['input']>>>;
  lt?: InputMaybe<Scalars['DateTime']['input']>;
  lte?: InputMaybe<Scalars['DateTime']['input']>;
  neq?: InputMaybe<Scalars['DateTime']['input']>;
  ngt?: InputMaybe<Scalars['DateTime']['input']>;
  ngte?: InputMaybe<Scalars['DateTime']['input']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['DateTime']['input']>>>;
  nlt?: InputMaybe<Scalars['DateTime']['input']>;
  nlte?: InputMaybe<Scalars['DateTime']['input']>;
};

export type DeactivateCityInput = {
  cityId: Scalars['UUID']['input'];
};

export type DeactivateDiscountCodeInput = {
  id: Scalars['UUID']['input'];
};

export type DecimalOperationFilterInput = {
  eq?: InputMaybe<Scalars['Decimal']['input']>;
  gt?: InputMaybe<Scalars['Decimal']['input']>;
  gte?: InputMaybe<Scalars['Decimal']['input']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Decimal']['input']>>>;
  lt?: InputMaybe<Scalars['Decimal']['input']>;
  lte?: InputMaybe<Scalars['Decimal']['input']>;
  neq?: InputMaybe<Scalars['Decimal']['input']>;
  ngt?: InputMaybe<Scalars['Decimal']['input']>;
  ngte?: InputMaybe<Scalars['Decimal']['input']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Decimal']['input']>>>;
  nlt?: InputMaybe<Scalars['Decimal']['input']>;
  nlte?: InputMaybe<Scalars['Decimal']['input']>;
};

export type DeleteAddressInput = {
  addressId: Scalars['UUID']['input'];
};

export type DeleteBannerInput = {
  bannerId: Scalars['UUID']['input'];
};

export type DeleteCancellationReasonInput = {
  id: Scalars['UUID']['input'];
};

export type DeleteCarouselInput = {
  id: Scalars['UUID']['input'];
};

export type DeleteDiscountCodeInput = {
  id: Scalars['UUID']['input'];
};

export type DeleteProvinceInput = {
  id: Scalars['UUID']['input'];
};

export type DeleteServiceCategoryInput = {
  serviceCategoryId: Scalars['UUID']['input'];
};

export type DeleteServiceSubCategoryInput = {
  serviceSubCategoryId: Scalars['UUID']['input'];
};

export type DeleteServiceTypeInput = {
  id: Scalars['UUID']['input'];
};

export type DeleteServiceTypeQuestionInput = {
  id: Scalars['UUID']['input'];
};

export type DisabledServiceTimeDto = {
  __typename?: 'DisabledServiceTimeDto';
  id: Scalars['UUID']['output'];
  time: Scalars['DateTime']['output'];
};

/** A segment of a collection. */
export type DisabledServiceTimeDtoCollectionSegment = {
  __typename?: 'DisabledServiceTimeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<DisabledServiceTimeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type DisabledServiceTimeDtoFilterInput = {
  and?: InputMaybe<Array<DisabledServiceTimeDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<DisabledServiceTimeDtoFilterInput>>;
  time?: InputMaybe<DateTimeOperationFilterInput>;
};

export type DisabledServiceTimeDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  time?: InputMaybe<SortEnumType>;
};

export type DiscountCodeDto = {
  __typename?: 'DiscountCodeDto';
  amount: Scalars['Decimal']['output'];
  code: Scalars['String']['output'];
  customer: CustomerDto;
  expiryDate?: Maybe<Scalars['DateTime']['output']>;
  id: Scalars['UUID']['output'];
  isActive: Scalars['Boolean']['output'];
  isPercentage: Scalars['Boolean']['output'];
  isUsed: Scalars['Boolean']['output'];
  title: Scalars['String']['output'];
};

/** A segment of a collection. */
export type DiscountCodeDtoCollectionSegment = {
  __typename?: 'DiscountCodeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<DiscountCodeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type DiscountCodeDtoFilterInput = {
  amount?: InputMaybe<DecimalOperationFilterInput>;
  and?: InputMaybe<Array<DiscountCodeDtoFilterInput>>;
  code?: InputMaybe<StringOperationFilterInput>;
  customer?: InputMaybe<CustomerDtoFilterInput>;
  expiryDate?: InputMaybe<DateTimeOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isActive?: InputMaybe<BooleanOperationFilterInput>;
  isPercentage?: InputMaybe<BooleanOperationFilterInput>;
  isUsed?: InputMaybe<BooleanOperationFilterInput>;
  or?: InputMaybe<Array<DiscountCodeDtoFilterInput>>;
  title?: InputMaybe<StringOperationFilterInput>;
};

export type DiscountCodeDtoSortInput = {
  amount?: InputMaybe<SortEnumType>;
  code?: InputMaybe<SortEnumType>;
  customer?: InputMaybe<CustomerDtoSortInput>;
  expiryDate?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isActive?: InputMaybe<SortEnumType>;
  isPercentage?: InputMaybe<SortEnumType>;
  isUsed?: InputMaybe<SortEnumType>;
  title?: InputMaybe<SortEnumType>;
};

export type FloatOperationFilterInput = {
  eq?: InputMaybe<Scalars['Float']['input']>;
  gt?: InputMaybe<Scalars['Float']['input']>;
  gte?: InputMaybe<Scalars['Float']['input']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Float']['input']>>>;
  lt?: InputMaybe<Scalars['Float']['input']>;
  lte?: InputMaybe<Scalars['Float']['input']>;
  neq?: InputMaybe<Scalars['Float']['input']>;
  ngt?: InputMaybe<Scalars['Float']['input']>;
  ngte?: InputMaybe<Scalars['Float']['input']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Float']['input']>>>;
  nlt?: InputMaybe<Scalars['Float']['input']>;
  nlte?: InputMaybe<Scalars['Float']['input']>;
};

export enum Gender {
  Female = 'FEMALE',
  Male = 'MALE',
  NotSet = 'NOT_SET'
}

export type GenderOperationFilterInput = {
  eq?: InputMaybe<Gender>;
  in?: InputMaybe<Array<Gender>>;
  neq?: InputMaybe<Gender>;
  nin?: InputMaybe<Array<Gender>>;
};

export type GenerateMultipartPresignedUrlsInput = {
  fileSize: Scalars['Long']['input'];
  objectKey: Scalars['String']['input'];
  partSize?: InputMaybe<Scalars['Int']['input']>;
};

export type GeneratePresignedUrlInput = {
  objectKey: Scalars['String']['input'];
};

export type GetAddressByIdInput = {
  addressId: Scalars['UUID']['input'];
};

export type GetAvailableRequestsInput = {
  latitude: Scalars['Float']['input'];
  longitude: Scalars['Float']['input'];
};

export type GetAvailableServiceCategoriesForCityInput = {
  cityId: Scalars['UUID']['input'];
};

export type GetAvailableServiceSubCategoriesForCityInput = {
  cityId: Scalars['UUID']['input'];
};

export type GetAvailableServiceTypesForAddressInput = {
  addressId: Scalars['UUID']['input'];
};

export type GetAvailableServiceTypesForCityInput = {
  cityId: Scalars['UUID']['input'];
};

export type GetBannerByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetCancellationReasonByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetCarouselByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetCityByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetCustomerByIdInput = {
  customerId: Scalars['UUID']['input'];
};

export type GetDiscountCodeByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetMyRevenueInput = {
  endDate?: InputMaybe<Scalars['DateTime']['input']>;
  startDate?: InputMaybe<Scalars['DateTime']['input']>;
};

export type GetNearestAddressesInput = {
  latitude: Scalars['Float']['input'];
  longitude: Scalars['Float']['input'];
};

export type GetPaymentByIdInput = {
  paymentId: Scalars['UUID']['input'];
};

export type GetPaymentsForServiceRequestInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type GetPopularServiceTypesInput = {
  cityId?: InputMaybe<Scalars['UUID']['input']>;
};

export type GetProvinceByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetServiceCategoryByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetServiceRequestByIdInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type GetServiceSubCategoryByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetServiceTypeByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetServiceTypeQuestionByIdInput = {
  id: Scalars['UUID']['input'];
};

export type GetServiceTypeQuestionsByServiceTypeInput = {
  serviceTypeId: Scalars['UUID']['input'];
};

export type GetSpecialistByIdInput = {
  specialistId: Scalars['UUID']['input'];
};

export type GetSpecialistRevenueByIdInput = {
  endDate?: InputMaybe<Scalars['DateTime']['input']>;
  specialistId: Scalars['UUID']['input'];
  startDate?: InputMaybe<Scalars['DateTime']['input']>;
};

export type IntOperationFilterInput = {
  eq?: InputMaybe<Scalars['Int']['input']>;
  gt?: InputMaybe<Scalars['Int']['input']>;
  gte?: InputMaybe<Scalars['Int']['input']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  lt?: InputMaybe<Scalars['Int']['input']>;
  lte?: InputMaybe<Scalars['Int']['input']>;
  neq?: InputMaybe<Scalars['Int']['input']>;
  ngt?: InputMaybe<Scalars['Int']['input']>;
  ngte?: InputMaybe<Scalars['Int']['input']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  nlt?: InputMaybe<Scalars['Int']['input']>;
  nlte?: InputMaybe<Scalars['Int']['input']>;
};

export type ListFilterInputTypeOfServiceRequestQnADtoFilterInput = {
  all?: InputMaybe<ServiceRequestQnADtoFilterInput>;
  any?: InputMaybe<Scalars['Boolean']['input']>;
  none?: InputMaybe<ServiceRequestQnADtoFilterInput>;
  some?: InputMaybe<ServiceRequestQnADtoFilterInput>;
};

export type ListFilterInputTypeOfServiceTypeDtoFilterInput = {
  all?: InputMaybe<ServiceTypeDtoFilterInput>;
  any?: InputMaybe<Scalars['Boolean']['input']>;
  none?: InputMaybe<ServiceTypeDtoFilterInput>;
  some?: InputMaybe<ServiceTypeDtoFilterInput>;
};

export type ListResponseBaseOfAddressDto = {
  __typename?: 'ListResponseBaseOfAddressDto';
  result?: Maybe<AddressDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfAddressDtoResultArgs = {
  order?: InputMaybe<Array<AddressDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<AddressDtoFilterInput>;
};

export type ListResponseBaseOfAdminDto = {
  __typename?: 'ListResponseBaseOfAdminDto';
  result?: Maybe<AdminDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfAdminDtoResultArgs = {
  order?: InputMaybe<Array<AdminDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<AdminDtoFilterInput>;
};

export type ListResponseBaseOfAvailableServiceRequestDto = {
  __typename?: 'ListResponseBaseOfAvailableServiceRequestDto';
  result?: Maybe<AvailableServiceRequestDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfAvailableServiceRequestDtoResultArgs = {
  order?: InputMaybe<Array<AvailableServiceRequestDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<AvailableServiceRequestDtoFilterInput>;
};

export type ListResponseBaseOfBannerDto = {
  __typename?: 'ListResponseBaseOfBannerDto';
  result?: Maybe<BannerDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfBannerDtoResultArgs = {
  order?: InputMaybe<Array<BannerDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<BannerDtoFilterInput>;
};

export type ListResponseBaseOfCancellationReasonDto = {
  __typename?: 'ListResponseBaseOfCancellationReasonDto';
  result?: Maybe<CancellationReasonDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfCancellationReasonDtoResultArgs = {
  order?: InputMaybe<Array<CancellationReasonDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CancellationReasonDtoFilterInput>;
};

export type ListResponseBaseOfCarouselDto = {
  __typename?: 'ListResponseBaseOfCarouselDto';
  result?: Maybe<CarouselDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfCarouselDtoResultArgs = {
  order?: InputMaybe<Array<CarouselDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CarouselDtoFilterInput>;
};

export type ListResponseBaseOfCityDto = {
  __typename?: 'ListResponseBaseOfCityDto';
  result?: Maybe<CityDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfCityDtoResultArgs = {
  order?: InputMaybe<Array<CityDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CityDtoFilterInput>;
};

export type ListResponseBaseOfCustomerDto = {
  __typename?: 'ListResponseBaseOfCustomerDto';
  result?: Maybe<CustomerDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfCustomerDtoResultArgs = {
  order?: InputMaybe<Array<CustomerDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CustomerDtoFilterInput>;
};

export type ListResponseBaseOfDisabledServiceTimeDto = {
  __typename?: 'ListResponseBaseOfDisabledServiceTimeDto';
  result?: Maybe<DisabledServiceTimeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfDisabledServiceTimeDtoResultArgs = {
  order?: InputMaybe<Array<DisabledServiceTimeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<DisabledServiceTimeDtoFilterInput>;
};

export type ListResponseBaseOfDiscountCodeDto = {
  __typename?: 'ListResponseBaseOfDiscountCodeDto';
  result?: Maybe<DiscountCodeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfDiscountCodeDtoResultArgs = {
  order?: InputMaybe<Array<DiscountCodeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<DiscountCodeDtoFilterInput>;
};

export type ListResponseBaseOfPaymentDto = {
  __typename?: 'ListResponseBaseOfPaymentDto';
  result?: Maybe<PaymentDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfPaymentDtoResultArgs = {
  order?: InputMaybe<Array<PaymentDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<PaymentDtoFilterInput>;
};

export type ListResponseBaseOfPopularServiceTypeDto = {
  __typename?: 'ListResponseBaseOfPopularServiceTypeDto';
  result?: Maybe<PopularServiceTypeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfPopularServiceTypeDtoResultArgs = {
  order?: InputMaybe<Array<PopularServiceTypeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<PopularServiceTypeDtoFilterInput>;
};

export type ListResponseBaseOfProvinceDto = {
  __typename?: 'ListResponseBaseOfProvinceDto';
  result?: Maybe<ProvinceDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfProvinceDtoResultArgs = {
  order?: InputMaybe<Array<ProvinceDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ProvinceDtoFilterInput>;
};

export type ListResponseBaseOfRateAndReviewDto = {
  __typename?: 'ListResponseBaseOfRateAndReviewDto';
  result?: Maybe<RateAndReviewDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfRateAndReviewDtoResultArgs = {
  order?: InputMaybe<Array<RateAndReviewDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<RateAndReviewDtoFilterInput>;
};

export type ListResponseBaseOfServiceCategoryDto = {
  __typename?: 'ListResponseBaseOfServiceCategoryDto';
  result?: Maybe<ServiceCategoryDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfServiceCategoryDtoResultArgs = {
  order?: InputMaybe<Array<ServiceCategoryDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceCategoryDtoFilterInput>;
};

export type ListResponseBaseOfServiceRequestDto = {
  __typename?: 'ListResponseBaseOfServiceRequestDto';
  result?: Maybe<ServiceRequestDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfServiceRequestDtoResultArgs = {
  order?: InputMaybe<Array<ServiceRequestDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceRequestDtoFilterInput>;
};

export type ListResponseBaseOfServiceSubCategoryDto = {
  __typename?: 'ListResponseBaseOfServiceSubCategoryDto';
  result?: Maybe<ServiceSubCategoryDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfServiceSubCategoryDtoResultArgs = {
  order?: InputMaybe<Array<ServiceSubCategoryDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
};

export type ListResponseBaseOfServiceTypeCountDto = {
  __typename?: 'ListResponseBaseOfServiceTypeCountDto';
  result?: Maybe<ServiceTypeCountDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfServiceTypeCountDtoResultArgs = {
  order?: InputMaybe<Array<ServiceTypeCountDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeCountDtoFilterInput>;
};

export type ListResponseBaseOfServiceTypeDto = {
  __typename?: 'ListResponseBaseOfServiceTypeDto';
  result?: Maybe<ServiceTypeDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfServiceTypeDtoResultArgs = {
  order?: InputMaybe<Array<ServiceTypeDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeDtoFilterInput>;
};

export type ListResponseBaseOfServiceTypeQuestionDto = {
  __typename?: 'ListResponseBaseOfServiceTypeQuestionDto';
  result?: Maybe<ServiceTypeQuestionDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfServiceTypeQuestionDtoResultArgs = {
  order?: InputMaybe<Array<ServiceTypeQuestionDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeQuestionDtoFilterInput>;
};

export type ListResponseBaseOfSpecialistDto = {
  __typename?: 'ListResponseBaseOfSpecialistDto';
  result?: Maybe<SpecialistDtoCollectionSegment>;
  status?: Maybe<Scalars['Any']['output']>;
};


export type ListResponseBaseOfSpecialistDtoResultArgs = {
  order?: InputMaybe<Array<SpecialistDtoSortInput>>;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<SpecialistDtoFilterInput>;
};

export type ListStringOperationFilterInput = {
  all?: InputMaybe<StringOperationFilterInput>;
  any?: InputMaybe<Scalars['Boolean']['input']>;
  none?: InputMaybe<StringOperationFilterInput>;
  some?: InputMaybe<StringOperationFilterInput>;
};

export type ListUserTypeOperationFilterInput = {
  all?: InputMaybe<UserTypeOperationFilterInput>;
  any?: InputMaybe<Scalars['Boolean']['input']>;
  none?: InputMaybe<UserTypeOperationFilterInput>;
  some?: InputMaybe<UserTypeOperationFilterInput>;
};

export enum LocationType {
  Commercial = 'COMMERCIAL',
  Office = 'OFFICE',
  Residential = 'RESIDENTIAL',
  Vacant = 'VACANT'
}

export type MarkAsArrivedInput = {
  latitude: Scalars['Float']['input'];
  longitude: Scalars['Float']['input'];
  serviceRequestId: Scalars['UUID']['input'];
};

export type MarkServiceRequestSettledInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type Mutation = {
  __typename?: 'Mutation';
  address_create: SingleResponseBaseOfAddressDto;
  address_delete: ResponseBase;
  address_setPrimary: ResponseBase;
  address_update: SingleResponseBaseOfAddressDto;
  /** Allows an owner to create a new admin user. */
  admin_create: ResponseBase;
  auth_refreshToken: ResponseBaseOfAuthResult;
  auth_requestOtp: ResponseBase;
  auth_verifyOtp: ResponseBaseOfAuthResult;
  banner_create: ResponseBaseOfBannerDto;
  banner_delete: ResponseBase;
  banner_update: ResponseBaseOfBannerDto;
  cancellationReason_create: ResponseBaseOfCancellationReasonDto;
  cancellationReason_delete: ResponseBase;
  cancellationReason_update: ResponseBaseOfCancellationReasonDto;
  carousel_create: ResponseBaseOfCarouselDto;
  carousel_delete: ResponseBase;
  carousel_update: ResponseBaseOfCarouselDto;
  city_activate: SingleResponseBaseOfCityDto;
  city_create: SingleResponseBaseOfCityDto;
  city_deactivate: SingleResponseBaseOfCityDto;
  city_setActiveBanner: SingleResponseBaseOfCityDto;
  city_setActiveCarousel: SingleResponseBaseOfCityDto;
  city_setAvailableServiceTypes: SingleResponseBaseOfCityDto;
  city_update: SingleResponseBaseOfCityDto;
  city_updateBoundary: SingleResponseBaseOfCityDto;
  disabledServiceTime_create: ResponseBaseOfDisabledServiceTimeDto;
  disabledServiceTime_remove: ResponseBase;
  discountCode_activate: ResponseBaseOfDiscountCodeDto;
  discountCode_create: ResponseBaseOfDiscountCodeDto;
  discountCode_deactivate: ResponseBaseOfDiscountCodeDto;
  discountCode_delete: ResponseBase;
  payment_create_zibal: ResponseBaseOfPaymentDto;
  province_create: ResponseBaseOfProvinceDto;
  province_delete: ResponseBase;
  province_update: ResponseBaseOfProvinceDto;
  rateAndReview_create: ResponseBaseOfRateAndReviewDto;
  s3_completeMultipartUpload: ResponseBase;
  s3_generatePresignedUrl: ResponseBaseOfS3SinglepartUploadUrlsResultDto;
  s3_generatePresignedUrls: ResponseBaseOfS3MultipartUploadUrlsResultDto;
  serviceCategory_create: ResponseBaseOfServiceCategoryDto;
  serviceCategory_delete: ResponseBase;
  serviceCategory_update: ResponseBaseOfServiceCategoryDto;
  serviceRequest_accept: SingleResponseBaseOfServiceRequestDto;
  serviceRequest_applyDiscount: ResponseBaseOfServiceRequestDto;
  serviceRequest_cancel: SingleResponseBaseOfServiceRequestDto;
  serviceRequest_completeService: SingleResponseBaseOfServiceRequestDto;
  serviceRequest_create: ResponseBaseOfServiceRequestDto;
  serviceRequest_markAsArrived: SingleResponseBaseOfServiceRequestDto;
  serviceRequest_markAsSettled: SingleResponseBaseOfServiceRequestDto;
  serviceRequest_reject: ResponseBaseOfRejectedServiceRequestDto;
  serviceRequest_removeDiscount: ResponseBaseOfServiceRequestDto;
  serviceSubCategory_create: ResponseBaseOfServiceSubCategoryDto;
  serviceSubCategory_delete: ResponseBase;
  serviceSubCategory_update: ResponseBaseOfServiceSubCategoryDto;
  serviceTypeQuestion_create: ResponseBaseOfServiceTypeQuestionDto;
  serviceTypeQuestion_delete: ResponseBase;
  serviceTypeQuestion_update: ResponseBaseOfServiceTypeQuestionDto;
  serviceType_create: ResponseBaseOfServiceTypeDto;
  serviceType_delete: ResponseBase;
  serviceType_update: ResponseBaseOfServiceTypeDto;
  specialist_setLocationAndSpecialty: ResponseBase;
  specialist_setPersonalInformation: ResponseBase;
  specialist_updateIdentityVerificationVideo: ResponseBase;
  specialist_updateSpecializedDocuments: ResponseBase;
  specialist_verifyIDCard: ResponseBase;
  specialist_verifyIdentityVerificationVideo: ResponseBase;
  specialist_verifySpecializedDocuments: ResponseBase;
  user_setBlockState: ResponseBase;
  user_updateProfile: ResponseBaseOfUserProfileDto;
};


export type MutationAddress_CreateArgs = {
  input: AddAddressInput;
};


export type MutationAddress_DeleteArgs = {
  input: DeleteAddressInput;
};


export type MutationAddress_SetPrimaryArgs = {
  input: SetPrimaryAddressInput;
};


export type MutationAddress_UpdateArgs = {
  input: UpdateAddressInput;
};


export type MutationAdmin_CreateArgs = {
  input: CreateAdminInput;
};


export type MutationAuth_RefreshTokenArgs = {
  input: RefreshTokenRequestInput;
};


export type MutationAuth_RequestOtpArgs = {
  input: RequestOtpInput;
};


export type MutationAuth_VerifyOtpArgs = {
  input: VerifyOtpInput;
};


export type MutationBanner_CreateArgs = {
  input: CreateBannerInput;
};


export type MutationBanner_DeleteArgs = {
  input: DeleteBannerInput;
};


export type MutationBanner_UpdateArgs = {
  input: UpdateBannerInput;
};


export type MutationCancellationReason_CreateArgs = {
  input: CreateCancellationReasonInput;
};


export type MutationCancellationReason_DeleteArgs = {
  input: DeleteCancellationReasonInput;
};


export type MutationCancellationReason_UpdateArgs = {
  input: UpdateCancellationReasonInput;
};


export type MutationCarousel_CreateArgs = {
  input: CreateCarouselInput;
};


export type MutationCarousel_DeleteArgs = {
  input: DeleteCarouselInput;
};


export type MutationCarousel_UpdateArgs = {
  input: UpdateCarouselInput;
};


export type MutationCity_ActivateArgs = {
  input: ActivateCityInput;
};


export type MutationCity_CreateArgs = {
  input: CreateCityInput;
};


export type MutationCity_DeactivateArgs = {
  input: DeactivateCityInput;
};


export type MutationCity_SetActiveBannerArgs = {
  input: SetActiveBannerInput;
};


export type MutationCity_SetActiveCarouselArgs = {
  input: SetActiveCarouselInput;
};


export type MutationCity_SetAvailableServiceTypesArgs = {
  input: SetCityAvailableServiceTypesInput;
};


export type MutationCity_UpdateArgs = {
  input: UpdateCityInput;
};


export type MutationCity_UpdateBoundaryArgs = {
  input: UpdateCityBoundaryInput;
};


export type MutationDisabledServiceTime_CreateArgs = {
  input: CreateDisabledServiceTimeInput;
};


export type MutationDisabledServiceTime_RemoveArgs = {
  input: RemoveDisabledServiceTimeInput;
};


export type MutationDiscountCode_ActivateArgs = {
  input: ActivateDiscountCodeInput;
};


export type MutationDiscountCode_CreateArgs = {
  input: CreateDiscountCodeInput;
};


export type MutationDiscountCode_DeactivateArgs = {
  input: DeactivateDiscountCodeInput;
};


export type MutationDiscountCode_DeleteArgs = {
  input: DeleteDiscountCodeInput;
};


export type MutationPayment_Create_ZibalArgs = {
  input: CreatePaymentInput;
};


export type MutationProvince_CreateArgs = {
  input: CreateProvinceInput;
};


export type MutationProvince_DeleteArgs = {
  input: DeleteProvinceInput;
};


export type MutationProvince_UpdateArgs = {
  input: UpdateProvinceInput;
};


export type MutationRateAndReview_CreateArgs = {
  input: CreateRateAndReviewInput;
};


export type MutationS3_CompleteMultipartUploadArgs = {
  input: CompleteMultipartUploadInput;
};


export type MutationS3_GeneratePresignedUrlArgs = {
  input: GeneratePresignedUrlInput;
};


export type MutationS3_GeneratePresignedUrlsArgs = {
  input: GenerateMultipartPresignedUrlsInput;
};


export type MutationServiceCategory_CreateArgs = {
  input: CreateServiceCategoryInput;
};


export type MutationServiceCategory_DeleteArgs = {
  input: DeleteServiceCategoryInput;
};


export type MutationServiceCategory_UpdateArgs = {
  input: UpdateServiceCategoryInput;
};


export type MutationServiceRequest_AcceptArgs = {
  input: AcceptServiceRequestInput;
};


export type MutationServiceRequest_ApplyDiscountArgs = {
  input: ApplyDiscountCodeToServiceRequestInput;
};


export type MutationServiceRequest_CancelArgs = {
  input: CancelServiceRequestInput;
};


export type MutationServiceRequest_CompleteServiceArgs = {
  input: CompleteServiceInput;
};


export type MutationServiceRequest_CreateArgs = {
  input: CreateServiceRequestInput;
};


export type MutationServiceRequest_MarkAsArrivedArgs = {
  input: MarkAsArrivedInput;
};


export type MutationServiceRequest_MarkAsSettledArgs = {
  input: MarkServiceRequestSettledInput;
};


export type MutationServiceRequest_RejectArgs = {
  input: RejectServiceRequestInput;
};


export type MutationServiceRequest_RemoveDiscountArgs = {
  input: RemoveDiscountCodeFromServiceRequestInput;
};


export type MutationServiceSubCategory_CreateArgs = {
  input: CreateServiceSubCategoryInput;
};


export type MutationServiceSubCategory_DeleteArgs = {
  input: DeleteServiceSubCategoryInput;
};


export type MutationServiceSubCategory_UpdateArgs = {
  input: UpdateServiceSubCategoryInput;
};


export type MutationServiceTypeQuestion_CreateArgs = {
  input: CreateServiceTypeQuestionInput;
};


export type MutationServiceTypeQuestion_DeleteArgs = {
  input: DeleteServiceTypeQuestionInput;
};


export type MutationServiceTypeQuestion_UpdateArgs = {
  input: UpdateServiceTypeQuestionInput;
};


export type MutationServiceType_CreateArgs = {
  input: CreateServiceTypeInput;
};


export type MutationServiceType_DeleteArgs = {
  input: DeleteServiceTypeInput;
};


export type MutationServiceType_UpdateArgs = {
  input: UpdateServiceTypeInput;
};


export type MutationSpecialist_SetLocationAndSpecialtyArgs = {
  input: SetLocationAndSpecialtyInput;
};


export type MutationSpecialist_SetPersonalInformationArgs = {
  input: SetPersonalInformationInput;
};


export type MutationSpecialist_UpdateIdentityVerificationVideoArgs = {
  input: UpdateIdentityVerificationVideoInput;
};


export type MutationSpecialist_UpdateSpecializedDocumentsArgs = {
  input: UpdateSpecializedDocumentsInput;
};


export type MutationSpecialist_VerifyIdCardArgs = {
  input: VerifyIdCardInput;
};


export type MutationSpecialist_VerifyIdentityVerificationVideoArgs = {
  input: VerifyIdentityVerificationVideoInput;
};


export type MutationSpecialist_VerifySpecializedDocumentsArgs = {
  input: VerifySpecializedDocumentsInput;
};


export type MutationUser_SetBlockStateArgs = {
  input: SetUserBlockStateInput;
};


export type MutationUser_UpdateProfileArgs = {
  input: UpdateUserProfileInput;
};

export type PaymentDto = {
  __typename?: 'PaymentDto';
  amount: Scalars['Decimal']['output'];
  discountCode?: Maybe<DiscountCodeDto>;
  id: Scalars['UUID']['output'];
  paymentUrl?: Maybe<Scalars['String']['output']>;
  serviceRequest: ServiceRequestDto;
  status: PaymentStatus;
};

/** A segment of a collection. */
export type PaymentDtoCollectionSegment = {
  __typename?: 'PaymentDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<PaymentDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type PaymentDtoFilterInput = {
  amount?: InputMaybe<DecimalOperationFilterInput>;
  and?: InputMaybe<Array<PaymentDtoFilterInput>>;
  discountCode?: InputMaybe<DiscountCodeDtoFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<PaymentDtoFilterInput>>;
  paymentUrl?: InputMaybe<StringOperationFilterInput>;
  serviceRequest?: InputMaybe<ServiceRequestDtoFilterInput>;
  status?: InputMaybe<PaymentStatusOperationFilterInput>;
};

export type PaymentDtoSortInput = {
  amount?: InputMaybe<SortEnumType>;
  discountCode?: InputMaybe<DiscountCodeDtoSortInput>;
  id?: InputMaybe<SortEnumType>;
  paymentUrl?: InputMaybe<SortEnumType>;
  serviceRequest?: InputMaybe<ServiceRequestDtoSortInput>;
  status?: InputMaybe<SortEnumType>;
};

export enum PaymentStatus {
  Failed = 'FAILED',
  Pending = 'PENDING',
  Success = 'SUCCESS'
}

export type PaymentStatusOperationFilterInput = {
  eq?: InputMaybe<PaymentStatus>;
  in?: InputMaybe<Array<PaymentStatus>>;
  neq?: InputMaybe<PaymentStatus>;
  nin?: InputMaybe<Array<PaymentStatus>>;
};

export type PopularServiceTypeDto = {
  __typename?: 'PopularServiceTypeDto';
  abbreviation: Scalars['String']['output'];
  banner: Scalars['String']['output'];
  basePrice: Scalars['Decimal']['output'];
  id: Scalars['UUID']['output'];
  isSpecial: Scalars['Boolean']['output'];
  logo: Scalars['String']['output'];
  name: Scalars['String']['output'];
  requestCount: Scalars['Int']['output'];
  serviceSubCategory: ServiceSubCategoryDto;
};

/** A segment of a collection. */
export type PopularServiceTypeDtoCollectionSegment = {
  __typename?: 'PopularServiceTypeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<PopularServiceTypeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type PopularServiceTypeDtoFilterInput = {
  abbreviation?: InputMaybe<StringOperationFilterInput>;
  and?: InputMaybe<Array<PopularServiceTypeDtoFilterInput>>;
  banner?: InputMaybe<StringOperationFilterInput>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isSpecial?: InputMaybe<BooleanOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<PopularServiceTypeDtoFilterInput>>;
  requestCount?: InputMaybe<IntOperationFilterInput>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
};

export type PopularServiceTypeDtoSortInput = {
  abbreviation?: InputMaybe<SortEnumType>;
  banner?: InputMaybe<SortEnumType>;
  basePrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isSpecial?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  requestCount?: InputMaybe<SortEnumType>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoSortInput>;
};

export type ProvinceDto = {
  __typename?: 'ProvinceDto';
  abbreviation: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  name: Scalars['String']['output'];
};

/** A segment of a collection. */
export type ProvinceDtoCollectionSegment = {
  __typename?: 'ProvinceDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ProvinceDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ProvinceDtoFilterInput = {
  abbreviation?: InputMaybe<StringOperationFilterInput>;
  and?: InputMaybe<Array<ProvinceDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ProvinceDtoFilterInput>>;
};

export type ProvinceDtoSortInput = {
  abbreviation?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type QnAInput = {
  answers: Array<Scalars['String']['input']>;
  questionId: Scalars['UUID']['input'];
};

export type Query = {
  __typename?: 'Query';
  address_getAddressById: SingleResponseBaseOfAddressDto;
  address_getAvailableServiceTypes: ListResponseBaseOfServiceTypeDto;
  address_getMyAddresses: ListResponseBaseOfAddressDto;
  address_nearestAddresses: ListResponseBaseOfAddressDto;
  /** Returns all admin users. Accessible by owner/admin. */
  admin_getAll: ListResponseBaseOfAdminDto;
  /** Returns an admin by their ID. Accessible by owner/admin. */
  admin_getById: ResponseBaseOfAdminDto;
  banner_getAll: ListResponseBaseOfBannerDto;
  banner_getById: ResponseBaseOfBannerDto;
  cancellationReason_getAll: ListResponseBaseOfCancellationReasonDto;
  cancellationReason_getById: ResponseBaseOfCancellationReasonDto;
  carousel_getAll: ListResponseBaseOfCarouselDto;
  carousel_getById: ResponseBaseOfCarouselDto;
  city_getAll: ListResponseBaseOfCityDto;
  city_getAvailableServiceCategories: ListResponseBaseOfServiceCategoryDto;
  city_getAvailableServiceSubCategories: ListResponseBaseOfServiceSubCategoryDto;
  city_getAvailableServiceTypes: ListResponseBaseOfServiceTypeDto;
  city_getById: SingleResponseBaseOfCityDto;
  /** Returns all customers. */
  customer_getAll: ListResponseBaseOfCustomerDto;
  /** Returns a customer by their ID. */
  customer_getById: ResponseBaseOfCustomerDto;
  disabledServiceTime_getAll: ListResponseBaseOfDisabledServiceTimeDto;
  discountCode_getAll: ListResponseBaseOfDiscountCodeDto;
  discountCode_getById: ResponseBaseOfDiscountCodeDto;
  discountCode_getMyCodes: ListResponseBaseOfDiscountCodeDto;
  payment_getAll: ListResponseBaseOfPaymentDto;
  payment_getById: ResponseBaseOfPaymentDto;
  payment_getMyPayments: ListResponseBaseOfPaymentDto;
  payment_listForServiceRequest: ListResponseBaseOfPaymentDto;
  province_getAll: ListResponseBaseOfProvinceDto;
  province_getById: ResponseBaseOfProvinceDto;
  rateAndReview_getByCustomerId: ListResponseBaseOfRateAndReviewDto;
  rateAndReview_getBySpecialistId: ListResponseBaseOfRateAndReviewDto;
  /** Get revenue for the currently authenticated specialist in a given date range. */
  revenue_getMyRevenue: ResponseBaseOfSpecialistRevenueDto;
  /** Admin: get revenue of a specialist in a given date range. */
  revenue_getRevenueBySpecialistId: ResponseBaseOfSpecialistRevenueDto;
  serviceCategory_getAll: ListResponseBaseOfServiceCategoryDto;
  serviceCategory_getById: ResponseBaseOfServiceCategoryDto;
  serviceRequest_getAll: ListResponseBaseOfServiceRequestDto;
  serviceRequest_getAvailableRequests: ListResponseBaseOfAvailableServiceRequestDto;
  serviceRequest_getById: SingleResponseBaseOfServiceRequestDto;
  serviceRequest_getMyAcceptances: ListResponseBaseOfServiceRequestDto;
  serviceRequest_getMyRequests: ListResponseBaseOfServiceRequestDto;
  serviceSubCategory_getAll: ListResponseBaseOfServiceSubCategoryDto;
  serviceSubCategory_getById: ResponseBaseOfServiceSubCategoryDto;
  serviceTypeQuestion_getById: SingleResponseBaseOfServiceTypeQuestionDto;
  serviceTypeQuestion_getByServiceType: ListResponseBaseOfServiceTypeQuestionDto;
  serviceType_getById: ResponseBaseOfServiceTypeDto;
  serviceTypes_getAll: ListResponseBaseOfServiceTypeDto;
  serviceTypes_getPopular: ListResponseBaseOfPopularServiceTypeDto;
  /** Returns all specialists. */
  specialist_getAll: ListResponseBaseOfSpecialistDto;
  /** Returns a specialist by their ID. */
  specialist_getById: ResponseBaseOfSpecialistDto;
  /** Returns the profile of the currently authenticated specialist. */
  specialist_getMyProfile: ResponseBaseOfSpecialistDto;
  stats_getActiveSpecialists: ResponseBaseOfInt32;
  stats_getServiceRequests: ResponseBaseOfServiceRequestsDto;
  stats_getServiceTypeCounts: ListResponseBaseOfServiceTypeCountDto;
  stats_getTotalRevenue: ResponseBaseOfTotalRevenueDto;
  /** Gets the profile of the currently authenticated user. */
  user_getMyProfile: ResponseBaseOfUserProfileDto;
};


export type QueryAddress_GetAddressByIdArgs = {
  input: GetAddressByIdInput;
};


export type QueryAddress_GetAvailableServiceTypesArgs = {
  input: GetAvailableServiceTypesForAddressInput;
};


export type QueryAddress_NearestAddressesArgs = {
  input: GetNearestAddressesInput;
};


export type QueryAdmin_GetByIdArgs = {
  adminId: Scalars['UUID']['input'];
};


export type QueryBanner_GetByIdArgs = {
  input: GetBannerByIdInput;
};


export type QueryCancellationReason_GetByIdArgs = {
  input: GetCancellationReasonByIdInput;
};


export type QueryCarousel_GetByIdArgs = {
  input: GetCarouselByIdInput;
};


export type QueryCity_GetAvailableServiceCategoriesArgs = {
  input: GetAvailableServiceCategoriesForCityInput;
};


export type QueryCity_GetAvailableServiceSubCategoriesArgs = {
  input: GetAvailableServiceSubCategoriesForCityInput;
};


export type QueryCity_GetAvailableServiceTypesArgs = {
  input: GetAvailableServiceTypesForCityInput;
};


export type QueryCity_GetByIdArgs = {
  input: GetCityByIdInput;
};


export type QueryCustomer_GetByIdArgs = {
  input: GetCustomerByIdInput;
};


export type QueryDiscountCode_GetByIdArgs = {
  input: GetDiscountCodeByIdInput;
};


export type QueryPayment_GetByIdArgs = {
  input: GetPaymentByIdInput;
};


export type QueryPayment_ListForServiceRequestArgs = {
  input: GetPaymentsForServiceRequestInput;
};


export type QueryProvince_GetByIdArgs = {
  input: GetProvinceByIdInput;
};


export type QueryRateAndReview_GetByCustomerIdArgs = {
  customerId: Scalars['UUID']['input'];
};


export type QueryRateAndReview_GetBySpecialistIdArgs = {
  specialistId: Scalars['UUID']['input'];
};


export type QueryRevenue_GetMyRevenueArgs = {
  input: GetMyRevenueInput;
};


export type QueryRevenue_GetRevenueBySpecialistIdArgs = {
  input: GetSpecialistRevenueByIdInput;
};


export type QueryServiceCategory_GetByIdArgs = {
  input: GetServiceCategoryByIdInput;
};


export type QueryServiceRequest_GetAvailableRequestsArgs = {
  input: GetAvailableRequestsInput;
};


export type QueryServiceRequest_GetByIdArgs = {
  input: GetServiceRequestByIdInput;
};


export type QueryServiceSubCategory_GetByIdArgs = {
  input: GetServiceSubCategoryByIdInput;
};


export type QueryServiceTypeQuestion_GetByIdArgs = {
  input: GetServiceTypeQuestionByIdInput;
};


export type QueryServiceTypeQuestion_GetByServiceTypeArgs = {
  input: GetServiceTypeQuestionsByServiceTypeInput;
};


export type QueryServiceType_GetByIdArgs = {
  input: GetServiceTypeByIdInput;
};


export type QueryServiceTypes_GetPopularArgs = {
  input: GetPopularServiceTypesInput;
};


export type QuerySpecialist_GetByIdArgs = {
  input: GetSpecialistByIdInput;
};


export type QueryStats_GetActiveSpecialistsArgs = {
  input: StatsRangeInput;
};


export type QueryStats_GetServiceRequestsArgs = {
  input: StatsRangeInput;
};


export type QueryStats_GetServiceTypeCountsArgs = {
  input: StatsRangeInput;
};


export type QueryStats_GetTotalRevenueArgs = {
  input: StatsRangeInput;
};

export enum QuestionType {
  CheckBox = 'CHECK_BOX',
  RadioButton = 'RADIO_BUTTON'
}

export type QuestionTypeOperationFilterInput = {
  eq?: InputMaybe<QuestionType>;
  in?: InputMaybe<Array<QuestionType>>;
  neq?: InputMaybe<QuestionType>;
  nin?: InputMaybe<Array<QuestionType>>;
};

export type RateAndReviewDto = {
  __typename?: 'RateAndReviewDto';
  comment?: Maybe<Scalars['String']['output']>;
  rate: Scalars['Int']['output'];
};

/** A segment of a collection. */
export type RateAndReviewDtoCollectionSegment = {
  __typename?: 'RateAndReviewDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<RateAndReviewDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type RateAndReviewDtoFilterInput = {
  and?: InputMaybe<Array<RateAndReviewDtoFilterInput>>;
  comment?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<RateAndReviewDtoFilterInput>>;
  rate?: InputMaybe<IntOperationFilterInput>;
};

export type RateAndReviewDtoSortInput = {
  comment?: InputMaybe<SortEnumType>;
  rate?: InputMaybe<SortEnumType>;
};

export type RefreshTokenRequestInput = {
  accessToken: Scalars['String']['input'];
  refreshToken: Scalars['String']['input'];
};

export type RejectServiceRequestInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type RejectedServiceRequestDto = {
  __typename?: 'RejectedServiceRequestDto';
  serviceRequest: ServiceRequestDto;
  specialist: SpecialistDto;
};

export type RemoveDisabledServiceTimeInput = {
  id: Scalars['UUID']['input'];
};

export type RemoveDiscountCodeFromServiceRequestInput = {
  serviceRequestId: Scalars['UUID']['input'];
};

export type RequestOtpInput = {
  phoneNumber: Scalars['String']['input'];
  userType: UserType;
};

export type ResponseBase = {
  __typename?: 'ResponseBase';
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfAdminDto = {
  __typename?: 'ResponseBaseOfAdminDto';
  result?: Maybe<AdminDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfAuthResult = {
  __typename?: 'ResponseBaseOfAuthResult';
  result?: Maybe<AuthResult>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfBannerDto = {
  __typename?: 'ResponseBaseOfBannerDto';
  result?: Maybe<BannerDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfCancellationReasonDto = {
  __typename?: 'ResponseBaseOfCancellationReasonDto';
  result?: Maybe<CancellationReasonDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfCarouselDto = {
  __typename?: 'ResponseBaseOfCarouselDto';
  result?: Maybe<CarouselDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfCustomerDto = {
  __typename?: 'ResponseBaseOfCustomerDto';
  result?: Maybe<CustomerDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfDisabledServiceTimeDto = {
  __typename?: 'ResponseBaseOfDisabledServiceTimeDto';
  result?: Maybe<DisabledServiceTimeDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfDiscountCodeDto = {
  __typename?: 'ResponseBaseOfDiscountCodeDto';
  result?: Maybe<DiscountCodeDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfInt32 = {
  __typename?: 'ResponseBaseOfInt32';
  result: Scalars['Int']['output'];
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfPaymentDto = {
  __typename?: 'ResponseBaseOfPaymentDto';
  result?: Maybe<PaymentDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfProvinceDto = {
  __typename?: 'ResponseBaseOfProvinceDto';
  result?: Maybe<ProvinceDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfRateAndReviewDto = {
  __typename?: 'ResponseBaseOfRateAndReviewDto';
  result?: Maybe<RateAndReviewDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfRejectedServiceRequestDto = {
  __typename?: 'ResponseBaseOfRejectedServiceRequestDto';
  result?: Maybe<RejectedServiceRequestDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfS3MultipartUploadUrlsResultDto = {
  __typename?: 'ResponseBaseOfS3MultipartUploadUrlsResultDto';
  result?: Maybe<S3MultipartUploadUrlsResultDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfS3SinglepartUploadUrlsResultDto = {
  __typename?: 'ResponseBaseOfS3SinglepartUploadUrlsResultDto';
  result?: Maybe<S3SinglepartUploadUrlsResultDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfServiceCategoryDto = {
  __typename?: 'ResponseBaseOfServiceCategoryDto';
  result?: Maybe<ServiceCategoryDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfServiceRequestDto = {
  __typename?: 'ResponseBaseOfServiceRequestDto';
  result?: Maybe<ServiceRequestDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfServiceRequestsDto = {
  __typename?: 'ResponseBaseOfServiceRequestsDto';
  result?: Maybe<ServiceRequestsDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfServiceSubCategoryDto = {
  __typename?: 'ResponseBaseOfServiceSubCategoryDto';
  result?: Maybe<ServiceSubCategoryDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfServiceTypeDto = {
  __typename?: 'ResponseBaseOfServiceTypeDto';
  result?: Maybe<ServiceTypeDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfServiceTypeQuestionDto = {
  __typename?: 'ResponseBaseOfServiceTypeQuestionDto';
  result?: Maybe<ServiceTypeQuestionDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfSpecialistDto = {
  __typename?: 'ResponseBaseOfSpecialistDto';
  result?: Maybe<SpecialistDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfSpecialistRevenueDto = {
  __typename?: 'ResponseBaseOfSpecialistRevenueDto';
  result?: Maybe<SpecialistRevenueDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfTotalRevenueDto = {
  __typename?: 'ResponseBaseOfTotalRevenueDto';
  result?: Maybe<TotalRevenueDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type ResponseBaseOfUserProfileDto = {
  __typename?: 'ResponseBaseOfUserProfileDto';
  result?: Maybe<UserProfileDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type S3MultipartUploadUrlsResultDto = {
  __typename?: 'S3MultipartUploadUrlsResultDto';
  objectUrl: Scalars['String']['output'];
  presignedUrls: Array<Scalars['String']['output']>;
  uploadId: Scalars['String']['output'];
};

export type S3SinglepartUploadUrlsResultDto = {
  __typename?: 'S3SinglepartUploadUrlsResultDto';
  objectUrl: Scalars['String']['output'];
  presignedUrl: Scalars['String']['output'];
};

export type ServiceCategoryDto = {
  __typename?: 'ServiceCategoryDto';
  abbreviation: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  logo: Scalars['String']['output'];
  name: Scalars['String']['output'];
};

/** A segment of a collection. */
export type ServiceCategoryDtoCollectionSegment = {
  __typename?: 'ServiceCategoryDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceCategoryDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ServiceCategoryDtoFilterInput = {
  abbreviation?: InputMaybe<StringOperationFilterInput>;
  and?: InputMaybe<Array<ServiceCategoryDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceCategoryDtoFilterInput>>;
};

export type ServiceCategoryDtoSortInput = {
  abbreviation?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
};

export type ServiceRequestDto = {
  __typename?: 'ServiceRequestDto';
  address: AddressDto;
  basePrice: Scalars['Decimal']['output'];
  cancellationReason?: Maybe<CancellationReasonDto>;
  customer: CustomerDto;
  customerShare: Scalars['Decimal']['output'];
  description?: Maybe<Scalars['String']['output']>;
  discountAmount: Scalars['Decimal']['output'];
  finalPrice: Scalars['Decimal']['output'];
  id: Scalars['UUID']['output'];
  paidAt?: Maybe<Scalars['DateTime']['output']>;
  qnAs: Array<ServiceRequestQnADto>;
  rateAndReview?: Maybe<RateAndReviewDto>;
  requestDate: Scalars['DateTime']['output'];
  serviceType: ServiceTypeDto;
  settledAt?: Maybe<Scalars['DateTime']['output']>;
  specialist?: Maybe<SpecialistDto>;
  specialistGenderRequirement: Gender;
  status: ServiceRequestStatus;
  trackingCode: Scalars['String']['output'];
};

/** A segment of a collection. */
export type ServiceRequestDtoCollectionSegment = {
  __typename?: 'ServiceRequestDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceRequestDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ServiceRequestDtoFilterInput = {
  address?: InputMaybe<AddressDtoFilterInput>;
  and?: InputMaybe<Array<ServiceRequestDtoFilterInput>>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  cancellationReason?: InputMaybe<CancellationReasonDtoFilterInput>;
  customer?: InputMaybe<CustomerDtoFilterInput>;
  customerShare?: InputMaybe<DecimalOperationFilterInput>;
  description?: InputMaybe<StringOperationFilterInput>;
  discountAmount?: InputMaybe<DecimalOperationFilterInput>;
  finalPrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  or?: InputMaybe<Array<ServiceRequestDtoFilterInput>>;
  paidAt?: InputMaybe<DateTimeOperationFilterInput>;
  qnAs?: InputMaybe<ListFilterInputTypeOfServiceRequestQnADtoFilterInput>;
  rateAndReview?: InputMaybe<RateAndReviewDtoFilterInput>;
  requestDate?: InputMaybe<DateTimeOperationFilterInput>;
  serviceType?: InputMaybe<ServiceTypeDtoFilterInput>;
  settledAt?: InputMaybe<DateTimeOperationFilterInput>;
  specialist?: InputMaybe<SpecialistDtoFilterInput>;
  specialistGenderRequirement?: InputMaybe<GenderOperationFilterInput>;
  status?: InputMaybe<ServiceRequestStatusOperationFilterInput>;
  trackingCode?: InputMaybe<StringOperationFilterInput>;
};

export type ServiceRequestDtoSortInput = {
  address?: InputMaybe<AddressDtoSortInput>;
  basePrice?: InputMaybe<SortEnumType>;
  cancellationReason?: InputMaybe<CancellationReasonDtoSortInput>;
  customer?: InputMaybe<CustomerDtoSortInput>;
  customerShare?: InputMaybe<SortEnumType>;
  description?: InputMaybe<SortEnumType>;
  discountAmount?: InputMaybe<SortEnumType>;
  finalPrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  paidAt?: InputMaybe<SortEnumType>;
  rateAndReview?: InputMaybe<RateAndReviewDtoSortInput>;
  requestDate?: InputMaybe<SortEnumType>;
  serviceType?: InputMaybe<ServiceTypeDtoSortInput>;
  settledAt?: InputMaybe<SortEnumType>;
  specialist?: InputMaybe<SpecialistDtoSortInput>;
  specialistGenderRequirement?: InputMaybe<SortEnumType>;
  status?: InputMaybe<SortEnumType>;
  trackingCode?: InputMaybe<SortEnumType>;
};

export type ServiceRequestQnADto = {
  __typename?: 'ServiceRequestQnADto';
  answer?: Maybe<Scalars['String']['output']>;
  questionText: Scalars['String']['output'];
};

export type ServiceRequestQnADtoFilterInput = {
  and?: InputMaybe<Array<ServiceRequestQnADtoFilterInput>>;
  answer?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceRequestQnADtoFilterInput>>;
  questionText?: InputMaybe<StringOperationFilterInput>;
};

export enum ServiceRequestStatus {
  AcceptedBySpecialist = 'ACCEPTED_BY_SPECIALIST',
  CancelledByCustomer = 'CANCELLED_BY_CUSTOMER',
  CancelledBySpecialist = 'CANCELLED_BY_SPECIALIST',
  Paid = 'PAID',
  Pending = 'PENDING',
  PendingPayment = 'PENDING_PAYMENT',
  SettledWithSpecialist = 'SETTLED_WITH_SPECIALIST',
  SpecialistArrivedToLocation = 'SPECIALIST_ARRIVED_TO_LOCATION'
}

export type ServiceRequestStatusChangedNotification = {
  __typename?: 'ServiceRequestStatusChangedNotification';
  customerId: Scalars['UUID']['output'];
  newStatus: ServiceRequestStatus;
  payload?: Maybe<ServiceRequestDto>;
  serviceRequestId: Scalars['UUID']['output'];
  specialistId?: Maybe<Scalars['UUID']['output']>;
};

export type ServiceRequestStatusOperationFilterInput = {
  eq?: InputMaybe<ServiceRequestStatus>;
  in?: InputMaybe<Array<ServiceRequestStatus>>;
  neq?: InputMaybe<ServiceRequestStatus>;
  nin?: InputMaybe<Array<ServiceRequestStatus>>;
};

export type ServiceRequestsDto = {
  __typename?: 'ServiceRequestsDto';
  successfulRequests: Scalars['Int']['output'];
  totalRequests: Scalars['Int']['output'];
};

export type ServiceSubCategoryDto = {
  __typename?: 'ServiceSubCategoryDto';
  abbreviation: Scalars['String']['output'];
  id: Scalars['UUID']['output'];
  logo: Scalars['String']['output'];
  name: Scalars['String']['output'];
  serviceCategory: ServiceCategoryDto;
};

/** A segment of a collection. */
export type ServiceSubCategoryDtoCollectionSegment = {
  __typename?: 'ServiceSubCategoryDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceSubCategoryDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ServiceSubCategoryDtoFilterInput = {
  abbreviation?: InputMaybe<StringOperationFilterInput>;
  and?: InputMaybe<Array<ServiceSubCategoryDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceSubCategoryDtoFilterInput>>;
  serviceCategory?: InputMaybe<ServiceCategoryDtoFilterInput>;
};

export type ServiceSubCategoryDtoSortInput = {
  abbreviation?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  serviceCategory?: InputMaybe<ServiceCategoryDtoSortInput>;
};

export type ServiceTypeCountDto = {
  __typename?: 'ServiceTypeCountDto';
  count: Scalars['Int']['output'];
  serviceTypeId: Scalars['UUID']['output'];
  serviceTypeName: Scalars['String']['output'];
};

/** A segment of a collection. */
export type ServiceTypeCountDtoCollectionSegment = {
  __typename?: 'ServiceTypeCountDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceTypeCountDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ServiceTypeCountDtoFilterInput = {
  and?: InputMaybe<Array<ServiceTypeCountDtoFilterInput>>;
  count?: InputMaybe<IntOperationFilterInput>;
  or?: InputMaybe<Array<ServiceTypeCountDtoFilterInput>>;
  serviceTypeId?: InputMaybe<UuidOperationFilterInput>;
  serviceTypeName?: InputMaybe<StringOperationFilterInput>;
};

export type ServiceTypeCountDtoSortInput = {
  count?: InputMaybe<SortEnumType>;
  serviceTypeId?: InputMaybe<SortEnumType>;
  serviceTypeName?: InputMaybe<SortEnumType>;
};

export type ServiceTypeDto = {
  __typename?: 'ServiceTypeDto';
  abbreviation: Scalars['String']['output'];
  banner: Scalars['String']['output'];
  basePrice: Scalars['Decimal']['output'];
  id: Scalars['UUID']['output'];
  isSpecial: Scalars['Boolean']['output'];
  logo: Scalars['String']['output'];
  name: Scalars['String']['output'];
  serviceSubCategory: ServiceSubCategoryDto;
};

/** A segment of a collection. */
export type ServiceTypeDtoCollectionSegment = {
  __typename?: 'ServiceTypeDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceTypeDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ServiceTypeDtoFilterInput = {
  abbreviation?: InputMaybe<StringOperationFilterInput>;
  and?: InputMaybe<Array<ServiceTypeDtoFilterInput>>;
  banner?: InputMaybe<StringOperationFilterInput>;
  basePrice?: InputMaybe<DecimalOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isSpecial?: InputMaybe<BooleanOperationFilterInput>;
  logo?: InputMaybe<StringOperationFilterInput>;
  name?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceTypeDtoFilterInput>>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
};

export type ServiceTypeDtoSortInput = {
  abbreviation?: InputMaybe<SortEnumType>;
  banner?: InputMaybe<SortEnumType>;
  basePrice?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  isSpecial?: InputMaybe<SortEnumType>;
  logo?: InputMaybe<SortEnumType>;
  name?: InputMaybe<SortEnumType>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoSortInput>;
};

export type ServiceTypeQuestionDto = {
  __typename?: 'ServiceTypeQuestionDto';
  id: Scalars['UUID']['output'];
  isRequired: Scalars['Boolean']['output'];
  options: Array<Scalars['String']['output']>;
  questionType: QuestionType;
  serviceType: ServiceTypeDto;
  text: Scalars['String']['output'];
};

/** A segment of a collection. */
export type ServiceTypeQuestionDtoCollectionSegment = {
  __typename?: 'ServiceTypeQuestionDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<ServiceTypeQuestionDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type ServiceTypeQuestionDtoFilterInput = {
  and?: InputMaybe<Array<ServiceTypeQuestionDtoFilterInput>>;
  id?: InputMaybe<UuidOperationFilterInput>;
  isRequired?: InputMaybe<BooleanOperationFilterInput>;
  options?: InputMaybe<ListStringOperationFilterInput>;
  or?: InputMaybe<Array<ServiceTypeQuestionDtoFilterInput>>;
  questionType?: InputMaybe<QuestionTypeOperationFilterInput>;
  serviceType?: InputMaybe<ServiceTypeDtoFilterInput>;
  text?: InputMaybe<StringOperationFilterInput>;
};

export type ServiceTypeQuestionDtoSortInput = {
  id?: InputMaybe<SortEnumType>;
  isRequired?: InputMaybe<SortEnumType>;
  questionType?: InputMaybe<SortEnumType>;
  serviceType?: InputMaybe<ServiceTypeDtoSortInput>;
  text?: InputMaybe<SortEnumType>;
};

export type SetActiveBannerInput = {
  bannerId?: InputMaybe<Scalars['UUID']['input']>;
  cityId: Scalars['UUID']['input'];
};

export type SetActiveCarouselInput = {
  carouselId?: InputMaybe<Scalars['UUID']['input']>;
  cityId: Scalars['UUID']['input'];
};

export type SetCityAvailableServiceTypesInput = {
  cityId: Scalars['UUID']['input'];
  serviceTypeIds: Array<Scalars['UUID']['input']>;
};

export type SetLocationAndSpecialtyInput = {
  cityId: Scalars['UUID']['input'];
  serviceSubCategoryId: Scalars['UUID']['input'];
  serviceTypeIds: Array<Scalars['UUID']['input']>;
};

export type SetPersonalInformationInput = {
  birthDate: Scalars['DateTime']['input'];
  firstName: Scalars['String']['input'];
  gender: Gender;
  idCardImageUrl?: InputMaybe<Scalars['String']['input']>;
  lastName: Scalars['String']['input'];
  nationalCode: Scalars['String']['input'];
  profileImageUrl?: InputMaybe<Scalars['String']['input']>;
};

export type SetPrimaryAddressInput = {
  addressId: Scalars['UUID']['input'];
};

export type SetUserBlockStateInput = {
  isBlocked: Scalars['Boolean']['input'];
  userId: Scalars['UUID']['input'];
};

export type SingleResponseBaseOfAddressDto = {
  __typename?: 'SingleResponseBaseOfAddressDto';
  result?: Maybe<AddressDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type SingleResponseBaseOfCityDto = {
  __typename?: 'SingleResponseBaseOfCityDto';
  result?: Maybe<CityDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type SingleResponseBaseOfServiceRequestDto = {
  __typename?: 'SingleResponseBaseOfServiceRequestDto';
  result?: Maybe<ServiceRequestDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export type SingleResponseBaseOfServiceTypeQuestionDto = {
  __typename?: 'SingleResponseBaseOfServiceTypeQuestionDto';
  result?: Maybe<ServiceTypeQuestionDto>;
  status?: Maybe<Scalars['Any']['output']>;
};

export enum SortEnumType {
  Asc = 'ASC',
  Desc = 'DESC'
}

export type SpecialistDto = {
  __typename?: 'SpecialistDto';
  acceptedMissions: Scalars['Int']['output'];
  averageRating: Scalars['Float']['output'];
  birthDate: Scalars['DateTime']['output'];
  cancelledMissions: Scalars['Int']['output'];
  city?: Maybe<CityDto>;
  code: Scalars['String']['output'];
  daysRegistered: Scalars['Int']['output'];
  firstName?: Maybe<Scalars['String']['output']>;
  gender: Gender;
  id: Scalars['UUID']['output'];
  idCardImageUrl?: Maybe<Scalars['String']['output']>;
  idCardVerificationStatus: VerificationStatus;
  identityVerificationVideoStatus: VerificationStatus;
  identityVerificationVideoUrl?: Maybe<Scalars['String']['output']>;
  isBlocked: Scalars['Boolean']['output'];
  lastName?: Maybe<Scalars['String']['output']>;
  nationalCode?: Maybe<Scalars['String']['output']>;
  phoneNumber: Scalars['String']['output'];
  profileImageUrl?: Maybe<Scalars['String']['output']>;
  rateCount: Scalars['Int']['output'];
  registeredAt: Scalars['DateTime']['output'];
  rejectedMissions: Scalars['Int']['output'];
  serviceSubCategory?: Maybe<ServiceSubCategoryDto>;
  serviceTypes: Array<ServiceTypeDto>;
  specializedDocumentUrls?: Maybe<Array<Scalars['String']['output']>>;
  specializedDocumentsVerificationStatus: VerificationStatus;
  successfulMissions: Scalars['Int']['output'];
};

/** A segment of a collection. */
export type SpecialistDtoCollectionSegment = {
  __typename?: 'SpecialistDtoCollectionSegment';
  /** A flattened list of the items. */
  items?: Maybe<Array<SpecialistDto>>;
  /** Information to aid in pagination. */
  pageInfo: CollectionSegmentInfo;
  totalCount: Scalars['Int']['output'];
};

export type SpecialistDtoFilterInput = {
  acceptedMissions?: InputMaybe<IntOperationFilterInput>;
  and?: InputMaybe<Array<SpecialistDtoFilterInput>>;
  averageRating?: InputMaybe<FloatOperationFilterInput>;
  birthDate?: InputMaybe<DateTimeOperationFilterInput>;
  cancelledMissions?: InputMaybe<IntOperationFilterInput>;
  city?: InputMaybe<CityDtoFilterInput>;
  code?: InputMaybe<StringOperationFilterInput>;
  daysRegistered?: InputMaybe<IntOperationFilterInput>;
  firstName?: InputMaybe<StringOperationFilterInput>;
  gender?: InputMaybe<GenderOperationFilterInput>;
  id?: InputMaybe<UuidOperationFilterInput>;
  idCardImageUrl?: InputMaybe<StringOperationFilterInput>;
  idCardVerificationStatus?: InputMaybe<VerificationStatusOperationFilterInput>;
  identityVerificationVideoStatus?: InputMaybe<VerificationStatusOperationFilterInput>;
  identityVerificationVideoUrl?: InputMaybe<StringOperationFilterInput>;
  isBlocked?: InputMaybe<BooleanOperationFilterInput>;
  lastName?: InputMaybe<StringOperationFilterInput>;
  nationalCode?: InputMaybe<StringOperationFilterInput>;
  or?: InputMaybe<Array<SpecialistDtoFilterInput>>;
  phoneNumber?: InputMaybe<StringOperationFilterInput>;
  profileImageUrl?: InputMaybe<StringOperationFilterInput>;
  rateCount?: InputMaybe<IntOperationFilterInput>;
  registeredAt?: InputMaybe<DateTimeOperationFilterInput>;
  rejectedMissions?: InputMaybe<IntOperationFilterInput>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
  serviceTypes?: InputMaybe<ListFilterInputTypeOfServiceTypeDtoFilterInput>;
  specializedDocumentUrls?: InputMaybe<ListStringOperationFilterInput>;
  specializedDocumentsVerificationStatus?: InputMaybe<VerificationStatusOperationFilterInput>;
  successfulMissions?: InputMaybe<IntOperationFilterInput>;
};

export type SpecialistDtoSortInput = {
  acceptedMissions?: InputMaybe<SortEnumType>;
  averageRating?: InputMaybe<SortEnumType>;
  birthDate?: InputMaybe<SortEnumType>;
  cancelledMissions?: InputMaybe<SortEnumType>;
  city?: InputMaybe<CityDtoSortInput>;
  code?: InputMaybe<SortEnumType>;
  daysRegistered?: InputMaybe<SortEnumType>;
  firstName?: InputMaybe<SortEnumType>;
  gender?: InputMaybe<SortEnumType>;
  id?: InputMaybe<SortEnumType>;
  idCardImageUrl?: InputMaybe<SortEnumType>;
  idCardVerificationStatus?: InputMaybe<SortEnumType>;
  identityVerificationVideoStatus?: InputMaybe<SortEnumType>;
  identityVerificationVideoUrl?: InputMaybe<SortEnumType>;
  isBlocked?: InputMaybe<SortEnumType>;
  lastName?: InputMaybe<SortEnumType>;
  nationalCode?: InputMaybe<SortEnumType>;
  phoneNumber?: InputMaybe<SortEnumType>;
  profileImageUrl?: InputMaybe<SortEnumType>;
  rateCount?: InputMaybe<SortEnumType>;
  registeredAt?: InputMaybe<SortEnumType>;
  rejectedMissions?: InputMaybe<SortEnumType>;
  serviceSubCategory?: InputMaybe<ServiceSubCategoryDtoSortInput>;
  specializedDocumentsVerificationStatus?: InputMaybe<SortEnumType>;
  successfulMissions?: InputMaybe<SortEnumType>;
};

export type SpecialistRevenueDto = {
  __typename?: 'SpecialistRevenueDto';
  settledAmount: Scalars['Decimal']['output'];
  specialist: SpecialistDto;
  totalAmount: Scalars['Decimal']['output'];
  unsettledAmount: Scalars['Decimal']['output'];
};

export type StatsRangeInput = {
  endDate?: InputMaybe<Scalars['DateTime']['input']>;
  startDate?: InputMaybe<Scalars['DateTime']['input']>;
};

export type StringOperationFilterInput = {
  and?: InputMaybe<Array<StringOperationFilterInput>>;
  contains?: InputMaybe<Scalars['String']['input']>;
  endsWith?: InputMaybe<Scalars['String']['input']>;
  eq?: InputMaybe<Scalars['String']['input']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  ncontains?: InputMaybe<Scalars['String']['input']>;
  nendsWith?: InputMaybe<Scalars['String']['input']>;
  neq?: InputMaybe<Scalars['String']['input']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['String']['input']>>>;
  nstartsWith?: InputMaybe<Scalars['String']['input']>;
  or?: InputMaybe<Array<StringOperationFilterInput>>;
  startsWith?: InputMaybe<Scalars['String']['input']>;
};

export type Subscription = {
  __typename?: 'Subscription';
  onServiceRequestStatusChanged: ServiceRequestStatusChangedNotification;
};


export type SubscriptionOnServiceRequestStatusChangedArgs = {
  userId: Scalars['UUID']['input'];
};

export type TotalRevenueDto = {
  __typename?: 'TotalRevenueDto';
  totalGross: Scalars['Decimal']['output'];
  totalPlatformShare: Scalars['Decimal']['output'];
  totalSpecialistShare: Scalars['Decimal']['output'];
};

export type UpdateAddressInput = {
  addressId: Scalars['UUID']['input'];
  buildingNumber: Scalars['Int']['input'];
  floorNumber: Scalars['Int']['input'];
  newLatitude: Scalars['Float']['input'];
  newLongitude: Scalars['Float']['input'];
  newText: Scalars['String']['input'];
  newTitle: Scalars['String']['input'];
  unitNumber: Scalars['Int']['input'];
};

export type UpdateBannerInput = {
  id: Scalars['UUID']['input'];
  imageUrl: Scalars['String']['input'];
  title: Scalars['String']['input'];
};

export type UpdateCancellationReasonInput = {
  id: Scalars['UUID']['input'];
  name: Scalars['String']['input'];
  targets: Array<UserType>;
};

export type UpdateCarouselInput = {
  id: Scalars['UUID']['input'];
  serviceTypeIds: Array<Scalars['UUID']['input']>;
  title: Scalars['String']['input'];
};

export type UpdateCityBoundaryInput = {
  cityId: Scalars['UUID']['input'];
  newWktBoundary: Scalars['String']['input'];
};

export type UpdateCityInput = {
  abbreviation: Scalars['String']['input'];
  cityId: Scalars['UUID']['input'];
  newName: Scalars['String']['input'];
};

export type UpdateIdentityVerificationVideoInput = {
  newVideoUrl: Scalars['String']['input'];
};

export type UpdateProvinceInput = {
  abbreviation: Scalars['String']['input'];
  id: Scalars['UUID']['input'];
  name: Scalars['String']['input'];
};

export type UpdateServiceCategoryInput = {
  abbreviation: Scalars['String']['input'];
  newLogo: Scalars['String']['input'];
  newName: Scalars['String']['input'];
  serviceCategoryId: Scalars['UUID']['input'];
};

export type UpdateServiceSubCategoryInput = {
  abbreviation: Scalars['String']['input'];
  newLogo: Scalars['String']['input'];
  newName: Scalars['String']['input'];
  serviceSubCategoryId: Scalars['UUID']['input'];
};

export type UpdateServiceTypeInput = {
  abbreviation: Scalars['String']['input'];
  banner: Scalars['String']['input'];
  basePrice: Scalars['Decimal']['input'];
  id: Scalars['UUID']['input'];
  isSpecial: Scalars['Boolean']['input'];
  logo: Scalars['String']['input'];
  name: Scalars['String']['input'];
};

export type UpdateServiceTypeQuestionInput = {
  id: Scalars['UUID']['input'];
  isRequired: Scalars['Boolean']['input'];
  options: Array<Scalars['String']['input']>;
  questionType: QuestionType;
  title: Scalars['String']['input'];
};

export type UpdateSpecializedDocumentsInput = {
  newDocumentUrls: Array<Scalars['String']['input']>;
};

export type UpdateUserProfileInput = {
  firstName: Scalars['String']['input'];
  gender: Gender;
  lastName: Scalars['String']['input'];
  profileImageUrl?: InputMaybe<Scalars['String']['input']>;
};

export type UserProfileDto = {
  __typename?: 'UserProfileDto';
  code: Scalars['String']['output'];
  firstName?: Maybe<Scalars['String']['output']>;
  gender: Gender;
  id: Scalars['UUID']['output'];
  isBlocked: Scalars['Boolean']['output'];
  lastName?: Maybe<Scalars['String']['output']>;
  phoneNumber: Scalars['String']['output'];
  profileImageUrl?: Maybe<Scalars['String']['output']>;
};

export enum UserType {
  Admin = 'ADMIN',
  Customer = 'CUSTOMER',
  Specialist = 'SPECIALIST'
}

export type UserTypeOperationFilterInput = {
  eq?: InputMaybe<UserType>;
  in?: InputMaybe<Array<UserType>>;
  neq?: InputMaybe<UserType>;
  nin?: InputMaybe<Array<UserType>>;
};

export type UuidOperationFilterInput = {
  eq?: InputMaybe<Scalars['UUID']['input']>;
  gt?: InputMaybe<Scalars['UUID']['input']>;
  gte?: InputMaybe<Scalars['UUID']['input']>;
  in?: InputMaybe<Array<InputMaybe<Scalars['UUID']['input']>>>;
  lt?: InputMaybe<Scalars['UUID']['input']>;
  lte?: InputMaybe<Scalars['UUID']['input']>;
  neq?: InputMaybe<Scalars['UUID']['input']>;
  ngt?: InputMaybe<Scalars['UUID']['input']>;
  ngte?: InputMaybe<Scalars['UUID']['input']>;
  nin?: InputMaybe<Array<InputMaybe<Scalars['UUID']['input']>>>;
  nlt?: InputMaybe<Scalars['UUID']['input']>;
  nlte?: InputMaybe<Scalars['UUID']['input']>;
};

export enum VerificationStatus {
  Approved = 'APPROVED',
  Pending = 'PENDING',
  Rejected = 'REJECTED'
}

export type VerificationStatusOperationFilterInput = {
  eq?: InputMaybe<VerificationStatus>;
  in?: InputMaybe<Array<VerificationStatus>>;
  neq?: InputMaybe<VerificationStatus>;
  nin?: InputMaybe<Array<VerificationStatus>>;
};

export type VerifyIdCardInput = {
  specialistId: Scalars['UUID']['input'];
  status: VerificationStatus;
};

export type VerifyIdentityVerificationVideoInput = {
  specialistId: Scalars['UUID']['input'];
  status: VerificationStatus;
};

export type VerifyOtpInput = {
  otp: Scalars['String']['input'];
  phoneNumber: Scalars['String']['input'];
  userType: UserType;
};

export type VerifySpecializedDocumentsInput = {
  specialistId: Scalars['UUID']['input'];
  status: VerificationStatus;
};

export type Admin_CreateMutationVariables = Exact<{
  input: CreateAdminInput;
}>;


export type Admin_CreateMutation = { __typename?: 'Mutation', admin_create: { __typename?: 'ResponseBase', status?: any | null } };

export type Admin_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<AdminDtoFilterInput>;
  order?: InputMaybe<Array<AdminDtoSortInput> | AdminDtoSortInput>;
}>;


export type Admin_GetAllQuery = { __typename?: 'Query', admin_getAll: { __typename?: 'ListResponseBaseOfAdminDto', status?: any | null, result?: { __typename?: 'AdminDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'AdminDto', firstName?: string | null, code: string, gender: Gender, id: any, phoneNumber: string, isBlocked: boolean, lastName?: string | null, profileImageUrl?: string | null }> | null } | null } };

export type User_SetBlockStateMutationVariables = Exact<{
  input: SetUserBlockStateInput;
}>;


export type User_SetBlockStateMutation = { __typename?: 'Mutation', user_setBlockState: { __typename?: 'ResponseBase', status?: any | null } };

export type Banner_CreateMutationVariables = Exact<{
  input: CreateBannerInput;
}>;


export type Banner_CreateMutation = { __typename?: 'Mutation', banner_create: { __typename?: 'ResponseBaseOfBannerDto', status?: any | null, result?: { __typename?: 'BannerDto', id: any, title: string, imageUrl: string } | null } };

export type Banner_UpdateMutationVariables = Exact<{
  input: UpdateBannerInput;
}>;


export type Banner_UpdateMutation = { __typename?: 'Mutation', banner_update: { __typename?: 'ResponseBaseOfBannerDto', status?: any | null, result?: { __typename?: 'BannerDto', id: any, title: string, imageUrl: string } | null } };

export type Banner_DeleteMutationVariables = Exact<{
  input: DeleteBannerInput;
}>;


export type Banner_DeleteMutation = { __typename?: 'Mutation', banner_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type Banner_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<BannerDtoFilterInput>;
  order?: InputMaybe<Array<BannerDtoSortInput> | BannerDtoSortInput>;
}>;


export type Banner_GetAllQuery = { __typename?: 'Query', banner_getAll: { __typename?: 'ListResponseBaseOfBannerDto', status?: any | null, result?: { __typename?: 'BannerDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'BannerDto', id: any, imageUrl: string, title: string }> | null } | null } };

export type City_SetActiveBannerMutationVariables = Exact<{
  input: SetActiveBannerInput;
}>;


export type City_SetActiveBannerMutation = { __typename?: 'Mutation', city_setActiveBanner: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type City_SetActiveCarouselMutationVariables = Exact<{
  input: SetActiveCarouselInput;
}>;


export type City_SetActiveCarouselMutation = { __typename?: 'Mutation', city_setActiveCarousel: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type Carousel_CreateMutationVariables = Exact<{
  input: CreateCarouselInput;
}>;


export type Carousel_CreateMutation = { __typename?: 'Mutation', carousel_create: { __typename?: 'ResponseBaseOfCarouselDto', status?: any | null, result?: { __typename?: 'CarouselDto', id: any, title: string } | null } };

export type Carousel_UpdateMutationVariables = Exact<{
  input: UpdateCarouselInput;
}>;


export type Carousel_UpdateMutation = { __typename?: 'Mutation', carousel_update: { __typename?: 'ResponseBaseOfCarouselDto', status?: any | null, result?: { __typename?: 'CarouselDto', id: any, title: string } | null } };

export type Carousel_DeleteMutationVariables = Exact<{
  input: DeleteCarouselInput;
}>;


export type Carousel_DeleteMutation = { __typename?: 'Mutation', carousel_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type Carousel_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CarouselDtoFilterInput>;
  order?: InputMaybe<Array<CarouselDtoSortInput> | CarouselDtoSortInput>;
}>;


export type Carousel_GetAllQuery = { __typename?: 'Query', carousel_getAll: { __typename?: 'ListResponseBaseOfCarouselDto', status?: any | null, result?: { __typename?: 'CarouselDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'CarouselDto', id: any, title: string, serviceTypes: Array<{ __typename?: 'ServiceTypeDto', id: any, name: string, logo: string, banner: string, serviceSubCategory: { __typename?: 'ServiceSubCategoryDto', id: any } }> }> | null } | null } };

export type City_CreateCityMutationVariables = Exact<{
  input: CreateCityInput;
}>;


export type City_CreateCityMutation = { __typename?: 'Mutation', city_create: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type CreateProvinceMutationVariables = Exact<{
  input: CreateProvinceInput;
}>;


export type CreateProvinceMutation = { __typename?: 'Mutation', province_create: { __typename?: 'ResponseBaseOfProvinceDto', status?: any | null, result?: { __typename?: 'ProvinceDto', id: any, name: string } | null } };

export type City_ActivateMutationVariables = Exact<{
  input: ActivateCityInput;
}>;


export type City_ActivateMutation = { __typename?: 'Mutation', city_activate: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type City_DeactivateMutationVariables = Exact<{
  input: DeactivateCityInput;
}>;


export type City_DeactivateMutation = { __typename?: 'Mutation', city_deactivate: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type City_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CityDtoFilterInput>;
  order?: InputMaybe<Array<CityDtoSortInput> | CityDtoSortInput>;
}>;


export type City_GetAllQuery = { __typename?: 'Query', city_getAll: { __typename?: 'ListResponseBaseOfCityDto', result?: { __typename?: 'CityDtoCollectionSegment', items?: Array<{ __typename?: 'CityDto', id: any, abbreviation: string, boundary: string, name: string, isActive: boolean, province: { __typename?: 'ProvinceDto', id: any, name: string }, activeBanner?: { __typename?: 'BannerDto', id: any, title: string, imageUrl: string } | null, activeCarousel?: { __typename?: 'CarouselDto', id: any, title: string } | null }> | null } | null } };

export type City_UpdateCityMutationVariables = Exact<{
  input: UpdateCityInput;
}>;


export type City_UpdateCityMutation = { __typename?: 'Mutation', city_update: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type ProvincesQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ProvinceDtoFilterInput>;
  order?: InputMaybe<Array<ProvinceDtoSortInput> | ProvinceDtoSortInput>;
}>;


export type ProvincesQuery = { __typename?: 'Query', province_getAll: { __typename?: 'ListResponseBaseOfProvinceDto', result?: { __typename?: 'ProvinceDtoCollectionSegment', items?: Array<{ __typename?: 'ProvinceDto', name: string, id: any, abbreviation: string }> | null } | null } };

export type Province_UpdateMutationVariables = Exact<{
  input: UpdateProvinceInput;
}>;


export type Province_UpdateMutation = { __typename?: 'Mutation', province_update: { __typename?: 'ResponseBaseOfProvinceDto', status?: any | null, result?: { __typename?: 'ProvinceDto', id: any, name: string } | null } };

export type Province_DeleteMutationVariables = Exact<{
  input: DeleteProvinceInput;
}>;


export type Province_DeleteMutation = { __typename?: 'Mutation', province_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type City_UpdateBoundaryMutationVariables = Exact<{
  input: UpdateCityBoundaryInput;
}>;


export type City_UpdateBoundaryMutation = { __typename?: 'Mutation', city_updateBoundary: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type City_SetAvailableServiceTypesMutationVariables = Exact<{
  input: SetCityAvailableServiceTypesInput;
}>;


export type City_SetAvailableServiceTypesMutation = { __typename?: 'Mutation', city_setAvailableServiceTypes: { __typename?: 'SingleResponseBaseOfCityDto', status?: any | null } };

export type City_GetAvailableServiceTypesQueryVariables = Exact<{
  input: GetAvailableServiceTypesForCityInput;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeDtoFilterInput>;
  order?: InputMaybe<Array<ServiceTypeDtoSortInput> | ServiceTypeDtoSortInput>;
}>;


export type City_GetAvailableServiceTypesQuery = { __typename?: 'Query', city_getAvailableServiceTypes: { __typename?: 'ListResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceTypeDto', name: string, logo: string, id: any, isSpecial: boolean }> | null } | null } };

export type Customer_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CustomerDtoFilterInput>;
  order?: InputMaybe<Array<CustomerDtoSortInput> | CustomerDtoSortInput>;
}>;


export type Customer_GetAllQuery = { __typename?: 'Query', customer_getAll: { __typename?: 'ListResponseBaseOfCustomerDto', status?: any | null, result?: { __typename?: 'CustomerDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'CustomerDto', code: string, firstName?: string | null, gender: Gender, id: any, lastName?: string | null, phoneNumber: string, profileImageUrl?: string | null, isBlocked: boolean }> | null } | null } };

export type Stats_GetActiveSpecialistsQueryVariables = Exact<{
  input: StatsRangeInput;
}>;


export type Stats_GetActiveSpecialistsQuery = { __typename?: 'Query', stats_getActiveSpecialists: { __typename?: 'ResponseBaseOfInt32', status?: any | null, result: number } };

export type Stats_GetTotalRevenueQueryVariables = Exact<{
  input: StatsRangeInput;
}>;


export type Stats_GetTotalRevenueQuery = { __typename?: 'Query', stats_getTotalRevenue: { __typename?: 'ResponseBaseOfTotalRevenueDto', status?: any | null, result?: { __typename?: 'TotalRevenueDto', totalGross: any, totalPlatformShare: any, totalSpecialistShare: any } | null } };

export type Stats_GetServiceRequestsQueryVariables = Exact<{
  input: StatsRangeInput;
}>;


export type Stats_GetServiceRequestsQuery = { __typename?: 'Query', stats_getServiceRequests: { __typename?: 'ResponseBaseOfServiceRequestsDto', status?: any | null, result?: { __typename?: 'ServiceRequestsDto', totalRequests: number, successfulRequests: number } | null } };

export type Stats_GetServiceTypeCountsQueryVariables = Exact<{
  input: StatsRangeInput;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeCountDtoFilterInput>;
  order?: InputMaybe<Array<ServiceTypeCountDtoSortInput> | ServiceTypeCountDtoSortInput>;
}>;


export type Stats_GetServiceTypeCountsQuery = { __typename?: 'Query', stats_getServiceTypeCounts: { __typename?: 'ListResponseBaseOfServiceTypeCountDto', status?: any | null, result?: { __typename?: 'ServiceTypeCountDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceTypeCountDto', count: number, serviceTypeId: any, serviceTypeName: string }> | null } | null } };

export type DiscountCode_CreateMutationVariables = Exact<{
  input: CreateDiscountCodeInput;
}>;


export type DiscountCode_CreateMutation = { __typename?: 'Mutation', discountCode_create: { __typename?: 'ResponseBaseOfDiscountCodeDto', status?: any | null } };

export type DiscountCode_DeleteMutationVariables = Exact<{
  input: DeleteDiscountCodeInput;
}>;


export type DiscountCode_DeleteMutation = { __typename?: 'Mutation', discountCode_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type DiscountCode_ActivateMutationVariables = Exact<{
  input: ActivateDiscountCodeInput;
}>;


export type DiscountCode_ActivateMutation = { __typename?: 'Mutation', discountCode_activate: { __typename?: 'ResponseBaseOfDiscountCodeDto', status?: any | null } };

export type DiscountCode_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<DiscountCodeDtoFilterInput>;
  order?: InputMaybe<Array<DiscountCodeDtoSortInput> | DiscountCodeDtoSortInput>;
}>;


export type DiscountCode_GetAllQuery = { __typename?: 'Query', discountCode_getAll: { __typename?: 'ListResponseBaseOfDiscountCodeDto', status?: any | null, result?: { __typename?: 'DiscountCodeDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'DiscountCodeDto', amount: any, id: any, code: string, expiryDate?: any | null, isPercentage: boolean, isActive: boolean, title: string, customer: { __typename?: 'CustomerDto', id: any, firstName?: string | null, lastName?: string | null } }> | null } | null } };

export type DiscountCode_DeactivateMutationVariables = Exact<{
  input: DeactivateDiscountCodeInput;
}>;


export type DiscountCode_DeactivateMutation = { __typename?: 'Mutation', discountCode_deactivate: { __typename?: 'ResponseBaseOfDiscountCodeDto', status?: any | null } };

export type Auth_RequestOtpMutationVariables = Exact<{
  input: RequestOtpInput;
}>;


export type Auth_RequestOtpMutation = { __typename?: 'Mutation', auth_requestOtp: { __typename?: 'ResponseBase', status?: any | null } };

export type Auth_VerifyOtpMutationVariables = Exact<{
  input: VerifyOtpInput;
}>;


export type Auth_VerifyOtpMutation = { __typename?: 'Mutation', auth_verifyOtp: { __typename?: 'ResponseBaseOfAuthResult', status?: any | null, result?: { __typename?: 'AuthResult', accessToken: string, refreshToken: string } | null } };

export type Auth_RefreshTokenMutationVariables = Exact<{
  input: RefreshTokenRequestInput;
}>;


export type Auth_RefreshTokenMutation = { __typename?: 'Mutation', auth_refreshToken: { __typename?: 'ResponseBaseOfAuthResult', status?: any | null, result?: { __typename?: 'AuthResult', accessToken: string, refreshToken: string } | null } };

export type ServiceTypeQuestion_CreateMutationVariables = Exact<{
  input: CreateServiceTypeQuestionInput;
}>;


export type ServiceTypeQuestion_CreateMutation = { __typename?: 'Mutation', serviceTypeQuestion_create: { __typename?: 'ResponseBaseOfServiceTypeQuestionDto', status?: any | null } };

export type ServiceTypeQuestion_UpdateMutationVariables = Exact<{
  input: UpdateServiceTypeQuestionInput;
}>;


export type ServiceTypeQuestion_UpdateMutation = { __typename?: 'Mutation', serviceTypeQuestion_update: { __typename?: 'ResponseBaseOfServiceTypeQuestionDto', status?: any | null } };

export type ServiceTypeQuestion_GetByServiceTypeQueryVariables = Exact<{
  input: GetServiceTypeQuestionsByServiceTypeInput;
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeQuestionDtoFilterInput>;
  order?: InputMaybe<Array<ServiceTypeQuestionDtoSortInput> | ServiceTypeQuestionDtoSortInput>;
}>;


export type ServiceTypeQuestion_GetByServiceTypeQuery = { __typename?: 'Query', serviceTypeQuestion_getByServiceType: { __typename?: 'ListResponseBaseOfServiceTypeQuestionDto', status?: any | null, result?: { __typename?: 'ServiceTypeQuestionDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceTypeQuestionDto', id: any, isRequired: boolean, options: Array<string>, questionType: QuestionType, text: string, serviceType: { __typename?: 'ServiceTypeDto', id: any, serviceSubCategory: { __typename?: 'ServiceSubCategoryDto', id: any, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any } } } }> | null } | null } };

export type CancellationReason_CreateMutationVariables = Exact<{
  input: CreateCancellationReasonInput;
}>;


export type CancellationReason_CreateMutation = { __typename?: 'Mutation', cancellationReason_create: { __typename?: 'ResponseBaseOfCancellationReasonDto', status?: any | null } };

export type CancellationReason_UpdateMutationVariables = Exact<{
  input: UpdateCancellationReasonInput;
}>;


export type CancellationReason_UpdateMutation = { __typename?: 'Mutation', cancellationReason_update: { __typename?: 'ResponseBaseOfCancellationReasonDto', status?: any | null } };

export type CancellationReason_DeleteMutationVariables = Exact<{
  input: DeleteCancellationReasonInput;
}>;


export type CancellationReason_DeleteMutation = { __typename?: 'Mutation', cancellationReason_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type CancellationReason_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<CancellationReasonDtoFilterInput>;
  order?: InputMaybe<Array<CancellationReasonDtoSortInput> | CancellationReasonDtoSortInput>;
}>;


export type CancellationReason_GetAllQuery = { __typename?: 'Query', cancellationReason_getAll: { __typename?: 'ListResponseBaseOfCancellationReasonDto', status?: any | null, result?: { __typename?: 'CancellationReasonDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'CancellationReasonDto', name: string, id: any, targets: Array<UserType> }> | null } | null } };

export type ServiceRequest_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceRequestDtoFilterInput>;
  order?: InputMaybe<Array<ServiceRequestDtoSortInput> | ServiceRequestDtoSortInput>;
}>;


export type ServiceRequest_GetAllQuery = { __typename?: 'Query', serviceRequest_getAll: { __typename?: 'ListResponseBaseOfServiceRequestDto', status?: any | null, result?: { __typename?: 'ServiceRequestDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceRequestDto', trackingCode: string, basePrice: any, description?: string | null, discountAmount: any, finalPrice: any, id: any, requestDate: any, status: ServiceRequestStatus, address: { __typename?: 'AddressDto', latitude: number, longitude: number, floorNumber: number, buildingNumber: number, text: string, city: { __typename?: 'CityDto', name: string, id: any, province: { __typename?: 'ProvinceDto', name: string, id: any } } }, customer: { __typename?: 'CustomerDto', firstName?: string | null, id: any, lastName?: string | null, phoneNumber: string, profileImageUrl?: string | null }, specialist?: { __typename?: 'SpecialistDto', firstName?: string | null, id: any, lastName?: string | null, averageRating: number, rateCount: number, phoneNumber: string, profileImageUrl?: string | null } | null, serviceType: { __typename?: 'ServiceTypeDto', id: any, name: string, logo: string, serviceSubCategory: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any, name: string } } } }> | null } | null } };

export type S3_GeneratePresignedUrlMutationVariables = Exact<{
  input: GeneratePresignedUrlInput;
}>;


export type S3_GeneratePresignedUrlMutation = { __typename?: 'Mutation', s3_generatePresignedUrl: { __typename?: 'ResponseBaseOfS3SinglepartUploadUrlsResultDto', status?: any | null, result?: { __typename?: 'S3SinglepartUploadUrlsResultDto', presignedUrl: string, objectUrl: string } | null } };

export type S3_GeneratePresignedUrlsMutationVariables = Exact<{
  input: GenerateMultipartPresignedUrlsInput;
}>;


export type S3_GeneratePresignedUrlsMutation = { __typename?: 'Mutation', s3_generatePresignedUrls: { __typename?: 'ResponseBaseOfS3MultipartUploadUrlsResultDto', status?: any | null, result?: { __typename?: 'S3MultipartUploadUrlsResultDto', uploadId: string, presignedUrls: Array<string>, objectUrl: string } | null } };

export type S3_CompleteMultipartUploadMutationVariables = Exact<{
  input: CompleteMultipartUploadInput;
}>;


export type S3_CompleteMultipartUploadMutation = { __typename?: 'Mutation', s3_completeMultipartUpload: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceCategory_CreateServiceCategoryMutationVariables = Exact<{
  input: CreateServiceCategoryInput;
}>;


export type ServiceCategory_CreateServiceCategoryMutation = { __typename?: 'Mutation', serviceCategory_create: { __typename?: 'ResponseBaseOfServiceCategoryDto', status?: any | null, result?: { __typename?: 'ServiceCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceCategory_UpdateServiceCategoryMutationVariables = Exact<{
  input: UpdateServiceCategoryInput;
}>;


export type ServiceCategory_UpdateServiceCategoryMutation = { __typename?: 'Mutation', serviceCategory_update: { __typename?: 'ResponseBaseOfServiceCategoryDto', status?: any | null, result?: { __typename?: 'ServiceCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceCategory_DeleteServiceCategoryMutationVariables = Exact<{
  input: DeleteServiceCategoryInput;
}>;


export type ServiceCategory_DeleteServiceCategoryMutation = { __typename?: 'Mutation', serviceCategory_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceCategory_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceCategoryDtoFilterInput>;
  order?: InputMaybe<Array<ServiceCategoryDtoSortInput> | ServiceCategoryDtoSortInput>;
}>;


export type ServiceCategory_GetAllQuery = { __typename?: 'Query', serviceCategory_getAll: { __typename?: 'ListResponseBaseOfServiceCategoryDto', status?: any | null, result?: { __typename?: 'ServiceCategoryDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceCategoryDto', id: any, name: string, logo: string, abbreviation: string }> | null } | null } };

export type Specialist_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<SpecialistDtoFilterInput>;
  order?: InputMaybe<Array<SpecialistDtoSortInput> | SpecialistDtoSortInput>;
}>;


export type Specialist_GetAllQuery = { __typename?: 'Query', specialist_getAll: { __typename?: 'ListResponseBaseOfSpecialistDto', status?: any | null, result?: { __typename?: 'SpecialistDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'SpecialistDto', registeredAt: any, phoneNumber: string, nationalCode?: string | null, profileImageUrl?: string | null, gender: Gender, birthDate: any, rateCount: number, averageRating: number, daysRegistered: number, successfulMissions: number, firstName?: string | null, id: any, idCardImageUrl?: string | null, identityVerificationVideoStatus: VerificationStatus, idCardVerificationStatus: VerificationStatus, identityVerificationVideoUrl?: string | null, lastName?: string | null, code: string, specializedDocumentsVerificationStatus: VerificationStatus, specializedDocumentUrls?: Array<string> | null, city?: { __typename?: 'CityDto', id: any, name: string } | null, serviceTypes: Array<{ __typename?: 'ServiceTypeDto', id: any, name: string }> }> | null } | null } };

export type Specialist_VerifyIdCardMutationVariables = Exact<{
  input: VerifyIdCardInput;
}>;


export type Specialist_VerifyIdCardMutation = { __typename?: 'Mutation', specialist_verifyIDCard: { __typename?: 'ResponseBase', status?: any | null } };

export type Specialist_VerifyIdentityVerificationVideoMutationVariables = Exact<{
  input: VerifyIdentityVerificationVideoInput;
}>;


export type Specialist_VerifyIdentityVerificationVideoMutation = { __typename?: 'Mutation', specialist_verifyIdentityVerificationVideo: { __typename?: 'ResponseBase', status?: any | null } };

export type Specialist_VerifySpecializedDocumentsMutationVariables = Exact<{
  input: VerifySpecializedDocumentsInput;
}>;


export type Specialist_VerifySpecializedDocumentsMutation = { __typename?: 'Mutation', specialist_verifySpecializedDocuments: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceSubCategory_CreateMutationVariables = Exact<{
  input: CreateServiceSubCategoryInput;
}>;


export type ServiceSubCategory_CreateMutation = { __typename?: 'Mutation', serviceSubCategory_create: { __typename?: 'ResponseBaseOfServiceSubCategoryDto', status?: any | null, result?: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceSubCategory_UpdateMutationVariables = Exact<{
  input: UpdateServiceSubCategoryInput;
}>;


export type ServiceSubCategory_UpdateMutation = { __typename?: 'Mutation', serviceSubCategory_update: { __typename?: 'ResponseBaseOfServiceSubCategoryDto', status?: any | null, result?: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, logo: string } | null } };

export type ServiceSubCategory_DeleteMutationVariables = Exact<{
  input: DeleteServiceSubCategoryInput;
}>;


export type ServiceSubCategory_DeleteMutation = { __typename?: 'Mutation', serviceSubCategory_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceSubCategory_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceSubCategoryDtoFilterInput>;
  order?: InputMaybe<Array<ServiceSubCategoryDtoSortInput> | ServiceSubCategoryDtoSortInput>;
}>;


export type ServiceSubCategory_GetAllQuery = { __typename?: 'Query', serviceSubCategory_getAll: { __typename?: 'ListResponseBaseOfServiceSubCategoryDto', status?: any | null, result?: { __typename?: 'ServiceSubCategoryDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceSubCategoryDto', id: any, name: string, logo: string, abbreviation: string, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any, name: string } }> | null } | null } };

export type ServiceType_CreateMutationVariables = Exact<{
  input: CreateServiceTypeInput;
}>;


export type ServiceType_CreateMutation = { __typename?: 'Mutation', serviceType_create: { __typename?: 'ResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDto', id: any, name: string, logo: string } | null } };

export type ServiceType_UpdateMutationVariables = Exact<{
  input: UpdateServiceTypeInput;
}>;


export type ServiceType_UpdateMutation = { __typename?: 'Mutation', serviceType_update: { __typename?: 'ResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDto', id: any, name: string, logo: string } | null } };

export type ServiceType_DeleteMutationVariables = Exact<{
  input: DeleteServiceTypeInput;
}>;


export type ServiceType_DeleteMutation = { __typename?: 'Mutation', serviceType_delete: { __typename?: 'ResponseBase', status?: any | null } };

export type ServiceTypes_GetAllQueryVariables = Exact<{
  skip?: InputMaybe<Scalars['Int']['input']>;
  take?: InputMaybe<Scalars['Int']['input']>;
  where?: InputMaybe<ServiceTypeDtoFilterInput>;
  order?: InputMaybe<Array<ServiceTypeDtoSortInput> | ServiceTypeDtoSortInput>;
}>;


export type ServiceTypes_GetAllQuery = { __typename?: 'Query', serviceTypes_getAll: { __typename?: 'ListResponseBaseOfServiceTypeDto', status?: any | null, result?: { __typename?: 'ServiceTypeDtoCollectionSegment', totalCount: number, items?: Array<{ __typename?: 'ServiceTypeDto', id: any, name: string, basePrice: any, logo: string, isSpecial: boolean, banner: string, abbreviation: string, serviceSubCategory: { __typename?: 'ServiceSubCategoryDto', id: any, name: string, serviceCategory: { __typename?: 'ServiceCategoryDto', id: any, name: string } } }> | null } | null } };

export type User_GetMyProfileQueryVariables = Exact<{ [key: string]: never; }>;


export type User_GetMyProfileQuery = { __typename?: 'Query', user_getMyProfile: { __typename?: 'ResponseBaseOfUserProfileDto', status?: any | null, result?: { __typename?: 'UserProfileDto', id: any, phoneNumber: string, firstName?: string | null, lastName?: string | null, profileImageUrl?: string | null, gender: Gender } | null } };



export const Admin_CreateDocument = `
    mutation admin_create($input: CreateAdminInput!) {
  admin_create(input: $input) {
    status
  }
}
    `;

export const useAdmin_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Admin_CreateMutation, TError, Admin_CreateMutationVariables, TContext>) => {
    
    return useMutation<Admin_CreateMutation, TError, Admin_CreateMutationVariables, TContext>(
      ['admin_create'],
      (variables?: Admin_CreateMutationVariables) => fetcher<Admin_CreateMutation, Admin_CreateMutationVariables>(Admin_CreateDocument, variables)(),
      options
    )};

export const Admin_GetAllDocument = `
    query admin_getAll($skip: Int, $take: Int, $where: AdminDtoFilterInput, $order: [AdminDtoSortInput!]) {
  admin_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        firstName
        code
        gender
        id
        phoneNumber
        isBlocked
        lastName
        profileImageUrl
      }
      totalCount
    }
    status
  }
}
    `;

export const useAdmin_GetAllQuery = <
      TData = Admin_GetAllQuery,
      TError = unknown
    >(
      variables?: Admin_GetAllQueryVariables,
      options?: UseQueryOptions<Admin_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<Admin_GetAllQuery, TError, TData>(
      variables === undefined ? ['admin_getAll'] : ['admin_getAll', variables],
      fetcher<Admin_GetAllQuery, Admin_GetAllQueryVariables>(Admin_GetAllDocument, variables),
      options
    )};

export const useInfiniteAdmin_GetAllQuery = <
      TData = Admin_GetAllQuery,
      TError = unknown
    >(
      variables?: Admin_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Admin_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Admin_GetAllQuery, TError, TData>(
      variables === undefined ? ['admin_getAll.infinite'] : ['admin_getAll.infinite', variables],
      (metaData) => fetcher<Admin_GetAllQuery, Admin_GetAllQueryVariables>(Admin_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const User_SetBlockStateDocument = `
    mutation user_setBlockState($input: SetUserBlockStateInput!) {
  user_setBlockState(input: $input) {
    status
  }
}
    `;

export const useUser_SetBlockStateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<User_SetBlockStateMutation, TError, User_SetBlockStateMutationVariables, TContext>) => {
    
    return useMutation<User_SetBlockStateMutation, TError, User_SetBlockStateMutationVariables, TContext>(
      ['user_setBlockState'],
      (variables?: User_SetBlockStateMutationVariables) => fetcher<User_SetBlockStateMutation, User_SetBlockStateMutationVariables>(User_SetBlockStateDocument, variables)(),
      options
    )};

export const Banner_CreateDocument = `
    mutation banner_create($input: CreateBannerInput!) {
  banner_create(input: $input) {
    status
    result {
      id
      title
      imageUrl
    }
  }
}
    `;

export const useBanner_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Banner_CreateMutation, TError, Banner_CreateMutationVariables, TContext>) => {
    
    return useMutation<Banner_CreateMutation, TError, Banner_CreateMutationVariables, TContext>(
      ['banner_create'],
      (variables?: Banner_CreateMutationVariables) => fetcher<Banner_CreateMutation, Banner_CreateMutationVariables>(Banner_CreateDocument, variables)(),
      options
    )};

export const Banner_UpdateDocument = `
    mutation banner_update($input: UpdateBannerInput!) {
  banner_update(input: $input) {
    status
    result {
      id
      title
      imageUrl
    }
  }
}
    `;

export const useBanner_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Banner_UpdateMutation, TError, Banner_UpdateMutationVariables, TContext>) => {
    
    return useMutation<Banner_UpdateMutation, TError, Banner_UpdateMutationVariables, TContext>(
      ['banner_update'],
      (variables?: Banner_UpdateMutationVariables) => fetcher<Banner_UpdateMutation, Banner_UpdateMutationVariables>(Banner_UpdateDocument, variables)(),
      options
    )};

export const Banner_DeleteDocument = `
    mutation banner_delete($input: DeleteBannerInput!) {
  banner_delete(input: $input) {
    status
  }
}
    `;

export const useBanner_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Banner_DeleteMutation, TError, Banner_DeleteMutationVariables, TContext>) => {
    
    return useMutation<Banner_DeleteMutation, TError, Banner_DeleteMutationVariables, TContext>(
      ['banner_delete'],
      (variables?: Banner_DeleteMutationVariables) => fetcher<Banner_DeleteMutation, Banner_DeleteMutationVariables>(Banner_DeleteDocument, variables)(),
      options
    )};

export const Banner_GetAllDocument = `
    query banner_getAll($skip: Int, $take: Int, $where: BannerDtoFilterInput, $order: [BannerDtoSortInput!]) {
  banner_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        imageUrl
        title
      }
      totalCount
    }
    status
  }
}
    `;

export const useBanner_GetAllQuery = <
      TData = Banner_GetAllQuery,
      TError = unknown
    >(
      variables?: Banner_GetAllQueryVariables,
      options?: UseQueryOptions<Banner_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<Banner_GetAllQuery, TError, TData>(
      variables === undefined ? ['banner_getAll'] : ['banner_getAll', variables],
      fetcher<Banner_GetAllQuery, Banner_GetAllQueryVariables>(Banner_GetAllDocument, variables),
      options
    )};

export const useInfiniteBanner_GetAllQuery = <
      TData = Banner_GetAllQuery,
      TError = unknown
    >(
      variables?: Banner_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Banner_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Banner_GetAllQuery, TError, TData>(
      variables === undefined ? ['banner_getAll.infinite'] : ['banner_getAll.infinite', variables],
      (metaData) => fetcher<Banner_GetAllQuery, Banner_GetAllQueryVariables>(Banner_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const City_SetActiveBannerDocument = `
    mutation city_setActiveBanner($input: SetActiveBannerInput!) {
  city_setActiveBanner(input: $input) {
    status
  }
}
    `;

export const useCity_SetActiveBannerMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_SetActiveBannerMutation, TError, City_SetActiveBannerMutationVariables, TContext>) => {
    
    return useMutation<City_SetActiveBannerMutation, TError, City_SetActiveBannerMutationVariables, TContext>(
      ['city_setActiveBanner'],
      (variables?: City_SetActiveBannerMutationVariables) => fetcher<City_SetActiveBannerMutation, City_SetActiveBannerMutationVariables>(City_SetActiveBannerDocument, variables)(),
      options
    )};

export const City_SetActiveCarouselDocument = `
    mutation city_setActiveCarousel($input: SetActiveCarouselInput!) {
  city_setActiveCarousel(input: $input) {
    status
  }
}
    `;

export const useCity_SetActiveCarouselMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_SetActiveCarouselMutation, TError, City_SetActiveCarouselMutationVariables, TContext>) => {
    
    return useMutation<City_SetActiveCarouselMutation, TError, City_SetActiveCarouselMutationVariables, TContext>(
      ['city_setActiveCarousel'],
      (variables?: City_SetActiveCarouselMutationVariables) => fetcher<City_SetActiveCarouselMutation, City_SetActiveCarouselMutationVariables>(City_SetActiveCarouselDocument, variables)(),
      options
    )};

export const Carousel_CreateDocument = `
    mutation carousel_create($input: CreateCarouselInput!) {
  carousel_create(input: $input) {
    status
    result {
      id
      title
    }
  }
}
    `;

export const useCarousel_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Carousel_CreateMutation, TError, Carousel_CreateMutationVariables, TContext>) => {
    
    return useMutation<Carousel_CreateMutation, TError, Carousel_CreateMutationVariables, TContext>(
      ['carousel_create'],
      (variables?: Carousel_CreateMutationVariables) => fetcher<Carousel_CreateMutation, Carousel_CreateMutationVariables>(Carousel_CreateDocument, variables)(),
      options
    )};

export const Carousel_UpdateDocument = `
    mutation carousel_update($input: UpdateCarouselInput!) {
  carousel_update(input: $input) {
    status
    result {
      id
      title
    }
  }
}
    `;

export const useCarousel_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Carousel_UpdateMutation, TError, Carousel_UpdateMutationVariables, TContext>) => {
    
    return useMutation<Carousel_UpdateMutation, TError, Carousel_UpdateMutationVariables, TContext>(
      ['carousel_update'],
      (variables?: Carousel_UpdateMutationVariables) => fetcher<Carousel_UpdateMutation, Carousel_UpdateMutationVariables>(Carousel_UpdateDocument, variables)(),
      options
    )};

export const Carousel_DeleteDocument = `
    mutation carousel_delete($input: DeleteCarouselInput!) {
  carousel_delete(input: $input) {
    status
  }
}
    `;

export const useCarousel_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Carousel_DeleteMutation, TError, Carousel_DeleteMutationVariables, TContext>) => {
    
    return useMutation<Carousel_DeleteMutation, TError, Carousel_DeleteMutationVariables, TContext>(
      ['carousel_delete'],
      (variables?: Carousel_DeleteMutationVariables) => fetcher<Carousel_DeleteMutation, Carousel_DeleteMutationVariables>(Carousel_DeleteDocument, variables)(),
      options
    )};

export const Carousel_GetAllDocument = `
    query carousel_getAll($skip: Int, $take: Int, $where: CarouselDtoFilterInput, $order: [CarouselDtoSortInput!]) {
  carousel_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        serviceTypes {
          id
          name
          logo
          banner
          serviceSubCategory {
            id
          }
        }
        title
      }
      totalCount
    }
    status
  }
}
    `;

export const useCarousel_GetAllQuery = <
      TData = Carousel_GetAllQuery,
      TError = unknown
    >(
      variables?: Carousel_GetAllQueryVariables,
      options?: UseQueryOptions<Carousel_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<Carousel_GetAllQuery, TError, TData>(
      variables === undefined ? ['carousel_getAll'] : ['carousel_getAll', variables],
      fetcher<Carousel_GetAllQuery, Carousel_GetAllQueryVariables>(Carousel_GetAllDocument, variables),
      options
    )};

export const useInfiniteCarousel_GetAllQuery = <
      TData = Carousel_GetAllQuery,
      TError = unknown
    >(
      variables?: Carousel_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Carousel_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Carousel_GetAllQuery, TError, TData>(
      variables === undefined ? ['carousel_getAll.infinite'] : ['carousel_getAll.infinite', variables],
      (metaData) => fetcher<Carousel_GetAllQuery, Carousel_GetAllQueryVariables>(Carousel_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const City_CreateCityDocument = `
    mutation city_createCity($input: CreateCityInput!) {
  city_create(input: $input) {
    status
  }
}
    `;

export const useCity_CreateCityMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_CreateCityMutation, TError, City_CreateCityMutationVariables, TContext>) => {
    
    return useMutation<City_CreateCityMutation, TError, City_CreateCityMutationVariables, TContext>(
      ['city_createCity'],
      (variables?: City_CreateCityMutationVariables) => fetcher<City_CreateCityMutation, City_CreateCityMutationVariables>(City_CreateCityDocument, variables)(),
      options
    )};

export const CreateProvinceDocument = `
    mutation createProvince($input: CreateProvinceInput!) {
  province_create(input: $input) {
    status
    result {
      id
      name
    }
  }
}
    `;

export const useCreateProvinceMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<CreateProvinceMutation, TError, CreateProvinceMutationVariables, TContext>) => {
    
    return useMutation<CreateProvinceMutation, TError, CreateProvinceMutationVariables, TContext>(
      ['createProvince'],
      (variables?: CreateProvinceMutationVariables) => fetcher<CreateProvinceMutation, CreateProvinceMutationVariables>(CreateProvinceDocument, variables)(),
      options
    )};

export const City_ActivateDocument = `
    mutation city_activate($input: ActivateCityInput!) {
  city_activate(input: $input) {
    status
  }
}
    `;

export const useCity_ActivateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_ActivateMutation, TError, City_ActivateMutationVariables, TContext>) => {
    
    return useMutation<City_ActivateMutation, TError, City_ActivateMutationVariables, TContext>(
      ['city_activate'],
      (variables?: City_ActivateMutationVariables) => fetcher<City_ActivateMutation, City_ActivateMutationVariables>(City_ActivateDocument, variables)(),
      options
    )};

export const City_DeactivateDocument = `
    mutation city_deactivate($input: DeactivateCityInput!) {
  city_deactivate(input: $input) {
    status
  }
}
    `;

export const useCity_DeactivateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_DeactivateMutation, TError, City_DeactivateMutationVariables, TContext>) => {
    
    return useMutation<City_DeactivateMutation, TError, City_DeactivateMutationVariables, TContext>(
      ['city_deactivate'],
      (variables?: City_DeactivateMutationVariables) => fetcher<City_DeactivateMutation, City_DeactivateMutationVariables>(City_DeactivateDocument, variables)(),
      options
    )};

export const City_GetAllDocument = `
    query city_getAll($skip: Int, $take: Int, $where: CityDtoFilterInput, $order: [CityDtoSortInput!]) {
  city_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        abbreviation
        boundary
        province {
          id
          name
        }
        name
        isActive
        activeBanner {
          id
          title
          imageUrl
        }
        activeCarousel {
          id
          title
        }
      }
    }
  }
}
    `;

export const useCity_GetAllQuery = <
      TData = City_GetAllQuery,
      TError = unknown
    >(
      variables?: City_GetAllQueryVariables,
      options?: UseQueryOptions<City_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<City_GetAllQuery, TError, TData>(
      variables === undefined ? ['city_getAll'] : ['city_getAll', variables],
      fetcher<City_GetAllQuery, City_GetAllQueryVariables>(City_GetAllDocument, variables),
      options
    )};

export const useInfiniteCity_GetAllQuery = <
      TData = City_GetAllQuery,
      TError = unknown
    >(
      variables?: City_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<City_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<City_GetAllQuery, TError, TData>(
      variables === undefined ? ['city_getAll.infinite'] : ['city_getAll.infinite', variables],
      (metaData) => fetcher<City_GetAllQuery, City_GetAllQueryVariables>(City_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const City_UpdateCityDocument = `
    mutation city_updateCity($input: UpdateCityInput!) {
  city_update(input: $input) {
    status
  }
}
    `;

export const useCity_UpdateCityMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_UpdateCityMutation, TError, City_UpdateCityMutationVariables, TContext>) => {
    
    return useMutation<City_UpdateCityMutation, TError, City_UpdateCityMutationVariables, TContext>(
      ['city_updateCity'],
      (variables?: City_UpdateCityMutationVariables) => fetcher<City_UpdateCityMutation, City_UpdateCityMutationVariables>(City_UpdateCityDocument, variables)(),
      options
    )};

export const ProvincesDocument = `
    query provinces($skip: Int, $take: Int, $where: ProvinceDtoFilterInput, $order: [ProvinceDtoSortInput!]) {
  province_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        name
        id
        abbreviation
      }
    }
  }
}
    `;

export const useProvincesQuery = <
      TData = ProvincesQuery,
      TError = unknown
    >(
      variables?: ProvincesQueryVariables,
      options?: UseQueryOptions<ProvincesQuery, TError, TData>
    ) => {
    
    return useQuery<ProvincesQuery, TError, TData>(
      variables === undefined ? ['provinces'] : ['provinces', variables],
      fetcher<ProvincesQuery, ProvincesQueryVariables>(ProvincesDocument, variables),
      options
    )};

export const useInfiniteProvincesQuery = <
      TData = ProvincesQuery,
      TError = unknown
    >(
      variables?: ProvincesQueryVariables,
      options?: UseInfiniteQueryOptions<ProvincesQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<ProvincesQuery, TError, TData>(
      variables === undefined ? ['provinces.infinite'] : ['provinces.infinite', variables],
      (metaData) => fetcher<ProvincesQuery, ProvincesQueryVariables>(ProvincesDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Province_UpdateDocument = `
    mutation province_update($input: UpdateProvinceInput!) {
  province_update(input: $input) {
    status
    result {
      id
      name
    }
  }
}
    `;

export const useProvince_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Province_UpdateMutation, TError, Province_UpdateMutationVariables, TContext>) => {
    
    return useMutation<Province_UpdateMutation, TError, Province_UpdateMutationVariables, TContext>(
      ['province_update'],
      (variables?: Province_UpdateMutationVariables) => fetcher<Province_UpdateMutation, Province_UpdateMutationVariables>(Province_UpdateDocument, variables)(),
      options
    )};

export const Province_DeleteDocument = `
    mutation province_delete($input: DeleteProvinceInput!) {
  province_delete(input: $input) {
    status
  }
}
    `;

export const useProvince_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Province_DeleteMutation, TError, Province_DeleteMutationVariables, TContext>) => {
    
    return useMutation<Province_DeleteMutation, TError, Province_DeleteMutationVariables, TContext>(
      ['province_delete'],
      (variables?: Province_DeleteMutationVariables) => fetcher<Province_DeleteMutation, Province_DeleteMutationVariables>(Province_DeleteDocument, variables)(),
      options
    )};

export const City_UpdateBoundaryDocument = `
    mutation city_updateBoundary($input: UpdateCityBoundaryInput!) {
  city_updateBoundary(input: $input) {
    status
  }
}
    `;

export const useCity_UpdateBoundaryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_UpdateBoundaryMutation, TError, City_UpdateBoundaryMutationVariables, TContext>) => {
    
    return useMutation<City_UpdateBoundaryMutation, TError, City_UpdateBoundaryMutationVariables, TContext>(
      ['city_updateBoundary'],
      (variables?: City_UpdateBoundaryMutationVariables) => fetcher<City_UpdateBoundaryMutation, City_UpdateBoundaryMutationVariables>(City_UpdateBoundaryDocument, variables)(),
      options
    )};

export const City_SetAvailableServiceTypesDocument = `
    mutation city_setAvailableServiceTypes($input: SetCityAvailableServiceTypesInput!) {
  city_setAvailableServiceTypes(input: $input) {
    status
  }
}
    `;

export const useCity_SetAvailableServiceTypesMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<City_SetAvailableServiceTypesMutation, TError, City_SetAvailableServiceTypesMutationVariables, TContext>) => {
    
    return useMutation<City_SetAvailableServiceTypesMutation, TError, City_SetAvailableServiceTypesMutationVariables, TContext>(
      ['city_setAvailableServiceTypes'],
      (variables?: City_SetAvailableServiceTypesMutationVariables) => fetcher<City_SetAvailableServiceTypesMutation, City_SetAvailableServiceTypesMutationVariables>(City_SetAvailableServiceTypesDocument, variables)(),
      options
    )};

export const City_GetAvailableServiceTypesDocument = `
    query city_getAvailableServiceTypes($input: GetAvailableServiceTypesForCityInput!, $skip: Int, $take: Int, $where: ServiceTypeDtoFilterInput, $order: [ServiceTypeDtoSortInput!]) {
  city_getAvailableServiceTypes(input: $input) {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        name
        logo
        id
        isSpecial
      }
      totalCount
    }
    status
  }
}
    `;

export const useCity_GetAvailableServiceTypesQuery = <
      TData = City_GetAvailableServiceTypesQuery,
      TError = unknown
    >(
      variables: City_GetAvailableServiceTypesQueryVariables,
      options?: UseQueryOptions<City_GetAvailableServiceTypesQuery, TError, TData>
    ) => {
    
    return useQuery<City_GetAvailableServiceTypesQuery, TError, TData>(
      ['city_getAvailableServiceTypes', variables],
      fetcher<City_GetAvailableServiceTypesQuery, City_GetAvailableServiceTypesQueryVariables>(City_GetAvailableServiceTypesDocument, variables),
      options
    )};

export const useInfiniteCity_GetAvailableServiceTypesQuery = <
      TData = City_GetAvailableServiceTypesQuery,
      TError = unknown
    >(
      variables: City_GetAvailableServiceTypesQueryVariables,
      options?: UseInfiniteQueryOptions<City_GetAvailableServiceTypesQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<City_GetAvailableServiceTypesQuery, TError, TData>(
      ['city_getAvailableServiceTypes.infinite', variables],
      (metaData) => fetcher<City_GetAvailableServiceTypesQuery, City_GetAvailableServiceTypesQueryVariables>(City_GetAvailableServiceTypesDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Customer_GetAllDocument = `
    query customer_getAll($skip: Int, $take: Int, $where: CustomerDtoFilterInput, $order: [CustomerDtoSortInput!]) {
  customer_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        code
        firstName
        gender
        id
        lastName
        phoneNumber
        profileImageUrl
        isBlocked
      }
      totalCount
    }
    status
  }
}
    `;

export const useCustomer_GetAllQuery = <
      TData = Customer_GetAllQuery,
      TError = unknown
    >(
      variables?: Customer_GetAllQueryVariables,
      options?: UseQueryOptions<Customer_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<Customer_GetAllQuery, TError, TData>(
      variables === undefined ? ['customer_getAll'] : ['customer_getAll', variables],
      fetcher<Customer_GetAllQuery, Customer_GetAllQueryVariables>(Customer_GetAllDocument, variables),
      options
    )};

export const useInfiniteCustomer_GetAllQuery = <
      TData = Customer_GetAllQuery,
      TError = unknown
    >(
      variables?: Customer_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Customer_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Customer_GetAllQuery, TError, TData>(
      variables === undefined ? ['customer_getAll.infinite'] : ['customer_getAll.infinite', variables],
      (metaData) => fetcher<Customer_GetAllQuery, Customer_GetAllQueryVariables>(Customer_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Stats_GetActiveSpecialistsDocument = `
    query stats_getActiveSpecialists($input: StatsRangeInput!) {
  stats_getActiveSpecialists(input: $input) {
    status
    result
  }
}
    `;

export const useStats_GetActiveSpecialistsQuery = <
      TData = Stats_GetActiveSpecialistsQuery,
      TError = unknown
    >(
      variables: Stats_GetActiveSpecialistsQueryVariables,
      options?: UseQueryOptions<Stats_GetActiveSpecialistsQuery, TError, TData>
    ) => {
    
    return useQuery<Stats_GetActiveSpecialistsQuery, TError, TData>(
      ['stats_getActiveSpecialists', variables],
      fetcher<Stats_GetActiveSpecialistsQuery, Stats_GetActiveSpecialistsQueryVariables>(Stats_GetActiveSpecialistsDocument, variables),
      options
    )};

export const useInfiniteStats_GetActiveSpecialistsQuery = <
      TData = Stats_GetActiveSpecialistsQuery,
      TError = unknown
    >(
      variables: Stats_GetActiveSpecialistsQueryVariables,
      options?: UseInfiniteQueryOptions<Stats_GetActiveSpecialistsQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Stats_GetActiveSpecialistsQuery, TError, TData>(
      ['stats_getActiveSpecialists.infinite', variables],
      (metaData) => fetcher<Stats_GetActiveSpecialistsQuery, Stats_GetActiveSpecialistsQueryVariables>(Stats_GetActiveSpecialistsDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Stats_GetTotalRevenueDocument = `
    query stats_getTotalRevenue($input: StatsRangeInput!) {
  stats_getTotalRevenue(input: $input) {
    status
    result {
      totalGross
      totalPlatformShare
      totalSpecialistShare
    }
  }
}
    `;

export const useStats_GetTotalRevenueQuery = <
      TData = Stats_GetTotalRevenueQuery,
      TError = unknown
    >(
      variables: Stats_GetTotalRevenueQueryVariables,
      options?: UseQueryOptions<Stats_GetTotalRevenueQuery, TError, TData>
    ) => {
    
    return useQuery<Stats_GetTotalRevenueQuery, TError, TData>(
      ['stats_getTotalRevenue', variables],
      fetcher<Stats_GetTotalRevenueQuery, Stats_GetTotalRevenueQueryVariables>(Stats_GetTotalRevenueDocument, variables),
      options
    )};

export const useInfiniteStats_GetTotalRevenueQuery = <
      TData = Stats_GetTotalRevenueQuery,
      TError = unknown
    >(
      variables: Stats_GetTotalRevenueQueryVariables,
      options?: UseInfiniteQueryOptions<Stats_GetTotalRevenueQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Stats_GetTotalRevenueQuery, TError, TData>(
      ['stats_getTotalRevenue.infinite', variables],
      (metaData) => fetcher<Stats_GetTotalRevenueQuery, Stats_GetTotalRevenueQueryVariables>(Stats_GetTotalRevenueDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Stats_GetServiceRequestsDocument = `
    query stats_getServiceRequests($input: StatsRangeInput!) {
  stats_getServiceRequests(input: $input) {
    status
    result {
      totalRequests
      successfulRequests
    }
  }
}
    `;

export const useStats_GetServiceRequestsQuery = <
      TData = Stats_GetServiceRequestsQuery,
      TError = unknown
    >(
      variables: Stats_GetServiceRequestsQueryVariables,
      options?: UseQueryOptions<Stats_GetServiceRequestsQuery, TError, TData>
    ) => {
    
    return useQuery<Stats_GetServiceRequestsQuery, TError, TData>(
      ['stats_getServiceRequests', variables],
      fetcher<Stats_GetServiceRequestsQuery, Stats_GetServiceRequestsQueryVariables>(Stats_GetServiceRequestsDocument, variables),
      options
    )};

export const useInfiniteStats_GetServiceRequestsQuery = <
      TData = Stats_GetServiceRequestsQuery,
      TError = unknown
    >(
      variables: Stats_GetServiceRequestsQueryVariables,
      options?: UseInfiniteQueryOptions<Stats_GetServiceRequestsQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Stats_GetServiceRequestsQuery, TError, TData>(
      ['stats_getServiceRequests.infinite', variables],
      (metaData) => fetcher<Stats_GetServiceRequestsQuery, Stats_GetServiceRequestsQueryVariables>(Stats_GetServiceRequestsDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Stats_GetServiceTypeCountsDocument = `
    query stats_getServiceTypeCounts($input: StatsRangeInput!, $skip: Int, $take: Int, $where: ServiceTypeCountDtoFilterInput, $order: [ServiceTypeCountDtoSortInput!]) {
  stats_getServiceTypeCounts(input: $input) {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        count
        serviceTypeId
        serviceTypeName
      }
      totalCount
    }
    status
  }
}
    `;

export const useStats_GetServiceTypeCountsQuery = <
      TData = Stats_GetServiceTypeCountsQuery,
      TError = unknown
    >(
      variables: Stats_GetServiceTypeCountsQueryVariables,
      options?: UseQueryOptions<Stats_GetServiceTypeCountsQuery, TError, TData>
    ) => {
    
    return useQuery<Stats_GetServiceTypeCountsQuery, TError, TData>(
      ['stats_getServiceTypeCounts', variables],
      fetcher<Stats_GetServiceTypeCountsQuery, Stats_GetServiceTypeCountsQueryVariables>(Stats_GetServiceTypeCountsDocument, variables),
      options
    )};

export const useInfiniteStats_GetServiceTypeCountsQuery = <
      TData = Stats_GetServiceTypeCountsQuery,
      TError = unknown
    >(
      variables: Stats_GetServiceTypeCountsQueryVariables,
      options?: UseInfiniteQueryOptions<Stats_GetServiceTypeCountsQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Stats_GetServiceTypeCountsQuery, TError, TData>(
      ['stats_getServiceTypeCounts.infinite', variables],
      (metaData) => fetcher<Stats_GetServiceTypeCountsQuery, Stats_GetServiceTypeCountsQueryVariables>(Stats_GetServiceTypeCountsDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const DiscountCode_CreateDocument = `
    mutation discountCode_create($input: CreateDiscountCodeInput!) {
  discountCode_create(input: $input) {
    status
  }
}
    `;

export const useDiscountCode_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<DiscountCode_CreateMutation, TError, DiscountCode_CreateMutationVariables, TContext>) => {
    
    return useMutation<DiscountCode_CreateMutation, TError, DiscountCode_CreateMutationVariables, TContext>(
      ['discountCode_create'],
      (variables?: DiscountCode_CreateMutationVariables) => fetcher<DiscountCode_CreateMutation, DiscountCode_CreateMutationVariables>(DiscountCode_CreateDocument, variables)(),
      options
    )};

export const DiscountCode_DeleteDocument = `
    mutation discountCode_delete($input: DeleteDiscountCodeInput!) {
  discountCode_delete(input: $input) {
    status
  }
}
    `;

export const useDiscountCode_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<DiscountCode_DeleteMutation, TError, DiscountCode_DeleteMutationVariables, TContext>) => {
    
    return useMutation<DiscountCode_DeleteMutation, TError, DiscountCode_DeleteMutationVariables, TContext>(
      ['discountCode_delete'],
      (variables?: DiscountCode_DeleteMutationVariables) => fetcher<DiscountCode_DeleteMutation, DiscountCode_DeleteMutationVariables>(DiscountCode_DeleteDocument, variables)(),
      options
    )};

export const DiscountCode_ActivateDocument = `
    mutation discountCode_activate($input: ActivateDiscountCodeInput!) {
  discountCode_activate(input: $input) {
    status
  }
}
    `;

export const useDiscountCode_ActivateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<DiscountCode_ActivateMutation, TError, DiscountCode_ActivateMutationVariables, TContext>) => {
    
    return useMutation<DiscountCode_ActivateMutation, TError, DiscountCode_ActivateMutationVariables, TContext>(
      ['discountCode_activate'],
      (variables?: DiscountCode_ActivateMutationVariables) => fetcher<DiscountCode_ActivateMutation, DiscountCode_ActivateMutationVariables>(DiscountCode_ActivateDocument, variables)(),
      options
    )};

export const DiscountCode_GetAllDocument = `
    query discountCode_getAll($skip: Int, $take: Int, $where: DiscountCodeDtoFilterInput, $order: [DiscountCodeDtoSortInput!]) {
  discountCode_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        amount
        id
        code
        expiryDate
        isPercentage
        isActive
        title
        customer {
          id
          firstName
          lastName
        }
      }
      totalCount
    }
    status
  }
}
    `;

export const useDiscountCode_GetAllQuery = <
      TData = DiscountCode_GetAllQuery,
      TError = unknown
    >(
      variables?: DiscountCode_GetAllQueryVariables,
      options?: UseQueryOptions<DiscountCode_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<DiscountCode_GetAllQuery, TError, TData>(
      variables === undefined ? ['discountCode_getAll'] : ['discountCode_getAll', variables],
      fetcher<DiscountCode_GetAllQuery, DiscountCode_GetAllQueryVariables>(DiscountCode_GetAllDocument, variables),
      options
    )};

export const useInfiniteDiscountCode_GetAllQuery = <
      TData = DiscountCode_GetAllQuery,
      TError = unknown
    >(
      variables?: DiscountCode_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<DiscountCode_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<DiscountCode_GetAllQuery, TError, TData>(
      variables === undefined ? ['discountCode_getAll.infinite'] : ['discountCode_getAll.infinite', variables],
      (metaData) => fetcher<DiscountCode_GetAllQuery, DiscountCode_GetAllQueryVariables>(DiscountCode_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const DiscountCode_DeactivateDocument = `
    mutation discountCode_deactivate($input: DeactivateDiscountCodeInput!) {
  discountCode_deactivate(input: $input) {
    status
  }
}
    `;

export const useDiscountCode_DeactivateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<DiscountCode_DeactivateMutation, TError, DiscountCode_DeactivateMutationVariables, TContext>) => {
    
    return useMutation<DiscountCode_DeactivateMutation, TError, DiscountCode_DeactivateMutationVariables, TContext>(
      ['discountCode_deactivate'],
      (variables?: DiscountCode_DeactivateMutationVariables) => fetcher<DiscountCode_DeactivateMutation, DiscountCode_DeactivateMutationVariables>(DiscountCode_DeactivateDocument, variables)(),
      options
    )};

export const Auth_RequestOtpDocument = `
    mutation auth_requestOtp($input: RequestOtpInput!) {
  auth_requestOtp(input: $input) {
    status
  }
}
    `;

export const useAuth_RequestOtpMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Auth_RequestOtpMutation, TError, Auth_RequestOtpMutationVariables, TContext>) => {
    
    return useMutation<Auth_RequestOtpMutation, TError, Auth_RequestOtpMutationVariables, TContext>(
      ['auth_requestOtp'],
      (variables?: Auth_RequestOtpMutationVariables) => fetcher<Auth_RequestOtpMutation, Auth_RequestOtpMutationVariables>(Auth_RequestOtpDocument, variables)(),
      options
    )};

export const Auth_VerifyOtpDocument = `
    mutation auth_verifyOtp($input: VerifyOtpInput!) {
  auth_verifyOtp(input: $input) {
    status
    result {
      accessToken
      refreshToken
    }
  }
}
    `;

export const useAuth_VerifyOtpMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Auth_VerifyOtpMutation, TError, Auth_VerifyOtpMutationVariables, TContext>) => {
    
    return useMutation<Auth_VerifyOtpMutation, TError, Auth_VerifyOtpMutationVariables, TContext>(
      ['auth_verifyOtp'],
      (variables?: Auth_VerifyOtpMutationVariables) => fetcher<Auth_VerifyOtpMutation, Auth_VerifyOtpMutationVariables>(Auth_VerifyOtpDocument, variables)(),
      options
    )};

export const Auth_RefreshTokenDocument = `
    mutation auth_refreshToken($input: RefreshTokenRequestInput!) {
  auth_refreshToken(input: $input) {
    status
    result {
      accessToken
      refreshToken
    }
  }
}
    `;

export const useAuth_RefreshTokenMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Auth_RefreshTokenMutation, TError, Auth_RefreshTokenMutationVariables, TContext>) => {
    
    return useMutation<Auth_RefreshTokenMutation, TError, Auth_RefreshTokenMutationVariables, TContext>(
      ['auth_refreshToken'],
      (variables?: Auth_RefreshTokenMutationVariables) => fetcher<Auth_RefreshTokenMutation, Auth_RefreshTokenMutationVariables>(Auth_RefreshTokenDocument, variables)(),
      options
    )};

export const ServiceTypeQuestion_CreateDocument = `
    mutation serviceTypeQuestion_create($input: CreateServiceTypeQuestionInput!) {
  serviceTypeQuestion_create(input: $input) {
    status
  }
}
    `;

export const useServiceTypeQuestion_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceTypeQuestion_CreateMutation, TError, ServiceTypeQuestion_CreateMutationVariables, TContext>) => {
    
    return useMutation<ServiceTypeQuestion_CreateMutation, TError, ServiceTypeQuestion_CreateMutationVariables, TContext>(
      ['serviceTypeQuestion_create'],
      (variables?: ServiceTypeQuestion_CreateMutationVariables) => fetcher<ServiceTypeQuestion_CreateMutation, ServiceTypeQuestion_CreateMutationVariables>(ServiceTypeQuestion_CreateDocument, variables)(),
      options
    )};

export const ServiceTypeQuestion_UpdateDocument = `
    mutation serviceTypeQuestion_update($input: UpdateServiceTypeQuestionInput!) {
  serviceTypeQuestion_update(input: $input) {
    status
  }
}
    `;

export const useServiceTypeQuestion_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceTypeQuestion_UpdateMutation, TError, ServiceTypeQuestion_UpdateMutationVariables, TContext>) => {
    
    return useMutation<ServiceTypeQuestion_UpdateMutation, TError, ServiceTypeQuestion_UpdateMutationVariables, TContext>(
      ['serviceTypeQuestion_update'],
      (variables?: ServiceTypeQuestion_UpdateMutationVariables) => fetcher<ServiceTypeQuestion_UpdateMutation, ServiceTypeQuestion_UpdateMutationVariables>(ServiceTypeQuestion_UpdateDocument, variables)(),
      options
    )};

export const ServiceTypeQuestion_GetByServiceTypeDocument = `
    query serviceTypeQuestion_getByServiceType($input: GetServiceTypeQuestionsByServiceTypeInput!, $skip: Int, $take: Int, $where: ServiceTypeQuestionDtoFilterInput, $order: [ServiceTypeQuestionDtoSortInput!]) {
  serviceTypeQuestion_getByServiceType(input: $input) {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        isRequired
        options
        questionType
        text
        serviceType {
          id
          serviceSubCategory {
            id
            serviceCategory {
              id
            }
          }
        }
      }
      totalCount
    }
    status
  }
}
    `;

export const useServiceTypeQuestion_GetByServiceTypeQuery = <
      TData = ServiceTypeQuestion_GetByServiceTypeQuery,
      TError = unknown
    >(
      variables: ServiceTypeQuestion_GetByServiceTypeQueryVariables,
      options?: UseQueryOptions<ServiceTypeQuestion_GetByServiceTypeQuery, TError, TData>
    ) => {
    
    return useQuery<ServiceTypeQuestion_GetByServiceTypeQuery, TError, TData>(
      ['serviceTypeQuestion_getByServiceType', variables],
      fetcher<ServiceTypeQuestion_GetByServiceTypeQuery, ServiceTypeQuestion_GetByServiceTypeQueryVariables>(ServiceTypeQuestion_GetByServiceTypeDocument, variables),
      options
    )};

export const useInfiniteServiceTypeQuestion_GetByServiceTypeQuery = <
      TData = ServiceTypeQuestion_GetByServiceTypeQuery,
      TError = unknown
    >(
      variables: ServiceTypeQuestion_GetByServiceTypeQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceTypeQuestion_GetByServiceTypeQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<ServiceTypeQuestion_GetByServiceTypeQuery, TError, TData>(
      ['serviceTypeQuestion_getByServiceType.infinite', variables],
      (metaData) => fetcher<ServiceTypeQuestion_GetByServiceTypeQuery, ServiceTypeQuestion_GetByServiceTypeQueryVariables>(ServiceTypeQuestion_GetByServiceTypeDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const CancellationReason_CreateDocument = `
    mutation cancellationReason_create($input: CreateCancellationReasonInput!) {
  cancellationReason_create(input: $input) {
    status
  }
}
    `;

export const useCancellationReason_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<CancellationReason_CreateMutation, TError, CancellationReason_CreateMutationVariables, TContext>) => {
    
    return useMutation<CancellationReason_CreateMutation, TError, CancellationReason_CreateMutationVariables, TContext>(
      ['cancellationReason_create'],
      (variables?: CancellationReason_CreateMutationVariables) => fetcher<CancellationReason_CreateMutation, CancellationReason_CreateMutationVariables>(CancellationReason_CreateDocument, variables)(),
      options
    )};

export const CancellationReason_UpdateDocument = `
    mutation cancellationReason_update($input: UpdateCancellationReasonInput!) {
  cancellationReason_update(input: $input) {
    status
  }
}
    `;

export const useCancellationReason_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<CancellationReason_UpdateMutation, TError, CancellationReason_UpdateMutationVariables, TContext>) => {
    
    return useMutation<CancellationReason_UpdateMutation, TError, CancellationReason_UpdateMutationVariables, TContext>(
      ['cancellationReason_update'],
      (variables?: CancellationReason_UpdateMutationVariables) => fetcher<CancellationReason_UpdateMutation, CancellationReason_UpdateMutationVariables>(CancellationReason_UpdateDocument, variables)(),
      options
    )};

export const CancellationReason_DeleteDocument = `
    mutation cancellationReason_delete($input: DeleteCancellationReasonInput!) {
  cancellationReason_delete(input: $input) {
    status
  }
}
    `;

export const useCancellationReason_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<CancellationReason_DeleteMutation, TError, CancellationReason_DeleteMutationVariables, TContext>) => {
    
    return useMutation<CancellationReason_DeleteMutation, TError, CancellationReason_DeleteMutationVariables, TContext>(
      ['cancellationReason_delete'],
      (variables?: CancellationReason_DeleteMutationVariables) => fetcher<CancellationReason_DeleteMutation, CancellationReason_DeleteMutationVariables>(CancellationReason_DeleteDocument, variables)(),
      options
    )};

export const CancellationReason_GetAllDocument = `
    query cancellationReason_getAll($skip: Int, $take: Int, $where: CancellationReasonDtoFilterInput, $order: [CancellationReasonDtoSortInput!]) {
  cancellationReason_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        name
        id
        targets
      }
      totalCount
    }
    status
  }
}
    `;

export const useCancellationReason_GetAllQuery = <
      TData = CancellationReason_GetAllQuery,
      TError = unknown
    >(
      variables?: CancellationReason_GetAllQueryVariables,
      options?: UseQueryOptions<CancellationReason_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<CancellationReason_GetAllQuery, TError, TData>(
      variables === undefined ? ['cancellationReason_getAll'] : ['cancellationReason_getAll', variables],
      fetcher<CancellationReason_GetAllQuery, CancellationReason_GetAllQueryVariables>(CancellationReason_GetAllDocument, variables),
      options
    )};

export const useInfiniteCancellationReason_GetAllQuery = <
      TData = CancellationReason_GetAllQuery,
      TError = unknown
    >(
      variables?: CancellationReason_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<CancellationReason_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<CancellationReason_GetAllQuery, TError, TData>(
      variables === undefined ? ['cancellationReason_getAll.infinite'] : ['cancellationReason_getAll.infinite', variables],
      (metaData) => fetcher<CancellationReason_GetAllQuery, CancellationReason_GetAllQueryVariables>(CancellationReason_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const ServiceRequest_GetAllDocument = `
    query serviceRequest_getAll($skip: Int, $take: Int, $where: ServiceRequestDtoFilterInput, $order: [ServiceRequestDtoSortInput!]) {
  serviceRequest_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        trackingCode
        address {
          latitude
          longitude
          floorNumber
          buildingNumber
          city {
            name
            id
            province {
              name
              id
            }
          }
          text
        }
        basePrice
        customer {
          firstName
          id
          lastName
          phoneNumber
          profileImageUrl
        }
        description
        discountAmount
        finalPrice
        id
        requestDate
        status
        specialist {
          firstName
          id
          lastName
          averageRating
          rateCount
          phoneNumber
          profileImageUrl
        }
        serviceType {
          id
          name
          logo
          serviceSubCategory {
            id
            name
            serviceCategory {
              id
              name
            }
          }
        }
      }
      totalCount
    }
    status
  }
}
    `;

export const useServiceRequest_GetAllQuery = <
      TData = ServiceRequest_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceRequest_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceRequest_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<ServiceRequest_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceRequest_getAll'] : ['serviceRequest_getAll', variables],
      fetcher<ServiceRequest_GetAllQuery, ServiceRequest_GetAllQueryVariables>(ServiceRequest_GetAllDocument, variables),
      options
    )};

export const useInfiniteServiceRequest_GetAllQuery = <
      TData = ServiceRequest_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceRequest_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceRequest_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<ServiceRequest_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceRequest_getAll.infinite'] : ['serviceRequest_getAll.infinite', variables],
      (metaData) => fetcher<ServiceRequest_GetAllQuery, ServiceRequest_GetAllQueryVariables>(ServiceRequest_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const S3_GeneratePresignedUrlDocument = `
    mutation s3_generatePresignedUrl($input: GeneratePresignedUrlInput!) {
  s3_generatePresignedUrl(input: $input) {
    status
    result {
      presignedUrl
      objectUrl
    }
  }
}
    `;

export const useS3_GeneratePresignedUrlMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<S3_GeneratePresignedUrlMutation, TError, S3_GeneratePresignedUrlMutationVariables, TContext>) => {
    
    return useMutation<S3_GeneratePresignedUrlMutation, TError, S3_GeneratePresignedUrlMutationVariables, TContext>(
      ['s3_generatePresignedUrl'],
      (variables?: S3_GeneratePresignedUrlMutationVariables) => fetcher<S3_GeneratePresignedUrlMutation, S3_GeneratePresignedUrlMutationVariables>(S3_GeneratePresignedUrlDocument, variables)(),
      options
    )};

export const S3_GeneratePresignedUrlsDocument = `
    mutation s3_generatePresignedUrls($input: GenerateMultipartPresignedUrlsInput!) {
  s3_generatePresignedUrls(input: $input) {
    status
    result {
      uploadId
      presignedUrls
      objectUrl
    }
  }
}
    `;

export const useS3_GeneratePresignedUrlsMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<S3_GeneratePresignedUrlsMutation, TError, S3_GeneratePresignedUrlsMutationVariables, TContext>) => {
    
    return useMutation<S3_GeneratePresignedUrlsMutation, TError, S3_GeneratePresignedUrlsMutationVariables, TContext>(
      ['s3_generatePresignedUrls'],
      (variables?: S3_GeneratePresignedUrlsMutationVariables) => fetcher<S3_GeneratePresignedUrlsMutation, S3_GeneratePresignedUrlsMutationVariables>(S3_GeneratePresignedUrlsDocument, variables)(),
      options
    )};

export const S3_CompleteMultipartUploadDocument = `
    mutation s3_completeMultipartUpload($input: CompleteMultipartUploadInput!) {
  s3_completeMultipartUpload(input: $input) {
    status
  }
}
    `;

export const useS3_CompleteMultipartUploadMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<S3_CompleteMultipartUploadMutation, TError, S3_CompleteMultipartUploadMutationVariables, TContext>) => {
    
    return useMutation<S3_CompleteMultipartUploadMutation, TError, S3_CompleteMultipartUploadMutationVariables, TContext>(
      ['s3_completeMultipartUpload'],
      (variables?: S3_CompleteMultipartUploadMutationVariables) => fetcher<S3_CompleteMultipartUploadMutation, S3_CompleteMultipartUploadMutationVariables>(S3_CompleteMultipartUploadDocument, variables)(),
      options
    )};

export const ServiceCategory_CreateServiceCategoryDocument = `
    mutation serviceCategory_createServiceCategory($input: CreateServiceCategoryInput!) {
  serviceCategory_create(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;

export const useServiceCategory_CreateServiceCategoryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceCategory_CreateServiceCategoryMutation, TError, ServiceCategory_CreateServiceCategoryMutationVariables, TContext>) => {
    
    return useMutation<ServiceCategory_CreateServiceCategoryMutation, TError, ServiceCategory_CreateServiceCategoryMutationVariables, TContext>(
      ['serviceCategory_createServiceCategory'],
      (variables?: ServiceCategory_CreateServiceCategoryMutationVariables) => fetcher<ServiceCategory_CreateServiceCategoryMutation, ServiceCategory_CreateServiceCategoryMutationVariables>(ServiceCategory_CreateServiceCategoryDocument, variables)(),
      options
    )};

export const ServiceCategory_UpdateServiceCategoryDocument = `
    mutation serviceCategory_updateServiceCategory($input: UpdateServiceCategoryInput!) {
  serviceCategory_update(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;

export const useServiceCategory_UpdateServiceCategoryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceCategory_UpdateServiceCategoryMutation, TError, ServiceCategory_UpdateServiceCategoryMutationVariables, TContext>) => {
    
    return useMutation<ServiceCategory_UpdateServiceCategoryMutation, TError, ServiceCategory_UpdateServiceCategoryMutationVariables, TContext>(
      ['serviceCategory_updateServiceCategory'],
      (variables?: ServiceCategory_UpdateServiceCategoryMutationVariables) => fetcher<ServiceCategory_UpdateServiceCategoryMutation, ServiceCategory_UpdateServiceCategoryMutationVariables>(ServiceCategory_UpdateServiceCategoryDocument, variables)(),
      options
    )};

export const ServiceCategory_DeleteServiceCategoryDocument = `
    mutation serviceCategory_deleteServiceCategory($input: DeleteServiceCategoryInput!) {
  serviceCategory_delete(input: $input) {
    status
  }
}
    `;

export const useServiceCategory_DeleteServiceCategoryMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceCategory_DeleteServiceCategoryMutation, TError, ServiceCategory_DeleteServiceCategoryMutationVariables, TContext>) => {
    
    return useMutation<ServiceCategory_DeleteServiceCategoryMutation, TError, ServiceCategory_DeleteServiceCategoryMutationVariables, TContext>(
      ['serviceCategory_deleteServiceCategory'],
      (variables?: ServiceCategory_DeleteServiceCategoryMutationVariables) => fetcher<ServiceCategory_DeleteServiceCategoryMutation, ServiceCategory_DeleteServiceCategoryMutationVariables>(ServiceCategory_DeleteServiceCategoryDocument, variables)(),
      options
    )};

export const ServiceCategory_GetAllDocument = `
    query serviceCategory_getAll($skip: Int, $take: Int, $where: ServiceCategoryDtoFilterInput, $order: [ServiceCategoryDtoSortInput!]) {
  serviceCategory_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        logo
        abbreviation
      }
      totalCount
    }
    status
  }
}
    `;

export const useServiceCategory_GetAllQuery = <
      TData = ServiceCategory_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceCategory_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceCategory_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<ServiceCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceCategory_getAll'] : ['serviceCategory_getAll', variables],
      fetcher<ServiceCategory_GetAllQuery, ServiceCategory_GetAllQueryVariables>(ServiceCategory_GetAllDocument, variables),
      options
    )};

export const useInfiniteServiceCategory_GetAllQuery = <
      TData = ServiceCategory_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceCategory_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceCategory_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<ServiceCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceCategory_getAll.infinite'] : ['serviceCategory_getAll.infinite', variables],
      (metaData) => fetcher<ServiceCategory_GetAllQuery, ServiceCategory_GetAllQueryVariables>(ServiceCategory_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Specialist_GetAllDocument = `
    query specialist_getAll($skip: Int, $take: Int, $where: SpecialistDtoFilterInput, $order: [SpecialistDtoSortInput!]) {
  specialist_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        city {
          id
          name
        }
        registeredAt
        phoneNumber
        nationalCode
        profileImageUrl
        gender
        birthDate
        rateCount
        averageRating
        daysRegistered
        successfulMissions
        firstName
        id
        idCardImageUrl
        identityVerificationVideoStatus
        idCardVerificationStatus
        identityVerificationVideoUrl
        lastName
        code
        serviceTypes {
          id
          name
        }
        specializedDocumentsVerificationStatus
        specializedDocumentUrls
      }
      totalCount
    }
    status
  }
}
    `;

export const useSpecialist_GetAllQuery = <
      TData = Specialist_GetAllQuery,
      TError = unknown
    >(
      variables?: Specialist_GetAllQueryVariables,
      options?: UseQueryOptions<Specialist_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<Specialist_GetAllQuery, TError, TData>(
      variables === undefined ? ['specialist_getAll'] : ['specialist_getAll', variables],
      fetcher<Specialist_GetAllQuery, Specialist_GetAllQueryVariables>(Specialist_GetAllDocument, variables),
      options
    )};

export const useInfiniteSpecialist_GetAllQuery = <
      TData = Specialist_GetAllQuery,
      TError = unknown
    >(
      variables?: Specialist_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<Specialist_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<Specialist_GetAllQuery, TError, TData>(
      variables === undefined ? ['specialist_getAll.infinite'] : ['specialist_getAll.infinite', variables],
      (metaData) => fetcher<Specialist_GetAllQuery, Specialist_GetAllQueryVariables>(Specialist_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const Specialist_VerifyIdCardDocument = `
    mutation specialist_verifyIDCard($input: VerifyIDCardInput!) {
  specialist_verifyIDCard(input: $input) {
    status
  }
}
    `;

export const useSpecialist_VerifyIdCardMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Specialist_VerifyIdCardMutation, TError, Specialist_VerifyIdCardMutationVariables, TContext>) => {
    
    return useMutation<Specialist_VerifyIdCardMutation, TError, Specialist_VerifyIdCardMutationVariables, TContext>(
      ['specialist_verifyIDCard'],
      (variables?: Specialist_VerifyIdCardMutationVariables) => fetcher<Specialist_VerifyIdCardMutation, Specialist_VerifyIdCardMutationVariables>(Specialist_VerifyIdCardDocument, variables)(),
      options
    )};

export const Specialist_VerifyIdentityVerificationVideoDocument = `
    mutation specialist_verifyIdentityVerificationVideo($input: VerifyIdentityVerificationVideoInput!) {
  specialist_verifyIdentityVerificationVideo(input: $input) {
    status
  }
}
    `;

export const useSpecialist_VerifyIdentityVerificationVideoMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Specialist_VerifyIdentityVerificationVideoMutation, TError, Specialist_VerifyIdentityVerificationVideoMutationVariables, TContext>) => {
    
    return useMutation<Specialist_VerifyIdentityVerificationVideoMutation, TError, Specialist_VerifyIdentityVerificationVideoMutationVariables, TContext>(
      ['specialist_verifyIdentityVerificationVideo'],
      (variables?: Specialist_VerifyIdentityVerificationVideoMutationVariables) => fetcher<Specialist_VerifyIdentityVerificationVideoMutation, Specialist_VerifyIdentityVerificationVideoMutationVariables>(Specialist_VerifyIdentityVerificationVideoDocument, variables)(),
      options
    )};

export const Specialist_VerifySpecializedDocumentsDocument = `
    mutation specialist_verifySpecializedDocuments($input: VerifySpecializedDocumentsInput!) {
  specialist_verifySpecializedDocuments(input: $input) {
    status
  }
}
    `;

export const useSpecialist_VerifySpecializedDocumentsMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<Specialist_VerifySpecializedDocumentsMutation, TError, Specialist_VerifySpecializedDocumentsMutationVariables, TContext>) => {
    
    return useMutation<Specialist_VerifySpecializedDocumentsMutation, TError, Specialist_VerifySpecializedDocumentsMutationVariables, TContext>(
      ['specialist_verifySpecializedDocuments'],
      (variables?: Specialist_VerifySpecializedDocumentsMutationVariables) => fetcher<Specialist_VerifySpecializedDocumentsMutation, Specialist_VerifySpecializedDocumentsMutationVariables>(Specialist_VerifySpecializedDocumentsDocument, variables)(),
      options
    )};

export const ServiceSubCategory_CreateDocument = `
    mutation serviceSubCategory_create($input: CreateServiceSubCategoryInput!) {
  serviceSubCategory_create(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;

export const useServiceSubCategory_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceSubCategory_CreateMutation, TError, ServiceSubCategory_CreateMutationVariables, TContext>) => {
    
    return useMutation<ServiceSubCategory_CreateMutation, TError, ServiceSubCategory_CreateMutationVariables, TContext>(
      ['serviceSubCategory_create'],
      (variables?: ServiceSubCategory_CreateMutationVariables) => fetcher<ServiceSubCategory_CreateMutation, ServiceSubCategory_CreateMutationVariables>(ServiceSubCategory_CreateDocument, variables)(),
      options
    )};

export const ServiceSubCategory_UpdateDocument = `
    mutation serviceSubCategory_update($input: UpdateServiceSubCategoryInput!) {
  serviceSubCategory_update(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;

export const useServiceSubCategory_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceSubCategory_UpdateMutation, TError, ServiceSubCategory_UpdateMutationVariables, TContext>) => {
    
    return useMutation<ServiceSubCategory_UpdateMutation, TError, ServiceSubCategory_UpdateMutationVariables, TContext>(
      ['serviceSubCategory_update'],
      (variables?: ServiceSubCategory_UpdateMutationVariables) => fetcher<ServiceSubCategory_UpdateMutation, ServiceSubCategory_UpdateMutationVariables>(ServiceSubCategory_UpdateDocument, variables)(),
      options
    )};

export const ServiceSubCategory_DeleteDocument = `
    mutation serviceSubCategory_delete($input: DeleteServiceSubCategoryInput!) {
  serviceSubCategory_delete(input: $input) {
    status
  }
}
    `;

export const useServiceSubCategory_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceSubCategory_DeleteMutation, TError, ServiceSubCategory_DeleteMutationVariables, TContext>) => {
    
    return useMutation<ServiceSubCategory_DeleteMutation, TError, ServiceSubCategory_DeleteMutationVariables, TContext>(
      ['serviceSubCategory_delete'],
      (variables?: ServiceSubCategory_DeleteMutationVariables) => fetcher<ServiceSubCategory_DeleteMutation, ServiceSubCategory_DeleteMutationVariables>(ServiceSubCategory_DeleteDocument, variables)(),
      options
    )};

export const ServiceSubCategory_GetAllDocument = `
    query serviceSubCategory_getAll($skip: Int, $take: Int, $where: ServiceSubCategoryDtoFilterInput, $order: [ServiceSubCategoryDtoSortInput!]) {
  serviceSubCategory_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        logo
        abbreviation
        serviceCategory {
          id
          name
        }
      }
      totalCount
    }
    status
  }
}
    `;

export const useServiceSubCategory_GetAllQuery = <
      TData = ServiceSubCategory_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceSubCategory_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceSubCategory_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<ServiceSubCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceSubCategory_getAll'] : ['serviceSubCategory_getAll', variables],
      fetcher<ServiceSubCategory_GetAllQuery, ServiceSubCategory_GetAllQueryVariables>(ServiceSubCategory_GetAllDocument, variables),
      options
    )};

export const useInfiniteServiceSubCategory_GetAllQuery = <
      TData = ServiceSubCategory_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceSubCategory_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceSubCategory_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<ServiceSubCategory_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceSubCategory_getAll.infinite'] : ['serviceSubCategory_getAll.infinite', variables],
      (metaData) => fetcher<ServiceSubCategory_GetAllQuery, ServiceSubCategory_GetAllQueryVariables>(ServiceSubCategory_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const ServiceType_CreateDocument = `
    mutation serviceType_create($input: CreateServiceTypeInput!) {
  serviceType_create(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;

export const useServiceType_CreateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceType_CreateMutation, TError, ServiceType_CreateMutationVariables, TContext>) => {
    
    return useMutation<ServiceType_CreateMutation, TError, ServiceType_CreateMutationVariables, TContext>(
      ['serviceType_create'],
      (variables?: ServiceType_CreateMutationVariables) => fetcher<ServiceType_CreateMutation, ServiceType_CreateMutationVariables>(ServiceType_CreateDocument, variables)(),
      options
    )};

export const ServiceType_UpdateDocument = `
    mutation serviceType_update($input: UpdateServiceTypeInput!) {
  serviceType_update(input: $input) {
    status
    result {
      id
      name
      logo
    }
  }
}
    `;

export const useServiceType_UpdateMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceType_UpdateMutation, TError, ServiceType_UpdateMutationVariables, TContext>) => {
    
    return useMutation<ServiceType_UpdateMutation, TError, ServiceType_UpdateMutationVariables, TContext>(
      ['serviceType_update'],
      (variables?: ServiceType_UpdateMutationVariables) => fetcher<ServiceType_UpdateMutation, ServiceType_UpdateMutationVariables>(ServiceType_UpdateDocument, variables)(),
      options
    )};

export const ServiceType_DeleteDocument = `
    mutation serviceType_delete($input: DeleteServiceTypeInput!) {
  serviceType_delete(input: $input) {
    status
  }
}
    `;

export const useServiceType_DeleteMutation = <
      TError = unknown,
      TContext = unknown
    >(options?: UseMutationOptions<ServiceType_DeleteMutation, TError, ServiceType_DeleteMutationVariables, TContext>) => {
    
    return useMutation<ServiceType_DeleteMutation, TError, ServiceType_DeleteMutationVariables, TContext>(
      ['serviceType_delete'],
      (variables?: ServiceType_DeleteMutationVariables) => fetcher<ServiceType_DeleteMutation, ServiceType_DeleteMutationVariables>(ServiceType_DeleteDocument, variables)(),
      options
    )};

export const ServiceTypes_GetAllDocument = `
    query serviceTypes_getAll($skip: Int, $take: Int, $where: ServiceTypeDtoFilterInput, $order: [ServiceTypeDtoSortInput!]) {
  serviceTypes_getAll {
    result(skip: $skip, take: $take, where: $where, order: $order) {
      items {
        id
        name
        basePrice
        logo
        isSpecial
        banner
        abbreviation
        serviceSubCategory {
          id
          name
          serviceCategory {
            id
            name
          }
        }
      }
      totalCount
    }
    status
  }
}
    `;

export const useServiceTypes_GetAllQuery = <
      TData = ServiceTypes_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceTypes_GetAllQueryVariables,
      options?: UseQueryOptions<ServiceTypes_GetAllQuery, TError, TData>
    ) => {
    
    return useQuery<ServiceTypes_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceTypes_getAll'] : ['serviceTypes_getAll', variables],
      fetcher<ServiceTypes_GetAllQuery, ServiceTypes_GetAllQueryVariables>(ServiceTypes_GetAllDocument, variables),
      options
    )};

export const useInfiniteServiceTypes_GetAllQuery = <
      TData = ServiceTypes_GetAllQuery,
      TError = unknown
    >(
      variables?: ServiceTypes_GetAllQueryVariables,
      options?: UseInfiniteQueryOptions<ServiceTypes_GetAllQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<ServiceTypes_GetAllQuery, TError, TData>(
      variables === undefined ? ['serviceTypes_getAll.infinite'] : ['serviceTypes_getAll.infinite', variables],
      (metaData) => fetcher<ServiceTypes_GetAllQuery, ServiceTypes_GetAllQueryVariables>(ServiceTypes_GetAllDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};

export const User_GetMyProfileDocument = `
    query user_getMyProfile {
  user_getMyProfile {
    status
    result {
      id
      phoneNumber
      firstName
      lastName
      profileImageUrl
      gender
    }
  }
}
    `;

export const useUser_GetMyProfileQuery = <
      TData = User_GetMyProfileQuery,
      TError = unknown
    >(
      variables?: User_GetMyProfileQueryVariables,
      options?: UseQueryOptions<User_GetMyProfileQuery, TError, TData>
    ) => {
    
    return useQuery<User_GetMyProfileQuery, TError, TData>(
      variables === undefined ? ['user_getMyProfile'] : ['user_getMyProfile', variables],
      fetcher<User_GetMyProfileQuery, User_GetMyProfileQueryVariables>(User_GetMyProfileDocument, variables),
      options
    )};

export const useInfiniteUser_GetMyProfileQuery = <
      TData = User_GetMyProfileQuery,
      TError = unknown
    >(
      variables?: User_GetMyProfileQueryVariables,
      options?: UseInfiniteQueryOptions<User_GetMyProfileQuery, TError, TData>
    ) => {
    
    return useInfiniteQuery<User_GetMyProfileQuery, TError, TData>(
      variables === undefined ? ['user_getMyProfile.infinite'] : ['user_getMyProfile.infinite', variables],
      (metaData) => fetcher<User_GetMyProfileQuery, User_GetMyProfileQueryVariables>(User_GetMyProfileDocument, {...variables, ...(metaData.pageParam ?? {})})(),
      options
    )};
