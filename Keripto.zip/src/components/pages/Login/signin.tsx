import { LoadingButton } from '@mui/lab';
import { Box, Card, CardContent, InputAdornment, Typography } from '@mui/material';
import { useRouter } from 'next/router';
import React, { useState } from 'react';
import { useAuth_RequestOtpMutation, UserType } from 'src/graphql/generated';

import PersonIcon from '@/assets/person';
import { useForm, Yup, yupResolver } from '@/components/atoms/Form';
import { FormProvider, TextField } from '@/components/atoms/Form';
//import { useAuth } from '@/providers/AuthProvider';
import COLORS from '@/theme/colors';

import * as S from './styles';

export const PHONE_VALIDATION = /9(1[0-9]|3[1-9]|2[1-9])-?[0-9]{3}-?[0-9]{4}/g;
const LoginSchema = Yup.object().shape({
	Mobil: Yup.string()
		.required('موبایل را وارد کنید')
		.matches(PHONE_VALIDATION, 'شماره موبایل معتبر نیست')
		.max(10, 'شماره موبایل نباید بیشتر از 10 رقم باشد'),
});
const Index = ({ getcode }: { getcode: any }) => {
	const [showerror, setshowerror] = useState(false);
	const [loading, setloading] = useState(false);
	const router = useRouter();
	const defaultValues = {
		Mobil: '',
	};
	const { mutate: mutate, isLoading: isLoadinglogin } = useAuth_RequestOtpMutation();

	const methods = useForm({
		resolver: yupResolver(LoginSchema),
		defaultValues,
	});

	const { handleSubmit } = methods;

	//const { isLoading, signInWithEmail } = useAuth();

	const onSubmit = async (data: typeof defaultValues) => {
		//signInWithEmail(data.Mobil);
		await mutate(
			{
				input: {
					phoneNumber: '+98' + data.Mobil,
					userType: UserType.Admin,
				},
			},
			{
				onSuccess: async (res) => {
					getcode(data.Mobil);
				},
				onError: (err) => {
					setshowerror(true);
				},
			}
		);
	};

	return (
		<FormProvider methods={methods}>
			<S.Content>
				<Card
					sx={{
						boxShadow: '0px 12px 24px #00000014',
						backgroundColor: COLORS.white2,
					}}
				>
					<CardContent>
						<Box marginBottom="30px" display="flex" flexDirection="column" alignItems="center">
							<img src="/icons/logo.jpg" alt="business" draggable="false" width={150} />

							<Typography
								fontFamily="Vazir"
								color={COLORS.blue}
								fontSize="24px"
								fontWeight="bold"
								textAlign="center"
								sx={{ marginTop: '10px' }}
							>
								کاریتو
							</Typography>
							<Typography
								fontFamily="Vazir"
								color={COLORS.black}
								fontSize="20px"
								fontWeight="bold"
								textAlign="center"
								sx={{ marginTop: '10px' }}
							>
								ورود به پنل مدیریت
							</Typography>
							{showerror ? (
								<Box
									marginTop="15px"
									display="flex"
									padding="10px"
									sx={{ height: 46, width: '100%', borderRadius: '8px !important', backgroundColor: '#D9D9D9' }}
								>
									<S.cell>
										<Typography
											fontWeight={400}
											color={COLORS.red}
											fontSize="17px"
											textAlign="right"
											fontFamily="Vazir"
										>
											اطلاعات صحیح نیست{' '}
										</Typography>
									</S.cell>
									<S.cell sx={{ flexBasis: '40px', flexGrow: 0, flexShrink: 0, textAlign: 'center', marginTop: '1px' }}>
										<S.RemoveIcon />
									</S.cell>
								</Box>
							) : (
								''
							)}
						</Box>
						<Box>
							<TextField
								required
								name="Mobil"
								placeholder="9120000000"
								sx={{ mb: 3 }}
								id="Mobil"
								label=" موبایل"
								InputProps={{
									endAdornment: (
										<InputAdornment position="end">
											<PersonIcon />
										</InputAdornment>
									),
									style: {
										backgroundColor: '#f8f8f8',
										textAlign: 'right',
									},
								}}
							/>
						</Box>

						<LoadingButton
							variant="contained"
							onClick={handleSubmit(onSubmit)}
							loading={loading}
							fullWidth
							sx={{
								fontSize: '15px',
								//backgroundImage: 'linear-gradient(to right,#1D5BD2, #4D88F9)',c7dffa
								background: '#88b2e1',
								color: '#fff',
								borderRadius: '8px !important',
							}}
						>
							ورود
						</LoadingButton>
						{/* <S.rowpage>
							<S.cellpage>
								<S.Authsingupabi>بازیابی رمز عبور</S.Authsingupabi>
							</S.cellpage>
							<S.cellpagetext>
								<S.Authsingup onClick={() => router.push('login/forgetPass')}>فراموشی رمز عبور؟</S.Authsingup>
							</S.cellpagetext>
						</S.rowpage>*/}
					</CardContent>
				</Card>
			</S.Content>
		</FormProvider>
	);
};

export default Index;
