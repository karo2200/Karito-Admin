const API_URL = 'http://193.151.152.161:8081/graphql';
const SUBSCRIPTION_URL = 'http://193.151.152.161:8081/graphql';
const BLOB_BASE_URL = 'http://193.151.152.161:8081/graphql';
const BLOB_URL = '';

const config = {
	API_URL,
	BLOB_URL,
	BLOB_BASE_URL,
	SUBSCRIPTION_URL,
	//
	//
	FIREBASE: {
		APP_ID: '',
		API_KEY: '',
		PROJECT_ID: '',
		AUTH_DOMAIN: '',
		STORAGE_BUCKET: '',
		MESSAGING_SENDER_ID: '',
	},
};

module.exports = config;
